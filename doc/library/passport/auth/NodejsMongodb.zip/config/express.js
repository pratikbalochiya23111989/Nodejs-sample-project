//all required configurations
var config = require('./config'),
	express = require('express'),
	bodyParser = require('body-parser'),
	passport = require('passport'),
	flash = require('connect-flash'),
	session = require('express-session'),
	breadcrumbs = require('express-breadcrumbs'),
	expressLayouts = require('express-ejs-layouts'),
	fileUpload = require('express-fileupload');
	//parse multipart/form-data    
	fs = require('fs');
	var moment = require('moment');
	moment().format();
//ends here

//exports modules
module.exports = function() {
	var app = express();
	app.use(bodyParser.urlencoded({limit: '500mb',extended: true}));
	var timeout = require('connect-timeout');
	app.use(timeout(600000));

	app.use(bodyParser.json());
	app.use(fileUpload());

	app.use(session({
		saveUninitialized: true,
		resave: false,
		secret: 'OurSuperSecretCookieSecret'
	}));

	//set path for views 
	app.set('layout', './layouts/main_admin');
	app.set('views', './app/views');
	app.set('view engine', 'ejs');
	app.use(expressLayouts);
	//ends here 

	app.use(flash());
	app.use(passport.initialize());
	app.use(passport.session());

	app.use(breadcrumbs.init());


	// fs.readdirSync('./app/routes').forEach(function (file) {
	// 	if(file.substr(-3) == '.js') {
	// 		require('../app/routes/' + file);
	// 		//console.log(route)
	// 		//route.controller(app);
	// 	}
	// });
	require('../app/routes/index.server.routes.js')(app);
	require('../app/routes/api.server.routes.js')(app);
	
	// routes for company
	require('../app/routes/company/dashboard.server.routes.js')(app);
	require('../app/routes/company/social.server.routes.js')(app);
	require('../app/routes/company/members.server.routes.js')(app);
	require('../app/routes/company/challenges.server.routes.js')(app);
	require('../app/routes/company/departments.server.routes.js')(app);
	require('../app/routes/company/teams.server.routes.js')(app);
	require('../app/routes/company/users.server.routes.js')(app);

	// routes for superadmin
	require('../app/routes/admin/dashboard.server.routes.js')(app);
	require('../app/routes/admin/administrators.server.routes.js')(app);
	require('../app/routes/admin/companies.server.routes.js')(app);
	require('../app/routes/admin/countries.server.routes.js')(app);
	require('../app/routes/admin/states.server.routes.js')(app);
	require('../app/routes/admin/industry.server.routes.js')(app);
	require('../app/routes/admin/settings.server.routes.js')(app);
	require('../app/routes/admin/social.server.routes.js')(app);
	require('../app/routes/admin/loginlogs.server.routes.js')(app);
	require('../app/routes/admin/data_modeller.server.routes.js')(app);
	require('../app/routes/admin/insurance_manager.server.routes.js')(app);
	require('../app/routes/admin/insurance_types.server.routes.js')(app);
	require('../app/routes/admin/insurance_types_plans.server.routes.js')(app);
	require('../app/routes/admin/policy_holder.server.routes.js')(app);

	require('../app/routes/superadmin/dashboard.server.routes.js')(app);
	require('../app/routes/superadmin/administrators.server.routes.js')(app);
	require('../app/routes/superadmin/companies.server.routes.js')(app);
	require('../app/routes/superadmin/insuranceadmin.server.routes.js')(app);
	require('../app/routes/superadmin/settings.server.routes.js')(app);
	require('../app/routes/superadmin/social.server.routes.js')(app);
	require('../app/routes/superadmin/industry.server.routes.js')(app);
	require('../app/routes/superadmin/cms.server.routes.js')(app);
	require('../app/routes/superadmin/loginlogs.server.routes.js')(app);
	require('../app/routes/common.server.routes.js')(app);
	require('../app/routes/superadmin/flashscreen.server.routes.js')(app);
	require('../app/routes/superadmin/announcement.server.routes.js')(app);
	require('../app/routes/superadmin/pushnotification.server.routes.js')(app);
	require('../app/routes/superadmin/departments.server.routes.js')(app);
	require('../app/routes/superadmin/members.server.routes.js')(app);
	require('../app/routes/superadmin/teams.server.routes.js')(app);
	require('../app/routes/superadmin/insurance_types.server.routes.js')(app);
	require('../app/routes/superadmin/insurance_types_plans.server.routes.js')(app);
	require('../app/routes/superadmin/policy_holder.server.routes.js')(app);
	require('../app/routes/superadmin/insuranceTypes.server.routes.js')(app);
	require('../app/routes/superadmin/insuranceTypesPlans.server.routes.js')(app);
	require('../app/routes/superadmin/customerplan.server.routes.js')(app);
	require('../app/routes/restApi.server.routes.js')(app);
	app.use(express.static('./public'));
	app.use(express.static('./upload'));
	return app;
};

