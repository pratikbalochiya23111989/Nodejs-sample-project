var port = 1338;
module.exports = {
	port: port,
	db: 'mongodb://209.239.116.58/aktivolabs'
};