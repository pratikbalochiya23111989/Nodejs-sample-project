var api = require('../controllers/api.server.controller.js');
module.exports = function(app) {
	/*app.get('/checkfileupload', api.loadhtmlfile);
	app.post('/postSaveBeyondVerbal', api.postSaveBeyondVerbal);*/
	app.post('/api', function(req, res) {
		var action = req.body.action
		switch(action) {
			case 'postTest2':
				api.postTest2(req, res);
		        break;
			case 'postSaveMemberSleep':
				api.postSaveMemberSleep(req, res);
		        break;
			case 'postSaveSetting':
		        api.postSaveSetting(req, res);
		        break;
		    case 'postVerifyUserOrganization':
		        api.postVerifyUserOrganization(req, res);
		        break;
		    case 'postVerifyUser':
		        api.postVerifyUser(req, res);
		        break;
		    case 'postSendOTP':
		    	api.postSendOTP(req, res);
		        break;
		    case 'postMatchOTP':
		    	api.postMatchOTP(req, res);
		        break;
		    case 'postSaveBeyondVerbal':
		    	api.postSaveBeyondVerbal(req, res);
		        break;
		    case 'postListBeyondVerbalHistory':
		    	api.postListBeyondVerbalHistory(req, res);
		        break;
		    case 'postProvisioningUser':
		    	api.postProvisioningUser(req, res);
		        break;
		    case 'postValidicDashboard':
		    	api.postValidicDashboard(req, res);
		        break;
		    case 'postSaveValidic':
		    	api.postSaveValidic(req, res);
		        break;
		    case 'postDailyValidicCaloriesChartInfo':
		    	api.postDailyValidicCaloriesChartInfo(req, res);
		        break;
		    case 'postValidicCaloriesChartInfo':
		    	api.postValidicCaloriesChartInfo(req, res);
		        break;
		    case 'postDailyValidicStepsChartInfo':
		    	api.postDailyValidicStepsChartInfo(req, res);
		        break;
		    case 'postValidicStepsChartInfo':
		    	api.postValidicStepsChartInfo(req, res);
		        break;
		    case 'postDailyValidicSleepsChartInfo':
		    	api.postDailyValidicSleepsChartInfo(req, res);
		        break;
		    case 'postValidicSleepsChartInfo':
		    	api.postValidicSleepsChartInfo(req, res);
		        break;
		    case 'postDailyValidicHeartBitRateChartInfo':
		    	api.postDailyValidicHeartBitRateChartInfo(req, res);
		        break;
		    case 'postValidicHeartBitRateChartInfo':
		    	api.postValidicHeartBitRateChartInfo(req, res);
		        break;
		    case 'postIMGUploadBase64':
		    	api.postIMGUploadBase64(req, res);
		        break;
		    case 'postGetRandomFile':
		    	api.postGetRandomFile(req, res);
		        break;
		    case 'postSocialMedia':
		    	api.postSocialMedia(req, res);
		        break;
		    case 'postSocialMediaFeedback':
		    	api.postSocialMediaFeedback(req, res);
		        break;
		    case 'postListSocial':
		    	api.postListSocial(req, res);
		        break;
		    default:
		        res.send("Wrong API")
		}
	});
};