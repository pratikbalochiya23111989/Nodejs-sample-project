var social = require('../../controllers/company/social.server.controller.js');
	
module.exports = function(app) {
	//social timeline
	app.get('/social/list', social.list);

	app.post('/social/postFeedBack', social.postFeedBack);

	app.post('/social/postCommentFeedBack', social.postCommentFeedBack);

	app.post('/social/postListUserComment', social.postListUserComment);

	app.post('/social/postListLikeUsers', social.postListLikeUsers);

	app.post('/social/postSocialPost', social.postSocialPost);

	app.post('/social/pressListCommentUsersModal',social.pressListCommentUsersModal);

	app.post('/social/removePost',social.removePost);

	app.post('/social/ajaxListSocialPost',social.ajaxListSocialPost);

	app.post('/social/loadSinglePost',social.loadSinglePost)

	app.post('/social/postEditSocialPost',social.postEditSocialPost)

	app.post('/social/removeSocialPostMedia',social.removeSocialPostMedia)

	app.post('/social/postListPreviewUsers',social.postListPreviewUsers)

	app.post('/social/postListShareUsers',social.postListShareUsers)
};

