var dashboard = require('../../controllers/company/dashboard.server.controller.js');

module.exports = function(app) {
	// dashboard
	app.get('/dashboard/list', dashboard.list);

	// dashboard aktivo chart
	app.get('/dashboard/loadDashboardChart', dashboard.loadDashboardChart);

	// dashboard load team
	app.get('/dashboard/loadTeam', dashboard.loadTeam);
};