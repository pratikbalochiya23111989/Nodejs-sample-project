var teams = require('../../controllers/company/teams.server.controller');
	
module.exports = function(app) {
	app.post('/teams/list', teams.list_action);

	// get team list
	app.get('/teams/list', teams.list);

	// add team
	app.get('/team/add', teams.add);

	//create team
	app.post('/team/create', teams.create);

	// edit team
	app.get('/team/edit/:id', teams.edit);

	//update team
	app.post('/team/update', teams.update);
};



