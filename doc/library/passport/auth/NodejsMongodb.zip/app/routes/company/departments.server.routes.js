var departments = require('../../controllers/company/departments.server.controller.js');
	
module.exports = function(app) {
	app.post('/departments/list', departments.list_action);

	// get department list
	app.get('/departments/list', departments.list);

	// add department
	app.get('/department/add', departments.add);

	//create department
	app.post('/department/create', departments.create);

	// edit department
	app.get('/department/edit/:id', departments.edit);

	//update department
	app.post('/department/update', departments.update);
};

