var members = require('../../controllers/company/members.server.controller.js');
	
module.exports = function(app) {
	app.post('/members/list_action', members.list_action);

	// get team list_action
	app.get('/members/list', members.list);

	// add member
	app.get('/member/add', members.add);

	//create member
	app.post('/member/create', members.create);

	//edit member
	app.get('/member/edit/:id', members.edit);

	//edit member
	app.get('/member/removephoto/:id', members.removephoto);

	//update member
	app.post('/member/update', members.update);

	//score
	app.get('/member/score', members.score);

	//export members info
	app.get('/member/exportcsv', members.exportcsv);
	
	//import members info
	app.post('/member/importcsv', members.importcsv);
};
