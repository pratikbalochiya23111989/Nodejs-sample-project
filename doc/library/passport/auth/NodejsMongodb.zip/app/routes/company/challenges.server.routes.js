var challenges = require('../../controllers/company/challenges.server.controller.js');
	
module.exports = function(app) {
	app.post('/challenges/list', challenges.list_action);
	
	//get challenge list
	app.get('/challenges/list', challenges.list);

	//add challenge	
	app.get('/challenges/add', challenges.add);

	//create challenge	
	app.post('/challenges/create', challenges.create);

	//edit challenge
	app.get('/challenges/edit/:id', challenges.edit);

	//remove photo
	app.get('/challenges/removephoto/:id', challenges.removephoto);

	// app.post('/challenges/addmembers', challenges.addmembers);

	//update challenge
	app.post('/challenges/update', challenges.update);

	app.post('/challenges/addteams', challenges.addteams);

	app.post('/challenges/allteams', challenges.allteams);

	app.post('/challenges/addmembers', challenges.addmembers);

	app.get('/challenges/allmembers', challenges.allmembers);

	app.post('/challenges/allteammembers', challenges.allteammembers);
};
