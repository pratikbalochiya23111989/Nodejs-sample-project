var users = require('../../controllers/company/users.server.controller.js'),
	passport = require('passport');

module.exports = function(app) {
	//get users list
	app.get('/users/list', users.list);
	
	//add user 	
	app.get('/users/add', users.add);

	//create user 
	app.post('/users/create', users.create);

	//edit user 	
	app.get('/users/edit/:userId', users.edit);

	//update user 
	app.post('/users/update', users.update);
	
	//get users login logs 
	app.get('/users/loginlogs', users.loginlogs);

	
	//login route 
	app.route('/login')
		.get(users.renderLogin)
		.post(passport.authenticate('local', {
			successRedirect: '/',
			failureRedirect: '/login',
			failureFlash: true
		}));

	// change password
	app.get('/users/changepassword', users.changepassword);

	// account setting
	app.get('/users/accountsetting', users.accountsetting);
};
