var common = require('../controllers/common.server.controller.js');
	
module.exports = function(app) {
	// get terms and condition
	app.get('/terms-and-condition', common.termsAndCondition);

	app.get('/changepassword', common.changepassword);

	app.post('/changedpassword',common.changedpassword);

	
	app.get('/updateprofile',common.updateprofile);

	app.post('/updatedprofile',common.updatedprofile);
};