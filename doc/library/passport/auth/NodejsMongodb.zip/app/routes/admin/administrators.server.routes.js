var administrators = require('../../controllers/admin/administrators.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/administrators/list', administrators.list_action);

	// get administrator list
	app.get('/admin/administrators/list', administrators.list);

	// add administrator
	app.get('/admin/administrator/add', administrators.add);

	//create administrator
	app.post('/admin/administrator/create', administrators.create);

	// edit administrator
	app.get('/admin/administrator/edit/:id', administrators.edit);

	//update administrator
	app.post('/admin/administrator/update', administrators.update);
};