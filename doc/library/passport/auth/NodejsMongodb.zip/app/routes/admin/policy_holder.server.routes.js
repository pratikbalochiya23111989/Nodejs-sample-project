var policy_holder = require('../../controllers/admin/policy_holder.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/policy_holder/list', policy_holder.list_action);
	// get team list_action
	app.get('/admin/policy_holder/list', policy_holder.list);

	// add member
	app.get('/admin/policy_holder/add', policy_holder.add);


	//edit member
	app.get('/admin/policy_holder/edit/:id', policy_holder.edit);

	app.post('/admin/policy_holder/create', policy_holder.create);

	app.post('/admin/policy_holder/update', policy_holder.update);

	app.post('/admin/policy_holder/importcsv', policy_holder.importcsv);

};
