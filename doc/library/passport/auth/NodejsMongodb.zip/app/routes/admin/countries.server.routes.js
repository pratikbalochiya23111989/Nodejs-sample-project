var countries = require('../../controllers/admin/countries.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/countries/list', countries.list_action);
	
	// get country list
	app.get('/admin/countries/list', countries.list);

	// add country
	app.get('/admin/country/add', countries.add);

	//create country
	app.post('/admin/country/create', countries.create);

	// edit country
	app.get('/admin/country/edit/:id', countries.edit);

	//update country
	app.post('/admin/country/update', countries.update);
};

