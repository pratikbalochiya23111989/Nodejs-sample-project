var social = require('../../controllers/admin/social.server.controller.js');
	
module.exports = function(app) {
	//social timeline
	app.get('/admin/social/list', social.list);

	app.post('/admin/social/postFeedBack', social.postFeedBack);

	app.post('/admin/social/postCommentFeedBack', social.postCommentFeedBack);

	app.post('/admin/social/postListUserComment', social.postListUserComment);

	app.post('/admin/social/postListLikeUsers', social.postListLikeUsers);

	app.post('/admin/social/postSocialPost', social.postSocialPost);

	app.post('/admin/social/pressListCommentUsersModal',social.pressListCommentUsersModal);

	app.post('/admin/social/removePost',social.removePost);

	app.post('/admin/social/ajaxListSocialPost',social.ajaxListSocialPost);

	app.post('/admin/social/loadSinglePost',social.loadSinglePost)

	app.post('/admin/social/postEditSocialPost',social.postEditSocialPost)

	app.post('/admin/social/removeSocialPostMedia',social.removeSocialPostMedia)

	app.post('/admin/social/postListPreviewUsers',social.postListPreviewUsers)

	app.post('/admin/social/postListShareUsers',social.postListShareUsers)
};

