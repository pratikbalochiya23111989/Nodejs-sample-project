var loginlogs = require('../../controllers/admin/loginlogs.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/loginlogs/list', loginlogs.list_action);

	// get loginlogs list
	app.get('/admin/loginlogs/list', loginlogs.list);

	app.post('/admin/loginlogs/logactivity', loginlogs.logactivity);
};