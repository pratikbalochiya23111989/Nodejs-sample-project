var insurance_manager = require('../../controllers/admin/insurance_manager.server.controller.js');
	
module.exports = function(app) {
	// get insurance_manager list
	app.get('/admin/insurance_manager/list', insurance_manager.list);

	app.get('/admin/insurance_manager/list_rundata', insurance_manager.listrundata);
};

