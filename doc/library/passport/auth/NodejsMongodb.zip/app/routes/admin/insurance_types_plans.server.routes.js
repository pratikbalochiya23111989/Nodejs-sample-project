var insurance_types_plans = require('../../controllers/admin/insurance_types_plans.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/insurance_types_plans/list', insurance_types_plans.list_action);
	// get insurance_type_plans list
	app.get('/admin/insurance_types_plans/list', insurance_types_plans.list);

	// add insurance_type_plans
	app.get('/admin/insurance_types_plans/add', insurance_types_plans.add);

	// edit insurance_type_plans

	app.get('/admin/insurance_types_plans/edit/:id', insurance_types_plans.edit);

	app.post('/admin/insurance_types_plans/create', insurance_types_plans.create);

	app.post('/admin/insurance_types_plans/update', insurance_types_plans.update);

	//app.post('/admin/insurance_type_plans/create', insurance_type_plans.create);
};

