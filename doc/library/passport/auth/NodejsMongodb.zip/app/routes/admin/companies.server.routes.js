var companies = require('../../controllers/admin/companies.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/company/list', companies.list_action);

	// get company list
	app.get('/admin/company/list', companies.list);

	// add company
	app.get('/admin/company/add', companies.add);

	//create company
	app.post('/admin/company/create', companies.create);

	// edit company
	app.get('/admin/company/edit/:id', companies.edit);

	//update company
	app.post('/admin/company/update', companies.update);
};

