var data_modeller = require('../../controllers/admin/data_modeller.server.controller.js');
	
module.exports = function(app) {
	// get data_modeller list
	app.get('/admin/data_modeller/list', data_modeller.list);
};

