var industry = require('../../controllers/admin/industry.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/industry/list', industry.list_action);

	// get industry list
	app.get('/admin/industry/list', industry.list);

	// add industry
	app.get('/admin/industry/add', industry.add);

	//create industry
	app.post('/admin/industry/create', industry.create);

	// edit industry
	app.get('/admin/industry/edit/:id', industry.edit);

	//update industry
	app.post('/admin/industry/update', industry.update);
};