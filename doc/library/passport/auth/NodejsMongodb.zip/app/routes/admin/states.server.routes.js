var states = require('../../controllers/admin/states.server.controller.js');
	
module.exports = function(app) {
	app.post('/admin/states/list', states.list_action);
	
	// get state list
	app.get('/admin/states/list', states.list);

	// add state
	app.get('/admin/state/add', states.add);

	//create state
	app.post('/admin/state/create', states.create);

	// edit state
	app.get('/admin/state/edit/:id', states.edit);

	//update state
	app.post('/admin/state/update', states.update);
};

