var settings = require('../../controllers/admin/settings.server.controller.js');
	
module.exports = function(app) {
	// edit setting
	app.get('/admin/setting/edit', settings.edit);

	//update setting
	app.post('/admin/setting/update', settings.update);
};

