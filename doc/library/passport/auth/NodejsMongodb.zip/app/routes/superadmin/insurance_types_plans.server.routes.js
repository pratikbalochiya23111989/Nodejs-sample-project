var insurance_types_plans = require('../../controllers/superadmin/insurance_types_plans.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/insurance_types_plans/list', insurance_types_plans.list_action);
	// get insurance_type_plans list
	app.get('/superadmin/insurance_types_plans/list', insurance_types_plans.list);

	// add insurance_type_plans
	app.get('/superadmin/insurance_types_plans/add', insurance_types_plans.add);

	// edit insurance_type_plans

	app.get('/superadmin/insurance_types_plans/edit/:id', insurance_types_plans.edit);

	app.post('/superadmin/insurance_types_plans/create', insurance_types_plans.create);

	app.post('/superadmin/insurance_types_plans/update', insurance_types_plans.update);

	app.get('/superadmin/insurance_types_plans/removephoto/:id', insurance_types_plans.removephoto);
};

