var administrators = require('../../controllers/superadmin/administrators.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/administrators/list', administrators.list_action);

	// get administrator list
	app.get('/superadmin/administrators/list', administrators.list);

	// add administrator
	app.get('/superadmin/administrator/add', administrators.add);

	//create administrator
	app.post('/superadmin/administrator/create', administrators.create);

	// edit administrator
	app.get('/superadmin/administrator/edit/:id', administrators.edit);

	//update administrator
	app.post('/superadmin/administrator/update', administrators.update);

	app.post('/checkemailexist', administrators.checkemailexist);
};