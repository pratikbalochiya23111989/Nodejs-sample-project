var teams = require('../../controllers/superadmin/teams.server.controller');
	
module.exports = function(app) {
	app.post('/superadmin/teams/list', teams.list_action);

	// get team list
	app.get('/superadmin/teams/list', teams.list);

	// add team
	app.get('/superadmin/teams/add', teams.add);

	//create team
	app.post('/superadmin/teams/create', teams.create);

	// edit team
	app.get('/superadmin/teams/edit/:id', teams.edit);

	//update team
	app.post('/superadmin/teams/update', teams.update);

	app.get('/superadmin/teams/removephoto/:id', teams.removephoto);
};



