var flashscreen = require('../../controllers/superadmin/flashscreen.server.controller.js');
	
module.exports = function(app) {
	// get flashscreen list
	app.get('/superadmin/flashscreen/list', flashscreen.list);

	// edit flashscreen
	app.get('/superadmin/flashscreen/edit/:id', flashscreen.edit);

	// //update flashscreen
	app.post('/superadmin/flashscreen/update', flashscreen.update);

	// //remove image flashscreen
	app.get('/admin/flashscreen/removephoto/:id', flashscreen.removephoto);
};