var cms = require('../../controllers/superadmin/cms.server.controller.js');
	
module.exports = function(app) {
	// get cms list
	app.get('/superadmin/cms/list', cms.list);

	// edit cms
	app.get('/superadmin/cms/edit/:id', cms.edit);

	//update cms
	app.post('/superadmin/cms/update', cms.update);

	// cms content
	app.post('/superadmin/cms/getContent', cms.getContent);
};