var social = require('../../controllers/superadmin/social.server.controller.js');
	
module.exports = function(app) {
	//social timeline
	app.get('/superadmin/social/list', social.list);

	app.post('/superadmin/social/postFeedBack', social.postFeedBack);

	app.post('/superadmin/social/postCommentFeedBack', social.postCommentFeedBack);

	app.post('/superadmin/social/postListUserComment', social.postListUserComment);

	app.post('/superadmin/social/postListLikeUsers', social.postListLikeUsers);

	app.post('/superadmin/social/postSocialPost', social.postSocialPost);

	app.post('/superadmin/social/pressListCommentUsersModal',social.pressListCommentUsersModal);

	app.post('/superadmin/social/removePost',social.removePost);

	app.post('/superadmin/social/ajaxListSocialPost',social.ajaxListSocialPost);

	app.post('/superadmin/social/loadSinglePost',social.loadSinglePost)

	app.post('/superadmin/social/postEditSocialPost',social.postEditSocialPost)

	app.post('/superadmin/social/removeSocialPostMedia',social.removeSocialPostMedia)

	app.post('/superadmin/social/postListPreviewUsers',social.postListPreviewUsers)

	app.post('/superadmin/social/postListShareUsers',social.postListShareUsers)
};

