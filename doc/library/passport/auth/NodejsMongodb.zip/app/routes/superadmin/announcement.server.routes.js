	var announcement = require('../../controllers/superadmin/announcement.server.controller.js');
	
module.exports = function(app) {
	// get announcement list

	app.post('/superadmin/announcement/list', announcement.list_action);

	app.get('/superadmin/announcement/list', announcement.list);

	// add announcement
	app.get('/superadmin/announcement/add', announcement.add);

	// edit announcement
	app.get('/superadmin/announcement/edit/:id', announcement.edit);

	app.post('/superadmin/announcement/create', announcement.create);

	app.post('/superadmin/announcement/update', announcement.update);

	app.get('/superadmin/announcement/removephoto/:id', announcement.removephoto);
};

