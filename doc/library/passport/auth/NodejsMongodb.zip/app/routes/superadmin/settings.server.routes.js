var settings = require('../../controllers/superadmin/settings.server.controller.js');
	
module.exports = function(app) {
	// edit setting
	app.get('/superadmin/setting/edit', settings.edit);

	//update setting
	app.post('/superadmin/setting/update', settings.update);
};

