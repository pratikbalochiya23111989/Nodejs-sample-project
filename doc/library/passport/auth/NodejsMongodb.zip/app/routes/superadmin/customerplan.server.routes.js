var customerplan = require('../../controllers/superadmin/customerplan.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/customerplan/list', customerplan.list_action);
	
	// get customerplan list
	app.get('/superadmin/customerplan/list', customerplan.list);

		// add customerplan
	app.get('/superadmin/customerplan/add', customerplan.add);

	//create customerplan
	app.post('/superadmin/customerplan/create', customerplan.create);

	// edit customerplan
	app.get('/superadmin/customerplan/edit/:id', customerplan.edit);

	// //update customerplan
	app.post('/superadmin/customerplan/update', customerplan.update);

	// //remove photo customerplan
	app.get('/superadmin/customerplan/removephoto/:id', customerplan.removephoto);
};