var insuranceTypesPlans = require('../../controllers/superadmin/insuranceTypesPlans.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/insuranceTypesPlans/list', insuranceTypesPlans.list_action);
	// get insuranceTypesPlans list
	app.get('/superadmin/insuranceTypesPlans/list', insuranceTypesPlans.list);

	// add insuranceTypesPlans
	app.get('/superadmin/insuranceTypesPlans/add', insuranceTypesPlans.add);

	// edit insuranceTypesPlans

	app.get('/superadmin/insuranceTypesPlans/edit/:id', insuranceTypesPlans.edit);

	app.post('/superadmin/insuranceTypesPlans/create', insuranceTypesPlans.create);

	app.post('/superadmin/insuranceTypesPlans/update', insuranceTypesPlans.update);

	app.get('/superadmin/insuranceTypesPlans/removephoto/:id', insuranceTypesPlans.removephoto);
	//app.post('/superadmin/insuranceTypePlans/create', insuranceTypesPlans.create);
};

