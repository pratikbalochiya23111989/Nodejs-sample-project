var dashboard = require('../../controllers/superadmin/dashboard.server.controller.js');
	
module.exports = function(app) {
	app.get('/superadmin/dashboard/list', dashboard.list);
	app.get('/superadmin/dashboard/loadDashboardChart', dashboard.loadDashboardChart);
	app.get('/superadmin/dashboard/loadCompany', dashboard.loadCompany);
};