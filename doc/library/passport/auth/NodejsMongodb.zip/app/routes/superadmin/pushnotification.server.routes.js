var pushnotification = require('../../controllers/superadmin/pushnotification.server.controller.js');
	
module.exports = function(app) {
	app.post('/pushnotification/list', pushnotification.list_action);

	// get pushnotification list
	app.get('/pushnotification/list', pushnotification.list);

	// add pushnotification
	app.get('/pushnotification/add', pushnotification.add);

	//create pushnotification
	app.post('/pushnotification/create', pushnotification.create);

	//Users List
	app.post('/pushnotification/usersList', pushnotification.usersList);

	app.post('/pushnotification/add_user', pushnotification.add_user);

};