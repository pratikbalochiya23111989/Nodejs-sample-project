	var insurance_types = require('../../controllers/superadmin/insurance_types.server.controller.js');
	
module.exports = function(app) {
	// get insurance_types list

	app.post('/superadmin/insurance_types/list', insurance_types.list_action);

	app.get('/superadmin/insurance_types/list', insurance_types.list);

	// add insurance_types
	app.get('/superadmin/insurance_types/add', insurance_types.add);

	// edit insurance_types
	app.get('/superadmin/insurance_types/edit/:id', insurance_types.edit);

	app.post('/superadmin/insurance_types/create', insurance_types.create);

	app.post('/superadmin/insurance_types/update', insurance_types.update);

	app.get('/superadmin/insurance_types/removephoto/:id', insurance_types.removephoto);
};

