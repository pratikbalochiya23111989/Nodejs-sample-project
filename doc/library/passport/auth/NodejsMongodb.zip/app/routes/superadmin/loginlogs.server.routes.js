var loginlogs = require('../../controllers/superadmin/loginlogs.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/loginlogs/list', loginlogs.list_action);

	// get loginlogs list
	app.get('/superadmin/loginlogs/list', loginlogs.list);

	app.post('/superadmin/loginlogs/logactivity', loginlogs.logactivity);
};