var members = require('../../controllers/superadmin/members.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/members/list_action', members.list_action);

	// get team list_action
	app.get('/superadmin/members/list', members.list);

	// add member
	app.get('/superadmin/members/add', members.add);

	//create member
	app.post('/superadmin/members/create', members.create);

	//edit member
	app.get('/superadmin/members/edit/:id', members.edit);

	//edit member
	app.get('/superadmin/members/removephoto/:id', members.removephoto);

	//update member
	app.post('/superadmin/members/update', members.update);

	//score
	app.get('/superadmin/members/score', members.score);

	//export members info
	app.get('/superadmin/members/exportcsv', members.exportcsv);
	
	//import members info
	app.post('/superadmin/members/importcsv', members.importcsv);
};
