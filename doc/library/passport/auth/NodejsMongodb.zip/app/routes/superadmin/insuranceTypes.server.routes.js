	var insuranceTypes = require('../../controllers/superadmin/insuranceTypes.server.controller.js');
	
module.exports = function(app) {
	// get insuranceTypes list

	app.post('/superadmin/insuranceTypes/list', insuranceTypes.list_action);

	app.get('/superadmin/insuranceTypes/list', insuranceTypes.list);

	// add insuranceTypes
	app.get('/superadmin/insuranceTypes/add', insuranceTypes.add);

	// edit insuranceTypes
	app.get('/superadmin/insuranceTypes/edit/:id', insuranceTypes.edit);

	app.post('/superadmin/insuranceTypes/create', insuranceTypes.create);

	app.post('/superadmin/insuranceTypes/update', insuranceTypes.update);

	app.get('/superadmin/insuranceTypes/removephoto/:id', insuranceTypes.removephoto);
};

