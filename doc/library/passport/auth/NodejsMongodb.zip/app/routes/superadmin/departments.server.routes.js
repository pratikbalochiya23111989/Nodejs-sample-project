var departments = require('../../controllers/superadmin/departments.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/departments/list', departments.list_action);

	// get department list
	app.get('/superadmin/departments/list', departments.list);

	// add department
	app.get('/superadmin/departments/add', departments.add);

	//create department
	app.post('/superadmin/departments/create', departments.create);

	// edit department
	app.get('/superadmin/departments/edit/:id', departments.edit);

	//update department
	app.post('/superadmin/departments/update', departments.update);

	app.get('/superadmin/departments/removephoto/:id', departments.removephoto);
};

