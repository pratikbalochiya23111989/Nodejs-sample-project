var policy_holder = require('../../controllers/superadmin/policy_holder.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/policy_holder/list', policy_holder.list_action);
	// get team list_action
	app.get('/superadmin/policy_holder/list', policy_holder.list);

	// add member
	app.get('/superadmin/policy_holder/add', policy_holder.add);


	//edit member
	app.get('/superadmin/policy_holder/edit/:id', policy_holder.edit);

	app.post('/superadmin/policy_holder/create', policy_holder.create);

	app.post('/superadmin/policy_holder/update', policy_holder.update);

	app.post('/superadmin/policy_holder/importcsv', policy_holder.importcsv);

	app.get('/superadmin/policy_holder/removephoto/:id', policy_holder.removephoto);

};
