var industry = require('../../controllers/superadmin/industry.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/industry/list', industry.list_action);

	// get industry list
	app.get('/superadmin/industry/list', industry.list);

	// add industry
	app.get('/superadmin/industry/add', industry.add);

	//create industry
	app.post('/superadmin/industry/create', industry.create);

	// edit industry
	app.get('/superadmin/industry/edit/:id', industry.edit);

	//update industry
	app.post('/superadmin/industry/update', industry.update);

	//remove Photo
	app.get('/superadmin/industry/removephoto/:id', industry.removephoto);

};