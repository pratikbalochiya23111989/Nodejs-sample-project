var companies = require('../../controllers/superadmin/companies.server.controller.js');
	
module.exports = function(app) {
	app.post('/company/list', companies.list_action);

	// get company list
	app.get('/company/list', companies.list);

	// add company
	app.get('/company/add', companies.add);

	//create company
	app.post('/company/create', companies.create);

	// edit company
	app.get('/company/edit/:id', companies.edit);

	//update company
	app.post('/company/update', companies.update);

	app.post('/departments/listaction', companies.listdepartmentaction);

	app.post('/department/createdepartment', companies.createdepartment);

	app.post('/team/createteam', companies.createteam);

	app.post('/department/editdepartment', companies.editdepartment);

	app.get('/company/:id/:tab/:companyid/update', companies.updatedepartteammember);

	app.get('/comapny/edit/:id/:tab', companies.tabviceview);
		
	app.get('/list_department', function(req, res){
		res.redirect('/company/edit/'+req.session.companyid);
	  
	});
	app.get('/list_team', function(req, res){
		res.redirect('/company/edit/'+req.session.companyid);
	  
	});
	app.get('/list_member', function(req, res){
		res.redirect('/company/edit/'+req.session.companyid);
	  
	});

	app.get('/company/removephoto/:id', companies.removephoto);

};

