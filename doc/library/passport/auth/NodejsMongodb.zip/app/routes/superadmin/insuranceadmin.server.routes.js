var insuranceadmin = require('../../controllers/superadmin/insuranceadmin.server.controller.js');
	
module.exports = function(app) {
	app.post('/superadmin/insuranceadmin/list', insuranceadmin.list_action);

	// get insuranceadmin list
	app.get('/superadmin/insuranceadmin/list', insuranceadmin.list);

	// add insuranceadmin
	app.get('/superadmin/insuranceadmin/add', insuranceadmin.add);

	//create insuranceadmin
	app.post('/superadmin/insuranceadmin/create', insuranceadmin.create);

	// edit insuranceadmin
	app.get('/superadmin/insuranceadmin/edit/:id', insuranceadmin.edit);

	//update insuranceadmin
	app.post('/superadmin/insuranceadmin/update', insuranceadmin.update);

	//remove Photo
	app.get('/superadmin/insuranceadmin/removephoto/:id', insuranceadmin.removephoto);
};