module.exports = function(req, res, next){
    if(req.session.uniqueid){
        next();
    }else res.send("Not auth");
}