var Administrator = require('mongoose').model('Administrator');
var EmailTemplate = require('mongoose').model('EmailTemplate');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var moment = require('moment')
var CustomerPlan=require('mongoose').model('CustomerPlan');

// list insuranceadmin
exports.list = function(req, res, next) {
	Administrator.find({status: {'$ne':'Deleted' }}, function(err, insuranceadmin) {
		if (err) {
			return next(err);
		}
		else {
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var fullUrl = req.protocol + '://' + req.get('host');
			for (var i = 0; i < insuranceadmin.length; i++) {
				var uploadpath = appDir+'/upload/insuranceadmin/'+insuranceadmin[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(insuranceadmin[i].photo!='')
                      {
                          insuranceadmin[i].photo = fullUrl+'/insuranceadmin/'+insuranceadmin[i].photo;
                      }
                      else
                      {
                          insuranceadmin[i].photo = fullUrl+'/insuranceadmin/no_image_user.png';
                      }
				}
				catch (e) {
				  	insuranceadmin[i].photo = fullUrl+'/insuranceadmin/no_image_user.png';
				}
			};
			res.render('superadmin/insuranceadmin/list', {
				pagename : 'insuranceadmin',
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				insuranceadmin: insuranceadmin,
				access_permission: req.session.access_permission,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new insuranceadmin 
exports.add = function(req, res, next) {
	CustomerPlan.find({status:'Active'}, function(err, customerplan) {
		console.log("Customerplan: "+customerplan);
		res.render('superadmin/insuranceadmin/add', {
			pagename : 'insuranceadmin',
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			customerplan : customerplan,
			messages: req.flash('error') || req.flash('info')
		});
	});	
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
	var fileExt = req.files.photo.name.split('.').pop();
	fileName = fileName+'.'+fileExt;
	var insuranceadmin = new Administrator(req.body);
	insuranceadmin.company_id = req.session.uniqueid;
	insuranceadmin.photo = fileName;
	insuranceadmin.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			sampleFile = req.files.photo;
			sampleFile.mv('./upload/insuranceadmin/'+fileName, function(err) {
				    var date = new Date();
					industry_name=req.body.title;
					loginHistoryObj.title = req.session.name+' added new insuranceadmin '+ industry_name;
					loginHistoryObj.login_id = req.session.historyid;
					loginHistoryObj.posted =date;
					loginHistoryObj.save(function(err) {
					});
				req.flash('info', 'New insuranceadmin Added Successfully.');
				return res.redirect('/superadmin/insuranceadmin/list');
			});
		}
	});
};

// exports.create = function(req, res, next) {	
// 	var loginHistoryObj = new LogActivity();
// 	var md5 = require('md5');
// 	var originalPassword = req.body.password;
// 	req.body.password = md5(req.body.password);
	
// 	var length = 10;
	
// 	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
// 	var fileExt = req.files.photo.name.split('.').pop();	
// 	fileName = fileName+'.'+fileExt;	
// 	sampleFile = req.files.photo;	
// 	sampleFile.mv('./upload/insuranceadmin/'+fileName, function(err) 
// 		{	
// 			if (err)	  
// 				return res.status(500).send(err);	
// 		});
// 	req.body.photo=fileName;
// 	var insuranceadmin = new Administrator(req.body);
// 	insuranceadmin.save(function(err) {
// 		if (err) {
// 			return next(err);
// 		}
// 		else {
// 			// EmailTemplate.findOne({code: 'SIGNUP'}, function(err, emailcontent) {
// 			// 	var text = emailcontent.content;
// 			// 	text = text.replace("#NAME#", (req.body.firstname+' '+req.body.lastname)).replace("#EMAIL#", req.body.email).replace("#PASSWORD#", originalPassword);
				
// 			// 	var api_key = 'key-43cf4c016eb85a389fc22df0dd7bf6f4';
// 			// 	var domain = 'dotzapper.com';
// 			// 	var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});
				 
// 			// 	var data = {
// 			// 	  from: 'Aktivo <demo1.testing1@gmail.com>',
// 			// 	  to: req.body.email,
// 			// 	  subject: 'Thank you for sign up at Brio',
// 			// 	  html: text
// 			// 	};
				 
// 				// mailgun.messages().send(data, function (error, body) {
// 					var date = new Date();
// 					loginHistoryObj.title = req.session.name+' created new insurance admin '+ req.body.firstname +' '+req.body.lastname;
// 					loginHistoryObj.login_id = req.session.historyid;
// 					loginHistoryObj.posted =date;
// 					loginHistoryObj.save(function(err) {
// 					});
// 				  	req.flash('info', 'New Insurance Admin Added Successfully.');
// 					return res.redirect('/superadmin/insuranceadmin/list');	
// 				// });
// 			//});
// 		}
// 	});
// };

exports.edit = function(req, res, next) {
	var id = req.params.id;
	Administrator.findOne({
			_id: id
		}, 
		function(err, insuranceadmin) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
                    if(insuranceadmin.photo!=''){
                        insuranceadmin.photo = fullUrl+'/insuranceadmin/'+insuranceadmin.photo;
                    }
                    else {
                        insuranceadmin.photo = '';
                    }
	            CustomerPlan.find({status:'Active'}, function(err, customerplan) {        
					res.render('superadmin/insuranceadmin/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						insuranceadmin: insuranceadmin,
						customerplan : customerplan,
						messages: req.flash('error') || req.flash('info')
					});
				});	
			}
		}
	);
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/insuranceadmin/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Administrator.findByIdAndUpdate(req.body.admin_id, req.body, function(err, user) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				loginHistoryObj.title = req.session.name+' updated insurance admin '+ req.body.firstname +' '+req.body.lastname;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Insurance admin Updated Successfully.');
				return res.redirect('/superadmin/insuranceadmin/list');
			}
		});
	}
	 else
	 {
	 	Administrator.findByIdAndUpdate(req.body.admin_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Insurance Admin Updated Successfully.');
				return res.redirect('/superadmin/insuranceadmin/list');
			}
		});
	 }
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	console.log(action);
	console.log(ids);
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Administrator.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Administrator.findOne({_id:n1},function(err, insuranceadmin){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  insuranceadmin '+ insuranceadmin.firstname+" "+insuranceadmin.lastname;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/insuranceadmin/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Administrator.findOne({
			_id: id
		}, 
		function(err, insuranceadmin) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/insuranceadmin/'+insuranceadmin.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Administrator.findByIdAndUpdate(id, memupdate, function(err, insuranceadmin) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/insuranceadmin/edit/'+id);
					}
				});
			}
		}
	);
};