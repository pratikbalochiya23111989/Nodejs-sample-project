var Department = require('mongoose').model('Department');
var Member = require('mongoose').model('Member');
var fs = require('fs');
var path = require('path');
var moment = require('moment')

// list departments
exports.list = function(req, res, next) {
	// console.log(req.session.uniqueid);return false;
	Department.find({status: {'$ne':'Deleted' },type:'Wellnessclient'}, function(err, departments) {
		if (err) {
			return next(err);
		}
		else {
			 	var appDir = path.dirname(require.main.filename);
				var fullUrl = req.protocol + '://' + req.get('host');
				var fs = require('fs');
				for (var i = 0; i < departments.length; i++) {
				var uploadpath = appDir+'/upload/department/'+departments[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(departments[i].photo!='')
				  	{
				  		departments[i].photo = fullUrl+'/department/'+departments[i].photo;
				  	}
				  	else
				  	{
				  		departments[i].photo = fullUrl+'/department/no_image_user.png';
				  	}
				  	
				}
				catch (e) {
				  	departments[i].photo = fullUrl+'/department/no_image_user.png';
				}
				// console.log(flashscreen[i].image);
			};
			res.render('superadmin/departments/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				departments: departments,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new department 
exports.add = function(req, res, next) {
		res.render('superadmin/departments/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			messages: req.flash('error') || req.flash('info')
		});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
	var fileExt = req.files.photo.name.split('.').pop();
	fileName = fileName+'.'+fileExt;
	var department = new Department(req.body);
	department.company_id = req.session.uniqueid;
	department.photo = fileName;
	department.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			sampleFile = req.files.photo;
			sampleFile.mv('./upload/department/'+fileName, function(err) {
				    var date = new Date();
					industry_name=req.body.title;
					loginHistoryObj.title = req.session.name+' added new department '+ industry_name;
					loginHistoryObj.login_id = req.session.historyid;
					loginHistoryObj.posted =date;
					loginHistoryObj.save(function(err) {
					});
				req.flash('info', 'New department Added Successfully.');
				return res.redirect('/superadmin/departments/list');
			});
		}
	});
};

// edit department

exports.edit = function(req, res, next) {
	var id = req.params.id;
	
	 Department.findOne({
	 		_id: id
		}, 
		function(err, department) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
					if(department.photo)
						{
							if(department.photo!=''){
								department.photo = fullUrl+'/department/'+department.photo;
								// if (!fs.existsSync(path)) {
								//    department.photo = '';
								// }
							}
							else {
								department.photo = '';
								}
						}
					else
					{
						department.photo = '';
					}
					res.render('superadmin/departments/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						department:department,
						messages: req.flash('error') || req.flash('info')
					});
			}
		});
};

// update department
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.body.imgUpload=='Yes')
	{
		var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/department/'+fileName, function(err) 
			{	
				if (err)	 
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Department.findByIdAndUpdate(req.body.departmentid, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated department '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				console.log(loginHistoryObj.login_id);
				console.log(loginHistoryObj);
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Department Updated Successfully.');
				return res.redirect('/superadmin/departments/list');
			}
		});
	}
	else
	{
		Department.findByIdAndUpdate(req.body.departmentid, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Department Updated Successfully.');
				return res.redirect('/superadmin/departments/list');
			}
		});
	}
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids = req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';

	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Department.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Department.findOne({_id:n1},function(err, department){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  department '+ department.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/departments/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Department.findOne({
			_id: id
		}, 
		function(err, department) {
			if (err) {
				return next(err);
			}
			else {
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/department/'+department.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Department.findByIdAndUpdate(id, memupdate, function(err, department) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/departments/edit/'+id);
					}
				});
			}
		}
	);
};