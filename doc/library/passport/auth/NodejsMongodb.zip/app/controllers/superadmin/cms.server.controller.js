var CMS = require('mongoose').model('CMS');
var LogActivity = require('mongoose').model('LogActivity');
var moment = require('moment')

// list cms
exports.list = function(req, res, next) {
	CMS.find({}, function(err, cms) {
		if (err) {
			return next(err);
		}
		else {
			res.render('superadmin/cms/list', {
				pagename : 'cms',
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				cms: cms,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

exports.getContent = function(req, res){
	var code = req.body.code;
	CMS.findOne({
			code: code
		}, 
		function(err, cms) {
			if (err) {
				return next(err);
			}
			else {
				res.send(cms.description);
				return false;			
			}
		}
	);
};

exports.edit = function(req, res, next) {
	var id = req.params.id;
	CMS.findOne({
			_id: id
		}, 
		function(err, cms) {
			if (err) {
				return next(err);
			}
			else {
				res.render('superadmin/cms/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					cms: cms,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	CMS.findByIdAndUpdate(req.body.cms_id, req.body, function(err, cms) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			loginHistoryObj.title = req.session.name+' updated CMS '+ req.body.title;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'CMS Updated Successfully.');
			return res.redirect('/superadmin/cms/list');
		}
	});
};