var CustomerPlan = require('mongoose').model('CustomerPlan');
var moment = require('moment');
var path = require('path');
var appDir = path.dirname(require.main.filename);
var fs = require('fs');

// list customerplan
exports.list = function(req, res, next) {
	CustomerPlan.find({status: {'$ne':'Deleted' }}, function(err, customerplan) {
		if (err) {
			return next(err);
		}
		else {
				var fullUrl = req.protocol + '://' + req.get('host');
				for (var i = 0; i < customerplan.length; i++) {
				var uploadpath = appDir+'/upload/customerplan/'+customerplan[i].photo;
				try {
				  	fs.statSync(uploadpath);
				  	if(customerplan[i].photo!='')
				  	{
				  		customerplan[i].photo = fullUrl+'/customerplan/'+customerplan[i].photo;
				  	}
				  	else
				  	{
				  		customerplan[i].photo = fullUrl+'/customerplan/no_image_user.png';
				  	}
				  	
				}
				catch (e) {
				  	customerplan[i].photo = fullUrl+'/customerplan/no_image_user.png';
				}
			};
			res.render('superadmin/customerplan/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				customerplan : customerplan,
				messages : req.flash('error') || req.flash('info'),
				messages : req.flash('info'),
				moment : moment
			});
		}
	}).sort({created_at:'desc'});
};

exports.add = function(req, res, next) {
	res.render('superadmin/customerplan/add', {
		pagename : 'customerplan',
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
	var fileExt = req.files.photo.name.split('.').pop();
	fileName = fileName+'.'+fileExt;
	var customerplan = new CustomerPlan(req.body);
	customerplan.company_id = req.session.uniqueid;
	customerplan.photo = fileName;
	customerplan.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			sampleFile = req.files.photo;
			sampleFile.mv('./upload/customerplan/'+fileName, function(err) {
				    var date = new Date();
					industry_name=req.body.title;
					loginHistoryObj.title = req.session.name+' added new customerplan '+ industry_name;
					loginHistoryObj.login_id = req.session.historyid;
					loginHistoryObj.posted =date;
					loginHistoryObj.save(function(err) {
					});
				req.flash('info', 'New customerplan Added Successfully.');
				return res.redirect('/superadmin/customerplan/list');
			});
		}
	});
};

exports.edit = function(req, res, next) {
	var id = req.params.id;
	CustomerPlan.findOne({
			_id: id
		}, 
		function(err, customerplan) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
						if(customerplan.photo)
						{
							if(customerplan.photo!=''){
							customerplan.photo = fullUrl+'/customerplan/'+customerplan.photo;
							}
						else {
							customerplan.photo = '';
							}
						}
						else
						{
							customerplan.photo = '';
						}
				res.render('superadmin/customerplan/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					customerplan:customerplan,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};


exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.body.imgUpload=='Yes')
	{
		var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/customerplan/'+fileName, function(err) 
			{	
				if (err)	 
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		CustomerPlan.findByIdAndUpdate(req.body.customerplanid, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated customerplan '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				console.log(loginHistoryObj.login_id);
				console.log(loginHistoryObj);
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Insurance Type Updated Successfully.');
				return res.redirect('/superadmin/customerplan/list');
			}
		});
	}
	else
	{
		CustomerPlan.findByIdAndUpdate(req.body.customerplanid, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Insurance Type Updated Successfully.');
				return res.redirect('/superadmin/customerplan/list');
			}
		});
	}
};


exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids = req.body.iId;
	
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';

	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			CustomerPlan.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							CustomerPlan.findOne({_id:n1},function(err, customerplan){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  customerplan '+ customerplan.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/customerplan/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	CustomerPlan.findOne({
			_id: id
		}, 
		function(err, customerplan) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/customerplan/'+customerplan.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				CustomerPlan.findByIdAndUpdate(id, memupdate, function(err, customerplan) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/customerplan/edit/'+id);
					}
				});
			}
		}
	);
};