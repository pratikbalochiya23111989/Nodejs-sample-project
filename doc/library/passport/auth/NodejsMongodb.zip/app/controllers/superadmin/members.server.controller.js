var Member = require('mongoose').model('Member');
var Company = require('mongoose').model('Company');
var Team = require('mongoose').model('Team');
var Department = require('mongoose').model('Department');

//get all members list
exports.list = function(req, res, next) {
	Member.find({}, function(err, members) {
		if (err) {
			return next(err);
		}
		else {
			var fullUrl = req.protocol + '://' + req.get('host');
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var uploadpath = '';

			var fs = require('fs');
			var stats;
			var sampleFileURL = fullUrl+'/sampleFormat.csv';
			for (var i = 0; i < members.length; i++) {
				var uploadpath = appDir+'/upload/member/'+members[i].photo;
				try {
				  	fs.statSync(uploadpath);
				  	if(members[i].photo!='')
				  	{
				  		members[i].photo = fullUrl+'/member/'+members[i].photo;
				  	}
				  	else
				  	{
				  		members[i].photo = fullUrl+'/member/no_image_user.png';
				  	}
				}
				catch (e) {
				  	members[i].photo = fullUrl+'/member/no_image_user.png';
				}
			};

			res.render('superadmin/members/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				members : members,
				samplefileurl : sampleFileURL,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info')
			});
		}
	}).sort({created_at:'desc'});
};

// import to csv
exports.importcsv = function(req, res, next) {
	var tmp_path = req.files;
	console.log(tmp_path);return false;
	var path = require('path');
	var appDir = path.dirname(require.main.filename);
	var multer	= require('multer');
	var filenametmp = '';
	var storage	= multer.diskStorage({
	  	destination: function (req, file, callback) {
	  		console.log('destination call');
	    	callback(null, './upload/csvfiles');
	  	},
	  	filename: function (req, file, callback) {
	  		console.log(file.originalname);
	  		var uniq_no = Math.floor(Math.random()*89999+10000);
	  		filenametmp = file.originalname;
			filenametmp = uniq_no+filenametmp;
	  		callback(null, filenametmp);
	  	}
	});
	var upload = multer({ storage : storage}).single('sampleFile');
	upload(req,res,function(err) {
		if(err) {
			return next(err);	
		}
		else {
			res.end('Uploaded sucessfully');
		}
		return false;
	});
	//console.log(req.files);
	/*var multer = require('multer');
	var storage	= multer.diskStorage({
	  	destination: function (req, file, callback) {
	  		console.log('call desti');
	    	callback(null, './upload');
	  	},
	  	filename: function (req, file, callback) {
	  		console.log('call filename');
	    	callback(null, file.fieldname + '-' + Date.now());
	  	} 
	});
	var upload = multer({ storage : storage}).single('sampleFile');
	upload(req,res,function(err) {
		if(err) {
			return res.end("Error uploading file.");
		}
		console.log('file uploaded call');
		res.end("File is uploaded");
	});*/
};

// export to csv
exports.exportcsv = function(req, res, next) {
	var async = require('async');
	var json2csv = require('json2csv');
	var fs = require('fs');
	var fields = ['No','ID','Firstname','Lastname','Email','Phone','Age','Sex','Height','Width','Status'];
	Member.find({company_id : req.session.uniqueid}, function(err, members) {
		var allMembersArr = [];
		var cntr = 0;
		async.forEachSeries(members.reverse(), function(n1, callback_s1) {
			var memObj = new Object;
			memObj.No = (cntr+1);
			memObj.ID = n1._id.toString();
			memObj.Firstname = n1.firstname;
			memObj.Lastname = n1.lastname;
			memObj.Email = n1.email;
			memObj.Phone = n1.phone;
			memObj.Age = n1.age;
			memObj.Sex = n1.sex;
			memObj.Height = n1.height;
			memObj.Width = n1.width;
			memObj.Status = n1.status;
			allMembersArr.push(memObj);
			cntr++;
			callback_s1();
		}, function (err) {
			var uniq_no = Math.floor(Math.random()*89999+10000);
			var csv = json2csv({ data: allMembersArr,fields: fields });
			res.attachment(uniq_no+'.csv');
			res.status(200).send(csv);
			return false;	
		});
	});
};

//add new member
// exports.add = function(req, res, next) {
// 	res.render('superadmin/members/add', {
// 		logintype : req.session.type,
// 		loginid : req.session.uniqueid,
// 		loginname : req.session.name,
// 		loginemail : req.session.email,
// 		messages: req.flash('error') || req.flash('info')
// 	});
// };

exports.add = function(req, res, next) {
	Team.find({}, function(err, teams) {
		Department.find({}, function(err, departments){
		res.render('superadmin/members/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			teams : teams,
			departments : departments,
			messages: req.flash('error') || req.flash('info')
		});
	});
  });		
};

exports.create = function(req, res, next) {
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
	var fileExt = req.files.photo.name.split('.').pop();
	fileName = fileName+'.'+fileExt;
	var member = new Member(req.body);
	member.company_id = req.session.uniqueid;
	member.photo = fileName;
	/*var path = require('path');
	var appDir = path.dirname(require.main.filename);
	var multer	= require('multer');

	var filenametmp = '';
	var storage	= multer.diskStorage({
	  	destination: function (req, file, callback) {
	    	callback(null, appDir+'/upload/member');
	  	},
	  	filename: function (req, file, callback) {
	  		var uniq_no = Math.floor(Math.random()*89999+10000);
	  		filenametmp = file.originalname;
			filenametmp = uniq_no+filenametmp;
	  		callback(null, filenametmp);
	  	}
	});
	var upload = multer({ storage : storage}).single('photo');
	upload(req,res,function(err) {
		if(err) {
			return next(err);	
		}
		else {*/
			req.body.member_id = req.session.uniqueid;
			/*req.body.photo = filenametmp;*/
			req.body.validic_uid = '';
			req.body.validic_access_token = '';
			req.body.age = '';
			req.body.sex = 'Male';
			req.body.height = '';
			req.body.weight = '';
			req.body.photo = '';
			member.save(function(err) {
				if (err) {
					return next(err);
				}
				else {
					sampleFile = req.files.photo;
					sampleFile.mv('./upload/member/'+fileName, function(err) {
				 //    var date = new Date();
					// industry_name=req.body.title;
					// loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
					// loginHistoryObj.login_id = req.session.historyid;
					// loginHistoryObj.posted =date;
					// console.log(loginHistoryObj.login_id);
					// console.log(loginHistoryObj);
					// loginHistoryObj.save(function(err) {
					// });
				req.flash('info', 'New Challenge Added Successfully.');
				return res.redirect('/superadmin/members/list');
			});
				}
			});	
		/*}
	});*/
};

// remove photo
exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Member.findOne({
			_id: id
		}, 
		function(err, member) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/member/'+member.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Member.findByIdAndUpdate(id, memupdate, function(err, member) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/members/edit/'+id);
					}
				});
			}
		}
	);
};

// edit member
exports.edit = function(req, res, next) {
	var id = req.params.id;
	Member.findOne({
			_id: id
		}, 
		function(err, member) {
			if (err) {
				return next(err);
			}
			else {
				Company.find({status : 'Active'}, function(err, companies) {
					var fullUrl = req.protocol + '://' + req.get('host');
					if(member.photo!=''){
						member.photo = fullUrl+'/member/'+member.photo;
					}
					else {
						member.photo = '';
					}
				Department.find({status : 'Active'}, function(err, departments){
					Team.find({status : 'Active'}, function(err, teams){
						res.render('superadmin/members/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						companies : companies,
						departments:departments,
						teams:teams,
						member: member,
						messages: req.flash('error') || req.flash('info')
					});
					});
					
				});
				}).sort({created_at:'desc'});
			}
		}
	);
};

// update member
exports.update = function(req, res, next) {
	 if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.file.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.file;	
		sampleFile.mv('./upload/member/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Member.findByIdAndUpdate(req.body.member_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Member Updated Successfully.');
				return res.redirect('/superadmin/members/list');
			}
		});
	 }
	 else
	 {
	 	Member.findByIdAndUpdate(req.body.member_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Member Updated Successfully.');
				return res.redirect('/superadmin/members/list');
			}
		});
	 }
};

// score
exports.score = function(req, res, next) {
	res.render('superadmin/members/score', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.list_action = function(req, res, next) {
	var action = req.body.btnAction
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
			Member.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Updated Successfully.');
						return res.redirect('/superadmin/members/list');
					}
				}
			)
			break;
		case "Deleted":
			Member.deleteMany(
				{ '_id':{ $in : req.body.iId } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Deleted Successfully.');
						return res.redirect('/superadmin/members/list');
					}
				}
			)
			break;
	}	
};