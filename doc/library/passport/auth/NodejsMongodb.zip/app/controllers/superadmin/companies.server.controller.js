var Company = require('mongoose').model('Company');
var Department = require('mongoose').model('Department');
var Team = require('mongoose').model('Team');
var Member = require('mongoose').model('Member');
var State = require('mongoose').model('State');
var Country = require('mongoose').model('Country');
var Industry = require('mongoose').model('Industry');
var EmailTemplate = require('mongoose').model('EmailTemplate');
var InsuranceTypesPlans = require('mongoose').model('InsuranceTypesPlans');
var InsuranceTypes = require('mongoose').model('InsuranceTypes');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var crypto = require('crypto');
var async = require('async');
var moment = require('moment')

// list administrator
exports.list = function(req, res, next) {
	if(req.session.tab=='step2')
	{
		delete req.session.tab;
	}
	else if(req.session.tab=='step3')
	{
		delete req.session.tab;
	}
	else if(req.session.tab=='step4')
	{
		delete req.session.tab;
	}
	Company.find({status:{$ne : 'Deleted'}}, function(err, companies) {
		if (err) {
			return next(err);
		}
		else {
			
			res.render('superadmin/companies/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				companies: companies,
				tab:req.session.tab,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new question 
exports.add = function(req, res, next) {
	Industry.find({status:'Active'}, function(err, industries) {
		InsuranceTypesPlans.find({status:'Active',type:'Group'}, function(err, insurancetypeplans) {
		InsuranceTypes.find({status:'Active',type:'Group'}, function(err, insurancetypes) {
		Country.find({status:'Active'}, function(err, countries) {
			State.find({status:'Active'}, function(err, states) {
				res.render('superadmin/companies/add', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					industries : industries,
					countries : countries,
					insurancetypes:insurancetypes,
					insurancetypeplans:insurancetypeplans,
					states : states,
					messages: req.flash('error') || req.flash('info')
				});
			});
			});
		});
		});
	}).sort({created_at:'desc'});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var md5 = require('md5');
	var originalPassword = req.body.password;
	req.body.password = md5(req.body.password);
	req.body.insurance_id = req.session.uniqueid;
	var company = new Company(req.body);
	company.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new company '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Company Added Successfully.');
			return res.redirect('/company/list');
			/*EmailTemplate.findOne({code: 'SIGNUP'}, function(err, emailcontent) {
				var text = emailcontent.content;
				text = text.replace("#NAME#", (req.body.firstname+' '+req.body.lastname)).replace("#EMAIL#", req.body.hr_email).replace("#PASSWORD#", originalPassword);
				
				var api_key = 'key-43cf4c016eb85a389fc22df0dd7bf6f4';
				var domain = 'dotzapper.com';
				var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});
				 
				var data = {
				  	from: 'Brio <demo1.testing1@gmail.com>',
				  	to: req.body.hr_email,
				  	subject: 'Thank you for sign up at Brio',
				  	html: text
				};
				 
				mailgun.messages().send(data, function (error, body) {
				  	req.flash('info', 'New Company Added Successfully.');
					return res.redirect('/admin/company/list');
				});
			});*/
		}
	});
};
exports.createdepartment = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.photo.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.photo;	
	sampleFile.mv('./upload/department/'+fileName, function(err) 
		{	
			if (err)	  
				return res.status(500).send(err);	
		});
	req.body.photo=fileName;
	var department = new Department(req.body);
	department.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new department '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Department Added Successfully.');
			return res.redirect('/company/edit/'+req.session.companyid);
		}
	});
};

exports.createteam = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.photo.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.photo;	
	sampleFile.mv('./upload/team/'+fileName, function(err) 
		{	
			if (err)	  
				return res.status(500).send(err);	
		});
	req.body.photo=fileName;
	var team = new Team(req.body);
	team.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			team_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new team '+ team_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Team Added Successfully.');
			return res.redirect('/company/edit/'+req.session.companyid);
		}
	});
};
exports.edit = function(req, res, next) {
	var id = req.params.id;
	console.log(req.session.tab);
	Industry.find({status:'Active'}, function(err, industries) {
		Company.findOne({
				_id: id
			}, 
			function(err, com) {
				if (err) {
					return next(err);
				}
				else {
					Department.find({status:{$ne : 'Deleted'},company_id:id}, function(err, departments) {
						Team.find({status:{$ne : 'Deleted'},company_id:id}, function(err, team) {
							Member.find({status:{$ne : 'Deleted'},company_id:id}, function(err, members) {
								var path = require('path');
							 	var appDir = path.dirname(require.main.filename);
							 	var uploadpath = '';
								var fullUrl = req.protocol + '://' + req.get('host');
								var fs = require('fs');
								for (var i = 0; i < departments.length; i++) {
									var uploadpath = appDir+'/upload/department/'+departments[i].photo;
									try {
									  	fs.statSync(uploadpath);
									  	if(departments[i].photo!='')
									  	{
									  		departments[i].photo = fullUrl+'/department/'+departments[i].photo;
									  	}
									  	else
									  	{
									  		departments[i].photo = fullUrl+'/department/no_image_user.png';
									  	}
									  	
									}
									catch (e) {
									  	departments[i].photo = fullUrl+'/department/no_image_user.png';
									}
								};
								for (var i = 0; i < team.length; i++) {
									var uploadpath = appDir+'/upload/team/'+team[i].photo;
									try {
									  	fs.statSync(uploadpath);
									  	if(team[i].photo!='')
									  	{
									  		team[i].photo = fullUrl+'/team/'+team[i].photo;
									  	}
									  	else
									  	{
									  		team[i].photo = fullUrl+'/team/no_image_user.png';
									  	}
									  	
									}
									catch (e) {
									  	team[i].photo = fullUrl+'/team/no_image_user.png';
									}
								};
								for (var i = 0; i < members.length; i++) {
									var uploadpath = appDir+'/upload/member/'+members[i].photo;
									try {
									  	fs.statSync(uploadpath);
									  	if(members[i].photo!='')
									  	{
									  		members[i].photo = fullUrl+'/member/'+members[i].photo;
									  	}
									  	else
									  	{
									  		members[i].photo = fullUrl+'/member/no_image_user.png';
									  	}
									  	
									}
									catch (e) {
									  	members[i].photo = fullUrl+'/member/no_image_user.png';
									}
								};
								Country.find({status:'Active'}, function(err, countries) {
									State.find({status:'Active',country_id:com.country_id}, function(err, states) {
										res.render('superadmin/companies/edit', {
											logintype : req.session.type,
											loginid : req.session.uniqueid,
											loginname : req.session.name,
											loginemail : req.session.email,
											com: com,
											departments:departments,
											team,team,
											members:members,
											tab:req.session.tab,
											industries : industries,
											countries : countries,
											states : states,
											messages: req.flash('error') || req.flash('info'),
											messages:req.flash('info'),
											moment: moment
										});
									});
								});
							}).sort({created_at:'desc'});
						}).sort({created_at:'desc'});
					}).sort({created_at:'desc'});

				}
			}
		);
	}).sort({created_at:'desc'});	
	
};
exports.updatedepartteammember = function(req, res, next) {
	req.session.tab=req.params.tab;
	var id = req.params.id;
	req.session.companyid=req.params.companyid;
	if(req.session.tab=='step2')
	{
		Department.findOne({
				_id: id
			}, 
			function(err, departments) {
				if (err) {
					return next(err);
				}
				else {
					var fullUrl = req.protocol + '://' + req.get('host');
					if(departments.photo)
					{
						if(departments.photo!=''){
							departments.photo = fullUrl+'/department/'+departments.photo;
						}
						else {
							departments.photo = '';
						}
					}
					else
					{
						departments.photo = '';
					}
					res.render('superadmin/companies/edit_department', {
						logintype : 'ajax',
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						departments:departments,
						tab:req.session.tab,
						companyid:req.session.companyid,
						messages: req.flash('error') || req.flash('info'),
						messages:req.flash('info'),
						moment: moment
					});
				}
			});
	}
	if(req.session.tab=='step3')
	{
		Team.findOne({
				_id: id
			}, 
			function(err, team) {
				if (err) {
					return next(err);
				}
				else {
					var fullUrl = req.protocol + '://' + req.get('host');
					if(team.photo)
					{
						if(team.photo!=''){
							team.photo = fullUrl+'/team/'+team.photo;
						}
						else {
							team.photo = '';
						}
					}
					else
					{
						team.photo = '';
					}
					Department.find({status:'Active'}, function(err, departments) {
					res.render('superadmin/companies/edit_team', {
						logintype : 'ajax',
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						team:team,
						departments:departments,
						tab:req.session.tab,
						companyid:req.session.companyid,
						messages: req.flash('error') || req.flash('info'),
						messages:req.flash('info'),
						moment: moment
					});
				});
				}
			});
	}
		
};
exports.editdepartment = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	 if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/department/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Department.findByIdAndUpdate(req.body.id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				depart_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated department '+ depart_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Department Updated Successfully.');
				return res.redirect('/company/edit/'+req.body.company_id);
			}
		});
	 }
	 else
	 {
	 	Department.findByIdAndUpdate(req.body.id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated insurance type '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Department Updated Successfully.');
				return res.redirect('/company/edit/'+req.body.company_id);
			}
		});
	 }
};
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	Company.findByIdAndUpdate(req.body.company_id, req.body, function(err, company) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' updated company '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Company Updated Successfully.');
			return res.redirect('/company/list');
		}
	});
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Company.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Company.findOne({_id:n1},function(err, company){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  company '+ company.firstname +' '+ company.lastname;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/company/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.listdepartmentaction = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	req.session.tab='step2';
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Department.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Department.findOne({_id:n1},function(err, department){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  department '+ department.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/company/edit/'+req.body.company_id);
						});
						
					}
				}
			)
			break;
	}
	
};

exports.add_member = function(req, res, next) {
	res.render('superadmin/companies/add_member', {
		messages: req.flash('error') || req.flash('info')
	});
};

exports.edit_member = function(req, res, next) {
	res.render('superadmin/companies/edit_member', {
		messages: req.flash('error') || req.flash('info')
	});
};

exports.removephoto = function(req, res, next) {
	var tab = req.session.tab;
	var companyid=req.session.companyid;
	var id=req.params.id;
	if(tab=='step2')
	{
		Department.findOne({
			_id: id
		}, 
			function(err, departments) {
				if (err) {
					return next(err);
				}
				else {
					var fs = require('fs');
					var path = require('path');
					var appDir = path.dirname(require.main.filename);
					var filePath = appDir+'/upload/department/'+departments.photo;
					fs.unlinkSync(filePath);

					var memupdate = new Object;
					memupdate.photo = '';
					Department.findByIdAndUpdate(id, memupdate, function(err, departments) {
						if (err) {
							return next(err);
						}
						else {
							return res.redirect('/company/'+id+'/'+tab+'/'+companyid+'/update');
						}
					});
				}
			}
		);
	}
};

exports.tabviceview = function(req, res, next) {
	req.session.tab=req.params.tab;
		req.session.companyid=req.params.id;
		var id=req.session.companyid;
		if(req.session.tab=='step2')
		{
			res.render('superadmin/companies/add_department',{
				logintype : 'ajax',
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				tab:req.session.tab,
				companyid:req.session.companyid
			});
		}
		if(req.session.tab=='step3')
		{
			Department.find({
				company_id: id
			}, 
				function(err, departments) {
					if (err) {
					return next(err);
					}
					else {
						res.render('superadmin/companies/add_team',{
							logintype : 'ajax',
							loginid : req.session.uniqueid,
							loginname : req.session.name,
							loginemail : req.session.email,
							tab:req.session.tab,
							departments:departments,
							companyid:req.session.companyid
						});
					}
			});
		}
		if(req.session.tab=='step4')
		{
			res.render('superadmin/companies/add_company_member',{
				logintype : 'ajax',
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				tab:req.session.tab,
				companyid:req.session.companyid
			});
		}
};