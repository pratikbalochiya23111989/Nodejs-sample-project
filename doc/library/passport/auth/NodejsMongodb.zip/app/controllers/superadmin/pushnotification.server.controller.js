var PushNotification = require('mongoose').model('PushNotification');
var Policy_Holder=require('mongoose').model('Policy_holder');
var Member = require('mongoose').model('Member');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var moment = require('moment')

// list administrator
exports.list = function(req, res, next) {
	PushNotification.find({}, function(err, pushnotification) {
		Member.find({}, function(err, member) {
		if (err) {
			return next(err);
		}
		else {
			
			res.render('superadmin/pushnotification/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				pushnotification: pushnotification,
				member:member,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			
			});
		}
		});
	}).sort({created_at:'desc'});
};

//add new administrator 
exports.add = function(req, res, next) {
	Member.find({status:'Active'}, function(err, member) {
		if (err) {
			return next(err);
		}
		else {
		res.render('superadmin/pushnotification/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			member:member,
			messages: req.flash('error') || req.flash('info'),
			messages:req.flash('info'),
			moment: moment
		});
		}
	});
};

exports.create = function(req, res, next) {
	var async = require('async');

	// code for ios push notification
	var apn = require('apn');
	var path = require('path');
	var appDir = path.dirname(require.main.filename);
	var p8FilePath = appDir+'/public/AuthKey_N7D8LP36YD.p8';
	var options = {
		token: {
		    key: p8FilePath,
		    keyId: "N7D8LP36YD",
		    teamId: "JEVW5NUQGW"
		},
		production: false
	};
	var apnProvider = new apn.Provider(options);
	// end of code for ios push notification

	// code for android push notification
	var FCM = require('fcm-node');
    var serverKey = 'AIzaSyClYcBgo2bpV3A0qOq4H0VAgULipnIoVX4'; //put your server key here
    var fcm = new FCM(serverKey);
	// end of code for android push notification

	req.body.senddatetime = req.body.senddatetime.replace("/", "-");
	req.body.senddatetime = req.body.senddatetime.replace("/", "-");
	var pushnotification = new PushNotification(req.body);
	var loginHistoryObj = new LogActivity();
	pushnotification.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			loginHistoryObj.title = req.session.name+' added new pushnotification '+ req.body.title;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
				if(req.body.usertype=='Member'){
					Member.find({_id: {$in: req.body.users}}, function(err, members) {
						async.forEachSeries(members, function(singleRec, callback_singleRec) {
							if(singleRec.device_type && req.body.types=='Manual'){
								if(singleRec.device_type=='Android'){
									var message = { //this may vary according to the message type (single recipient, multicast, topic, et cetera)
								        to: singleRec.device_token, 
								        collapse_key: 'green',
								        
								        notification: {
								            body: req.body.title
								        },
								        
								        data: {  //you can send only notification or only data(or include both)
								            my_key: 'my value',
								            my_another_key: 'my another value'
								        }
								    };
								    fcm.send(message, function(err, response){
								        callback_singleRec();
								    });
								}
								else if(singleRec.device_type=='IOS'){
									var deviceToken = singleRec.device_token;
									var note = new apn.Notification();

									note.expiry = Math.floor(Date.now() / 1000) + 3600; // Expires 1 hour from now.
									note.badge = 3;
									note.sound = "ping.aiff";
									note.alert = req.body.title;
									note.payload = {'messageFrom': 'Aktivo'};
									note.topic = "com.activolabdemo";

									apnProvider.send(note, deviceToken).then((result) => {
								  		callback_singleRec();
									});
								}
								else {
									callback_singleRec();
								}
							}
							else {
								callback_singleRec();
							}
						}, function (err) {
							req.flash('info', 'New PushNotification Added Successfully.');
							return res.redirect('/pushnotification/list');
						});
					});
				}
				else {

				}
			});
		}
	});
};


exports.list_action = function(req, res, next) {
	var action = req.body.btnAction;
	var loginHistoryObj = new LogActivity();
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	async.forEachSeries(req.body.iId, function(n1, callback_s1) {
		var date = new Date();
		if(action=='Deleted')
		{
			perform_action="deleted";
		}
			
		PushNotification.findOne({_id:n1},function(err, pushnotification){
			var loginHistoryObj = new LogActivity();
			loginHistoryObj.title = req.session.name+' '+perform_action+'  pushnotification '+ pushnotification.title;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
				callback_s1();
			});

		});
		
	}, function (err) {
		if(action=="Deleted")
		{
			PushNotification.deleteMany(
					{ '_id':{ $in : req.body.iId } },
					function (err,val) {
						if (err) {
							return next(err);
						}
						else {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							return res.redirect('/pushnotification/list');
						}
					}
				);
		}
	});
	
};

exports.usersList = function(req, res, next) {
	var id=req.body.id;
	PushNotification.findOne({_id:id,status: {'$ne':'Deleted' }}, function(err, pushnotification) {
		length=(pushnotification.users).length;
		if (err) {
			return next(err);
		}
		else {
			var pushUsers="<tr><th width='20%' class='tbl_pad_left' style='font: bold !important;color: black;''>Sr No.</th><th width='40%' colspan='6' class='tbl_pad_left' style='font: bold !important;color: black;''>Name</th></tr>";
			var pushUsersCnt = 1;
			async.forEachSeries(pushnotification.users, function(n1, callback_s1) {
				Member.findOne({_id :n1}, function(err, member) {
					pushUsers+= "<tr><td class='tbl_pad_left'>"+pushUsersCnt+"</td><td class='tbl_pad_left'>"+member.firstname+" "+member.lastname+"</td></tr>";
					pushUsersCnt++;
					callback_s1();
			 	});	
			}, function (err) {
				res.send(pushUsers);
			});
		}
	});
};
exports.add_user = function(req, res, next) {
	var usertype=req.body.values;
	var str='';
	if(usertype=='Policy_Holder')
	{
		Policy_Holder.find({status:'Active'},function(err,users){
			for(var i=0;i <users.length;i++)
			{
				str+='<option value='+users[i]._id+'>'+users[i].firstname+' '+users[i].lastname+'</option>'
			}
			res.send(str);
		});
	}
	else
	{
		Member.find({status:'Active'},function(err,users){
			for(var i=0;i <users.length;i++)
			{
				str+='<option value='+users[i]._id+'>'+users[i].firstname+' '+users[i].lastname+'</option>'
			}
			res.send(str);
		});
	}
};
