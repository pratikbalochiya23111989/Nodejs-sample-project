var InsuranceTypes = require('mongoose').model('InsuranceTypes');
var moment = require('moment');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
// list insurancetypes
exports.list = function(req, res, next) {
	InsuranceTypes.find({status: {'$ne':'Deleted' },type : 'Group'}, function(err, insurancetypes) {
		if (err) {
			return next(err);
		}
		else {
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var fullUrl = req.protocol + '://' + req.get('host');
			for (var i = 0; i < insurancetypes.length; i++) {
				var uploadpath = appDir+'/upload/insurancetype/'+insurancetypes[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(insurancetypes[i].photo!='')
                      {
                          insurancetypes[i].photo = fullUrl+'/insurancetype/'+insurancetypes[i].photo;
                      }
                      else
                      {
                          insurancetypes[i].photo = fullUrl+'/insurancetype/no_image_user.png';
                      }
				}
				catch (e) {
				  	insurancetypes[i].photo = fullUrl+'/insurancetype/no_image_user.png';
				}
			};

		res.render('superadmin/insuranceTypes/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				insurancetypes : insurancetypes,
				messages : req.flash('error') || req.flash('info'),
				messages : req.flash('info'),
				moment : moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new insurancetypes 
exports.add = function(req, res, next) {
	res.render('superadmin/insuranceTypes/add', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};


// edit insurancetypes
exports.edit = function(req, res, next) {
	 var id = req.params.id;
	 InsuranceTypes.findOne({
	 		_id: id
		}, 
		function(err, insurancetype) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
				if(insurancetype.photo){
					if(insurancetype.photo!=''){
						insurancetype.photo = fullUrl+'/insurancetype/'+insurancetype.photo;
					}
					else {
					insurancetype.photo = '';
					}
				}
				else{
					insurancetype.photo = '';
				}
				res.render('superadmin/insuranceTypes/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					insurancetype:insurancetype,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.photo.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.photo;	
	sampleFile.mv('./upload/insurancetype/'+fileName, function(err) 
		{	
			if (err)	  
				return res.status(500).send(err);	
		});
	req.body.photo=fileName;
	var insurancetype=new InsuranceTypes(req.body);
	insurancetype.save(function(err){
		if(err)
		{
			return next(err);
		}
		else
		{
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new insurance type '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Insurance Type added Successfully.');
			return res.redirect('/superadmin/insuranceTypes/list');
		}
	});
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	 if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/insurancetype/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		InsuranceTypes.findByIdAndUpdate(req.body.insurance_type_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated insurance type '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Insurance Type Updated Successfully.');
				return res.redirect('/superadmin/insuranceTypes/list');
			}
		});
	 }
	 else
	 {
	 	InsuranceTypes.findByIdAndUpdate(req.body.insurance_type_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Insurance Type Updated Successfully.');
				return res.redirect('/superadmin/insuranceTypes/list');
			}
		});
	 }
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
    var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			InsuranceTypes.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							InsuranceTypes.findOne({_id:n1},function(err, insurancetype){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  insurancetype '+ insurancetype.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/insuranceTypes/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	InsuranceTypes.findOne({
			_id: id
		}, 
		function(err, insurancetype) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/insurancetype/'+insurancetype.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				InsuranceTypes.findByIdAndUpdate(id, memupdate, function(err, insurancetype) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/insuranceTypes/edit/'+id);
					}
				});
			}
		}
	);
};