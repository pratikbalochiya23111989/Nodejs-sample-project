var Announcement = require('mongoose').model('Announcement');
var moment = require('moment');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');

// list announcement
exports.list = function(req, res, next) {
	Announcement.find({status:{$ne : 'Deleted'}}, function(err, announcement) {
		if (err) {
			return next(err);
		}
		else {
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var fullUrl = req.protocol + '://' + req.get('host');
			for (var i = 0; i < announcement.length; i++) {
				var uploadpath = appDir+'/upload/announcement/'+announcement[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(announcement[i].photo!='')
				  	{
				  		announcement[i].photo = fullUrl+'/announcement/'+announcement[i].photo;
				  	}
				  	else
				  	{
				  		announcement[i].photo = fullUrl+'/announcement/no_image_user.png';
				  	}
				  }	
				catch (e) {
				  	announcement[i].photo = fullUrl+'/announcement/no_image_user.png';
				}
			};

		res.render('superadmin/announcement/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				announcement : announcement,
				messages : req.flash('error') || req.flash('info'),
				messages : req.flash('info'),
				moment : moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new announcement 
exports.add = function(req, res, next) {
	res.render('superadmin/announcement/add', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};


// edit announcement
exports.edit = function(req, res, next) {
	 var id = req.params.id;
	 Announcement.findOne({
	 		_id: id
		}, 
		function(err, announcement) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
					if(announcement.photo){
							if(announcement.photo!=''){
							announcement.photo = fullUrl+'/announcement/'+announcement.photo;
								// if (!fs.existsSync(path)) {
								//    announcement.photo = '';
								// }
							}
							else {
							announcement.photo = '';
							}
					}
					else{
					announcement.photo = '';
					}
				res.render('superadmin/announcement/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					announcement:announcement,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.file.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.file;	
	sampleFile.mv('./upload/announcement/'+fileName, function(err) 
		{	
			if (err)	  
				return res.status(500).send(err);	
		});
	req.body.photo=fileName;
	var announcement=new Announcement(req.body);
	announcement.save(function(err){
		if(err)
		{
			return next(err);
		}
		else
		{
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new announcement '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Announcement added Successfully.');
			return res.redirect('/superadmin/announcement/list');
		}
	});
};


exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	 if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.file.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.file;
		sampleFile.mv('./upload/announcement/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Announcement.findByIdAndUpdate(req.body.announcement_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated announcement '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				console.log(loginHistoryObj.login_id);
				console.log(loginHistoryObj);
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Announcement Updated Successfully.');
				return res.redirect('/superadmin/announcement/list');
			}
		});
	 }
	 else
	 {
	 	Announcement.findByIdAndUpdate(req.body.announcement_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Announcement Updated Successfully.');
				return res.redirect('/superadmin/announcement/list');
			}
		});
	 }
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	async.forEachSeries(req.body.iId, function(n1, callback_s1) {
		var date = new Date();
		Announcement.findOne({_id:n1},function(err, announcement){
			var loginHistoryObj = new LogActivity();
			loginHistoryObj.title = req.session.name+' '+'deleted'+' announcement '+ announcement.title;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
				callback_s1();
			});

		});
		
	}, function (err) {
		var str = (req.body.iId.length>1) ? 'Records' : 'Record';					
		switch(action)
		{
			case "Deleted":
				Announcement.deleteMany(
					{ '_id':{ $in : req.body.iId } },
					function (err,val) {
						if (err) {
							return next(err);
						}
						else {
							
								if(err){
									return next(err);
								}
								else {
									req.flash('info', str+' Deleted Successfully.');
								}
								return res.redirect('/superadmin/announcement/list');
						
							
						}
					}
				)
				break;
		}
	});
	
	
};

exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Announcement.findOne({
			_id: id
		}, 
		function(err, announcement) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/announcement/'+announcement.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Announcement.findByIdAndUpdate(id, memupdate, function(err, announcement) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/announcement/edit/'+id);
					}
				});
			}
		}
	);
};