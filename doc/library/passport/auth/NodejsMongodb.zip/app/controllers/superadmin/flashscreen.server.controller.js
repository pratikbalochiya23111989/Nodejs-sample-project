var FLASHSCREEN = require('mongoose').model('FlashScreen');
var LogActivity = require('mongoose').model('LogActivity');
var moment = require('moment');

// list flashscreen
exports.list = function(req, res, next) {
	FLASHSCREEN.find({}, function(err, flashscreen) {
		if (err) {
			return next(err);
		}
		else {
				var path = require('path');
			 	var appDir = path.dirname(require.main.filename);
				var fullUrl = req.protocol + '://' + req.get('host');
				var fs = require('fs');
				for (var i = 0; i < flashscreen.length; i++) {
				var uploadpath = appDir+'/upload/flashscreen/'+flashscreen[i].image;

				try {
				  	fs.statSync(uploadpath);
				  	if(flashscreen[i].image!='')
				  	{
				  		flashscreen[i].image = fullUrl+'/flashscreen/'+flashscreen[i].image;
				  	}
				  	else
				  	{
				  		flashscreen[i].image = fullUrl+'/flashscreen/no_image_user.png';
				  	}
				  	
				}
				catch (e) {
				  	flashscreen[i].image = fullUrl+'/flashscreen/no_image_user.png';
				}
				// console.log(flashscreen[i].image);
			};
			res.render('superadmin/flashscreen/list', {
				pagename : 'flashscreen',
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				flashscreen: flashscreen,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

exports.edit = function(req, res, next) {
	var id = req.params.id;
	FLASHSCREEN.findOne({
			_id: id
		}, 
		function(err, flashscreen) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
					if(flashscreen.image)
						{
							if(flashscreen.image!=''){
								flashscreen.image = fullUrl+'/flashscreen/'+flashscreen.image;
							}
							else {
								flashscreen.image = '';
								}
						}
					else
					{
						flashscreen.image = '';
					}
				res.render('superadmin/flashscreen/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					flashscreen: flashscreen,
					messages: req.flash('error') || req.flash('info'),
					moment: moment
				});
			}
		}
	);
};


exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	 if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.file.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.file;	
		sampleFile.mv('./upload/flashscreen/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.image=fileName;
		FLASHSCREEN.findByIdAndUpdate(req.body.flashscreen_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated flashscreen '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'FlashScreen Updated Successfully.');
				return res.redirect('/superadmin/flashscreen/list');
			}
		});
	 }
	 else
	 {
	 	FLASHSCREEN.findByIdAndUpdate(req.body.flashscreen_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated flashscreen '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'FlashScreen Updated Successfully.');
				return res.redirect('/superadmin/flashscreen/list');
			}
		});
	 }
};


exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	FLASHSCREEN.findOne({
			_id: id
		}, 
		function(err, flashscreen) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/flashscreen/'+flashscreen.image;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.image = '';
				FLASHSCREEN.findByIdAndUpdate(id, memupdate, function(err, flashscreen) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/flashscreen/edit/'+id);
					}
				});
			}
		}
	);
};