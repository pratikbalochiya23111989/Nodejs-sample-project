var Industry = require('mongoose').model('Industry');
var LogActivity = require('mongoose').model('LogActivity');
var Superadmin = require('mongoose').model('Superadmin');
var async = require('async');
var moment = require('moment')

// list industry
exports.list = function(req, res, next) {
   	  Industry.find({status: {'$ne':'Deleted'},type : 'Group'}, function(err, industry) {
		if (err) {
			return next(err);
		}
		else {
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var fullUrl = req.protocol + '://' + req.get('host');
			for (var i = 0; i < industry.length; i++) {
				var uploadpath = appDir+'/upload/industry/'+industry[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(industry[i].photo!='')
                      {
                          industry[i].photo = fullUrl+'/industry/'+industry[i].photo;
                      }
                      else
                      {
                          industry[i].photo = fullUrl+'/industry/no_image_user.png';
                      }
				}
				catch (e) {
				  	industry[i].photo = fullUrl+'/industry/no_image_user.png';
				}
			};

			res.render('superadmin/industry/list', {
				pagename : 'industry',
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				industry: industry,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};


exports.add = function(req, res, next) {
	res.render('superadmin/industry/add', {
		pagename : 'industry',
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};
// create new industry
exports.create = function(req, res, next) {	
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.photo.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.photo;	
	sampleFile.mv('./upload/industry/'+fileName, function(err) 
		{	
			if (err)	  
				return res.status(500).send(err);	
		});
	req.body.photo=fileName;
	var industry=new Industry(req.body);
	industry.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new industry '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Industry Added Successfully.');
			return res.redirect('/superadmin/industry/list');
			
		}
	});
};

// edit industry
exports.edit = function(req, res, next) {
	var id = req.params.id;
	Industry.findOne({
			_id: id
		}, 
		function(err, industry) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
					if(industry.photo!=''){
						industry.photo = fullUrl+'/industry/'+industry.photo;
					}
					else {
						industry.photo = '';
					}
				res.render('superadmin/industry/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					industry: industry,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};
//Update industry
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/industry/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Industry.findByIdAndUpdate(req.body.industry_id, req.body, function(err, user) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated  industry '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Industry Updated Successfully.');
				return res.redirect('/superadmin/industry/list');
			}
		});
	}
	else
	 {
	 	Industry.findByIdAndUpdate(req.body.industry_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Industry Type Updated Successfully.');
				return res.redirect('/superadmin/industry/list');
			}
		});
	 }
};
//list actions
exports.list_action = function(req, res, next) {
	req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Industry.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
								
							Industry.findOne({_id:n1},function(err, industry){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  industry '+ industry.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/industry/list');
						});
						
					}
				}
			)
			break;
	}
	
};
//remove photo
exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Industry.findOne({
			_id: id
		}, 
		function(err, industry) {
			if (err) {
				console.log(err);
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/industry/'+industry.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Industry.findByIdAndUpdate(id, memupdate, function(err, industry) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/industry/edit/'+id);
					}
				});
			}
		}
	);
};