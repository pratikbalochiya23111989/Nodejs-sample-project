var Superadmin = require('mongoose').model('Superadmin'),
Administrator = require('mongoose').model('Administrator'),
Company = require('mongoose').model('Company'),
Member = require('mongoose').model('Member'),
MemberSocial = require('mongoose').model('MemberSocial'),
MemberSocialMedia = require('mongoose').model('MemberSocialMedia'),
MemberSocialMediaFeedback = require('mongoose').model('MemberSocialMediaFeedback'),
MemberSocialPreview = require('mongoose').model('MemberSocialPreview'),
MemberSocialShare = require('mongoose').model('MemberSocialShare');
var moment = require('moment');

exports.postListShareUsers = function(req, res){
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host')+'/img/avatar/avatar.jpg';
	var shareUserStr = '';

	MemberSocialShare.find({social_timeline_id:req.body.social_id},function(err,socialShare){
		async.forEachSeries(socialShare, function(n1, callback_s1) {
			Member.findOne({ _id: n1.member_id }, function(err, memberInfo) {
				shareUserStr+= "<tr><td><center><img src='"+fullUrl+"' class='avatar img-circle' alt='avatar'></center></td><td>Member</td><td>"+memberInfo.firstname+"</td><td><center><span style='background-color: #121D51;border-radius: 25%;color: #fff;padding: 15px;'>"+n1.share_datetime.length+"</span></center></td><td>"+n1.share_datetime.join('<br>')+"</td></tr>";
				callback_s1();
			});
		}, function () {
			var commentObj = {
				'tableInfo': shareUserStr,
				'totalRecords': socialShare.length
			}
			res.json(commentObj);
			return false;
		});
	});
};

// post preview user list
exports.postListPreviewUsers = function(req, res, next) {
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host')+'/img/avatar/avatar.jpg';
	var previewUserStr = '';

	MemberSocialPreview.find({social_timeline_id:req.body.social_id},function(err,socialPreview){
		async.forEachSeries(socialPreview, function(n1, callback_s1) {
			Member.findOne({ _id: n1.member_id }, function(err, memberInfo) {
				previewUserStr+= "<tr><td><center><img src='"+fullUrl+"' class='avatar img-circle' alt='avatar'></center></td><td>Member</td><td>"+memberInfo.firstname+"</td><td><center><span style='background-color: #121D51;border-radius: 25%;color: #fff;padding: 15px;'>"+n1.preview_datetime.length+"</span></center></td><td>"+n1.preview_datetime.join('<br>')+"</td></tr>";
				callback_s1();
			});
		}, function () {
			var commentObj = {
				'tableInfo': previewUserStr,
				'totalRecords': socialPreview.length
			}
			res.json(commentObj);
			return false;
		});
	});
};

exports.loadSinglePost = function(req,res){
	var social_id = req.body.social_id;
	var fullUrl = req.protocol + '://' + req.get('host');
	MemberSocial.findOne({_id:social_id},function(err, singlePost){
		var socialObj = new Object;
		socialObj._id = singlePost._id;
		socialObj.caption_title = singlePost.caption_title;
		MemberSocialMedia.findOne({ social_timeline_id: singlePost._id }, function(err, postMedia) {
			if(postMedia){
				var foldertype = (postMedia.media_type=='Image') ? 'image' : 'video';
				socialObj.media_id = postMedia._id;
				socialObj.media_type = postMedia.media_type;

				if(postMedia.media_type=='Image'){
					socialObj.file = (socialObj.file!='') ? fullUrl+'/socialmedia/'+foldertype+'/'+postMedia.file : '';
				}
				else if(postMedia.media_type=='Video'){
					socialObj.file = fullUrl+'/img/videoPlaceHolder.jpg';
				}
				else {
					socialObj.file = '';
				}
			}
			else {
				socialObj.file = '';
			}
			
			res.render('superadmin/social/ajax-edit-single-post.ejs', {
  				socialRecord : socialObj,
				layout:false,
				messages: req.flash('error') || req.flash('info')
			});
		});
	});
};

exports.removeSocialPostMedia = function(req, res){
	var social_media_id = req.body.id;
	MemberSocialMedia.findOne({_id : social_media_id},function(err, socialMedia){
		var fs = require('fs');
		var path = require('path');
		var appDir = path.dirname(require.main.filename);
		if(socialMedia.media_type=='Image'){
			var filePath = appDir+'/upload/socialmedia/image/'+socialMedia.file;
		}
		else {
			var filePath = appDir+'/upload/socialmedia/video/'+socialMedia.file;
		}
		fs.unlinkSync(filePath);
		res.send('done');
		return false;
	})
};

exports.postEditSocialPost = function(req, res){
	var async = require('async');
	var captionMsg = req.body.captionMsg2;

	var allHashTags = captionMsg.match(/#\w+/g);
	var socialPostObj = {
		caption_title : captionMsg,
		hash_tags : allHashTags
	}

	MemberSocial.findByIdAndUpdate(req.body.social_id2, socialPostObj, function(err, singleRecord) {
		var path = require('path');
		var appDir = path.dirname(require.main.filename);
		var fs = require('fs');

		async.forEachSeries(req.files, function(n1, callback_s1) {
			var length = 10;
			var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
			var fileExt = n1.name.split('.').pop();
			var fileExtLower = fileExt.toLowerCase();
			fileName = fileName+'.'+fileExt;
			var foldername = '',media_type = '';
			if(fileExtLower=='jpg' || fileExtLower=='jpeg' || fileExtLower=='png' || fileExtLower=='gif'){
				foldername = 'image';
				media_type = 'Image';
			}
			else {
				foldername = 'video';
				media_type = 'Video';
			}
			
			n1.mv('./upload/socialmedia/'+foldername+'/'+fileName, function(err) {
				MemberSocialMedia.findOne({ social_timeline_id: req.body.social_id2 },function(err, socialMediaRec){
					if(socialMediaRec){
						var mediaObj = {
							media_type : media_type,
							file : fileName
						};

						MemberSocialMedia.findOneAndUpdate({ social_timeline_id: req.body.social_id2 },mediaObj, function(err) { 
							callback_s1();
						});
					}
					else {
						var mediaObj = {
							social_timeline_id : req.body.social_id2,
							media_type : media_type,
							file : fileName
						};

						var sm = new MemberSocialMedia(mediaObj);
						sm.save(function(err,saverec) {
							callback_s1();
						});
					}
				})
			});
		}, function () {
			res.send('done');
			return false;
		});
	});
};

exports.postSocialPost = function(req,res){
	var async = require('async');
	var captionMsg = req.body.captionMsg;
	var allHashTags = captionMsg.match(/#\w+/g);
	var socialPostObj = {
		member_id : req.session.uniqueid,
		usertype : 'Super',
		caption_title : req.body.captionMsg,
		hash_tags : allHashTags
	}
	var sp = new MemberSocial(socialPostObj);
	sp.save(function(err,saverec) {
		var path = require('path');
		var appDir = path.dirname(require.main.filename);
		var fs = require('fs');

		async.forEachSeries(req.files, function(n1, callback_s1) {
			var length = 10;
			var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
			var fileExt = n1.name.split('.').pop();
			var fileExtLower = fileExt.toLowerCase();
			fileName = fileName+'.'+fileExt;
			var foldername = '',media_type = '';
			if(fileExtLower=='jpg' || fileExtLower=='jpeg' || fileExtLower=='png' || fileExtLower=='gif'){
				foldername = 'image';
				media_type = 'Image';
			}
			else {
				foldername = 'video';
				media_type = 'Video';
			}
			
			n1.mv('./upload/socialmedia/'+foldername+'/'+fileName, function(err) {
				var img_obj = {
					social_timeline_id : saverec._id,
					media_type : media_type,
					file : fileName
				};

				var smp = new MemberSocialMedia(img_obj);
				smp.save(function(err) {
					callback_s1();
				});
			});
		}, function () {
			res.send('done');
			return false;
		});
	})
};

// post like user list
exports.postListLikeUsers = function(req, res, next) {
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host');
	MemberSocialMediaFeedback.find({ social_id:req.body.social_id,feedbacktype:"Like"}, function(err, feedback) {
		var likeUserStr = '';
		if(feedback.length>0){
			async.forEachSeries(feedback, function(n1, callback_s1) {
				if(n1.usertype=='HR'){
					Company.findOne({ _id: n1.member_id }, function(err, companyInfo) {
						var hrPhoto = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						likeUserStr+= "<tr><td><center><img src='"+hrPhoto+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.usertype+"</td><td>"+companyInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});
				}
				else if(n1.usertype=='Insurance' || n1.usertype=='Broker'){
					Administrator.findOne({ _id: n1.member_id }, function(err, insuranceInfo) {
						var insPhoto = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						likeUserStr+= "<tr><td><center><img src='"+insPhoto+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.usertype+"</td><td>"+insuranceInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});
				}
				else if(n1.usertype=='Super'){
					Superadmin.findOne({ _id: n1.member_id }, function(err, superInfo) {
						var superPhoto = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						likeUserStr+= "<tr><td><center><img src='"+superPhoto+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.usertype+"</td><td>"+superInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});
				}
				else {
					Member.findOne({ _id: n1.member_id }, function(err, memberInfo) {
						var memPhoto = (memberInfo.photo!='') ? fullUrl+'/member/'+memberInfo.photo : fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						likeUserStr+= "<tr><td><center><img src='"+memPhoto+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.usertype+"</td><td>"+memberInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});
				}
			}, function () {
				var commentObj = {
					'tableInfo': likeUserStr,
					'totalRecords': feedback.length
				}
				res.json(commentObj);
			});
		}
		else {
			var commentObj = {
				'tableInfo': likeUserStr,
				'totalRecords': feedback.length
			}
			res.json(commentObj);
		}
	}).sort({created_at:'desc'});
};

exports.pressListCommentUsersModal = function(req,res){
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host');
	MemberSocialMediaFeedback.find({ social_id:req.body.social_id,feedbacktype:"Comment"}, function(err, feedback) {
		var commentUserStr = '';
		if(feedback.length>0){
			async.forEachSeries(feedback, function(n1, callback_s1) {
				if(n1.usertype=='HR'){
					Company.findOne({ _id: n1.member_id }, function(err, companyInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						commentUserStr+= "<tr><td><center><img src='"+photoURL+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.comment+"</td><td>"+companyInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});
				}
				else if(n1.usertype=='Insurance' || n1.usertype=='Broker'){
					Administrator.findOne({ _id: n1.member_id }, function(err, insuranceInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						commentUserStr+= "<tr><td><center><img src='"+photoURL+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.comment+"</td><td>"+insuranceInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});	
				}
				else if(n1.usertype=='Super'){
					Superadmin.findOne({ _id: n1.member_id }, function(err, superadminInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						commentUserStr+= "<tr><td><center><img src='"+photoURL+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.comment+"</td><td>"+superadminInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});		
				}
				else {
					Member.findOne({ _id: n1.member_id }, function(err, memberInfo) {
						var photoURL = (memberInfo.photo!='') ? fullUrl+'/member/'+memberInfo.photo : fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
						commentUserStr+= "<tr><td><center><img src='"+photoURL+"' class='avatar img-circle' alt='avatar'></center></td><td>"+n1.usertype+"</td><td>"+memberInfo.firstname+"</td><td>"+createdDate+"</td></tr>";
						callback_s1();
					});
				}
			}, function () {
				var commentObj = {
					'tableInfo': commentUserStr,
					'totalRecords': feedback.length
				}
				res.json(commentObj);	
			});
		}
		else {
			var commentObj = {
				'tableInfo': commentUserStr,
				'totalRecords': feedback.length
			}
			res.json(commentObj);	
		}
	}).sort({created_at:'desc'});
};

// post comment feedback
exports.postCommentFeedBack = function(req, res, next) {
	var feedObj = new Object;
	feedObj.member_id = req.session.uniqueid;
	feedObj.social_id = req.body.social_id;
	feedObj.feedbacktype = 'Comment';
	feedObj.usertype = 'Super';
	feedObj.comment = req.body.comment;

	var fp = new MemberSocialMediaFeedback(feedObj);
	fp.save(function(err) {
		MemberSocialMediaFeedback.find({ social_id:req.body.social_id,feedbacktype:"Comment",comment: { $ne: null }}, function(err, feedback2) {
			res.json(feedback2.length);
		});
	});
};

// post list user comment
exports.postListUserComment = function(req, res, next) {
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host');
	MemberSocialMediaFeedback.find({ social_id:req.body.social_id,feedbacktype:"Comment",comment: { $ne: null }}, function(err, feedback2) {
		var commentStr = '';
		if(feedback2.length>0){
			async.forEachSeries(feedback2, function(n1, callback_s1) {
				if(n1.usertype=='HR'){
					Company.findOne({ _id: n1.member_id }, function(err, companyInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
		    			commentStr+= "<li class='option-row'><img src='"+photoURL+"' class='avatar' alt='Avatar'><div class='reply'><p><strong><a href='javascript:void(0);'>"+companyInfo.firstname+' '+companyInfo.lastname+"</a></strong> "+n1.comment+"</p><p class='text-muted reply-time'>"+createdDate+"</p></div></li>";
		    			callback_s1();
					});
				}
				else if(n1.usertype=='Insurance' || n1.usertype=='Broker'){
					Administrator.findOne({ _id: n1.member_id }, function(err, insuranceInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
		    			commentStr+= "<li class='option-row'><img src='"+photoURL+"' class='avatar' alt='Avatar'><div class='reply'><p><strong><a href='javascript:void(0);'>"+insuranceInfo.firstname+' '+insuranceInfo.lastname+"</a></strong> "+n1.comment+"</p><p class='text-muted reply-time'>"+createdDate+"</p></div></li>";
		    			callback_s1();
					});
				}
				else if(n1.usertype=='Super'){
					Superadmin.findOne({ _id: n1.member_id }, function(err, superadminInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
		    			commentStr+= "<li class='option-row'><img src='"+photoURL+"' class='avatar' alt='Avatar'><div class='reply'><p><strong><a href='javascript:void(0);'>"+superadminInfo.firstname+' '+superadminInfo.lastname+"</a></strong> "+n1.comment+"</p><p class='text-muted reply-time'>"+createdDate+"</p></div></li>";
		    			callback_s1();
					});
				}
				else {
					Member.findOne({ _id: n1.member_id }, function(err, memberInfo) {
						var photoURL = fullUrl+'/img/avatar/avatar.jpg',
						createdDate = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
		    			commentStr+= "<li class='option-row'><img src='"+photoURL+"' class='avatar' alt='Avatar'><div class='reply'><p><strong><a href='javascript:void(0);'>"+memberInfo.firstname+' '+memberInfo.lastname+"</a></strong> "+n1.comment+"</p><p class='text-muted reply-time'>"+createdDate+"</p></div></li>";
		    			callback_s1();
					});
				}
			}, function () {
				res.json(commentStr);	
			});
		}
		else {
			res.json(commentStr);
		}
	}).sort({created_at:'desc'});
};

//post like unlike feedback
exports.postFeedBack = function(req, res, next) {
	MemberSocialMediaFeedback.find({ social_id:req.body.social_id,member_id:req.session.uniqueid, $or:[{feedbacktype:"Like"},{feedbacktype:"Unlike"}]}, function(err, feedback) {
		if(feedback.length==0){
			var loginUserType = (req.session.customertype=='Broker Admin') ? 'Broker' : 'Insurance';
			var feedObj = new Object;
			feedObj.member_id = req.session.uniqueid;  
			feedObj.social_id = req.body.social_id;
			feedObj.feedbacktype = 'Like';
			feedObj.usertype = 'Super';
			feedObj.comment = '';

			var fp = new MemberSocialMediaFeedback(feedObj);
			fp.save(function(err) {
				MemberSocialMediaFeedback.find({ social_id:req.body.social_id,feedbacktype:"Like"}, function(err, feedback2) {
					res.json(feedback2.length);
				});
			});
		}
		else {
			var selType = 'Like';
			if(feedback[0].feedbacktype=='Like'){
				selType = 'Unlike';
			}

			MemberSocialMediaFeedback.findOneAndUpdate({comment:'',social_id:req.body.social_id,member_id:req.session.uniqueid}, { feedbacktype: selType }, function(err, feedback3) {
				MemberSocialMediaFeedback.find({ social_id:req.body.social_id,feedbacktype:"Like"}, function(err, feedback4) {
					res.json(feedback4.length);
				});
			});
		}
	});
};

//social timeline
exports.list = function(req, res, next) {
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host');
	var campaigns = new Object;
	campaigns.first = fullUrl+'/socialmedia/image/set1.jpg';
	campaigns.second = fullUrl+'/socialmedia/image/set2.jpg';
	campaigns.third = fullUrl+'/socialmedia/image/set3.jpg';
	campaigns.fourth = fullUrl+'/socialmedia/image/set4.jpg';
	var resarr = new Object;
	var monthNames = ["January", "February", "March", "April", "May", "June",
	  "July", "August", "September", "October", "November", "December"
	];
  	MemberSocial.find(function(err, social) {
  		var hashTags = _.pluck(social, 'hash_tags');
		hashTags = _.uniq(hashTags.join().split(','));
		hashTags = hashTags.filter(Boolean)
		var month_year_info_arr = [];
  		var month_year_info_arr_cnt = month_year_arr_cnt = 0;
  		var month_year_arr = [];
  		async.forEachSeries(social, function(n1, callback_s1) {
  			MemberSocialPreview.find({social_timeline_id:n1._id},function(err, socialPreviewRec){
				if(socialPreviewRec.length>0){
					var previewDates = _.pluck(socialPreviewRec, 'preview_datetime');
					previewDatesArr = previewDates.join().split(',');
				}
				else {
					previewDatesArr = [];
				}
				MemberSocialShare.find({social_timeline_id:n1._id},function(err, socialShareRec){
					if(socialShareRec.length>0){
						var shareDates = _.pluck(socialShareRec, 'share_datetime');
						shareDatesArr = shareDates.join().split(',');
					}
					else {
						shareDatesArr = [];
					}


		  			var schemaName = '';
		  			if(n1.usertype=='Super'){
		  				schemaName = Superadmin;
		  			}	
		  			else if(n1.usertype=='Insurance' || n1.usertype=='Broker'){
		  				schemaName = Administrator;
		  			}
		  			else if(n1.usertype=='HR'){
		  				schemaName = Company;
		  			}
		  			else {
		  				schemaName = Member;
		  			}
		  			schemaName.findOne({ _id: n1.member_id }, function(err, userdetails) {
		  				var month_year_obj = new Object;
			  			var current_month = (n1.created_at.getMonth()+1);
			  			month_year_obj.month = current_month;
			  			month_year_obj.monthfullname = monthNames[(current_month-1)];
			  			var current_year = n1.created_at.getFullYear();
			  			month_year_obj.year = current_year;
			  			month_year_obj.social_info = [];
			  			var exist_status = 'no';
			  			var social_obj = new Object;
			  			social_obj.id = n1._id;
			  			social_obj.member_id = n1.member_id;
			  			social_obj.member_name = (userdetails.firstname+' '+userdetails.lastname);
			  			social_obj.member_photo = fullUrl+'/member/no_image_user.png';
			  			social_obj.caption_title = n1.caption_title;
			  			social_obj.company_id = n1.company_id;
			  			social_obj.total_preview = previewDatesArr.length;
			  			social_obj.total_share = shareDatesArr.length;
			  			social_obj.created_at = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
			  			var index = secondstoreindex = 0;
			  			for(var mon_year=0;mon_year<month_year_arr.length;mon_year++){
			  				if((month_year_arr[mon_year].month==current_month) && (month_year_arr[mon_year].year==current_year)){
			  					secondstoreindex = mon_year;
			  					index = month_year_info_arr[mon_year].social_info.length;
			  					month_year_info_arr[mon_year].social_info[index] = social_obj;
			  					exist_status = 'yes';
			  					break;
			  				}
			  			}
			  			if(exist_status=='no'){
			  				secondstoreindex = month_year_info_arr_cnt;
			  				month_year_info_arr[month_year_info_arr_cnt] = month_year_obj;
			  				month_year_info_arr[month_year_info_arr_cnt].social_info[0] = social_obj;
			  				month_year_arr[month_year_arr_cnt] = month_year_obj;
			  				month_year_info_arr_cnt++;
			  				month_year_arr_cnt++;
			  			}
			  			
			  			MemberSocialMedia.find({ social_timeline_id: n1._id }, function(err, membersocialmedia) {
					    	var member_social_media_arr = [];
		    				var member_social_media_cnt = 0;	
					    	async.forEachSeries(membersocialmedia, function(n2, callback_s2) {
								var n2_obj = new Object;
					    		n2_obj._id = n2._id;
					    		n2_obj.social_timeline_id = n2.social_timeline_id;
					    		n2_obj.media_type = n2.media_type;
					    		var foldertype = (n2.media_type=='Image') ? 'image' : 'video';
					    		
				    			n2_obj.file = (n2.file!='') ? fullUrl+'/socialmedia/'+foldertype+'/'+n2.file : '';
				    			member_social_media_arr[member_social_media_cnt] = n2_obj;
					    		member_social_media_cnt++;
					    		callback_s2();
					    	}, function (err) {
					    		month_year_info_arr[secondstoreindex].social_info[index].social_media = member_social_media_arr;
					  			
					  			var member_likes_feedback_arr = [];
					        	var member_likes_feedback_arr_cnt = 0;
					        	var member_comments_feedback_arr = [];
					        	var member_comments_feedback_arr_cnt = 0;
					        	month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
								month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
								MemberSocialMediaFeedback.find({ social_id: n1._id }, function(err, membersocialmediafeedback) {
									async.forEachSeries(membersocialmediafeedback, function(n3, callback_s3) {
										var feed_obj = new Object;
										feed_obj._id = n3._id;
										if(n3.usertype=='HR'){
											Company.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.usertype = n3.usertype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
										else if(n3.usertype=='Insurance' || n3.usertype=='Broker'){
											Administrator.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
										else if(n3.usertype=='Super'){
											Superadmin.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
										else {
											Member.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.usertype = n3.usertype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
									}, function () {
										var socialmedia_obj = member_social_media_arr;
								        callback_s1();
								    });
								}).sort({created_at:'desc'});
							});
						});
		  			});
				});
			});
  		}, function (err) {
  			res.render('superadmin/social/list', {
  				customarr : month_year_info_arr,
				logintype : req.session.type,
				loginid : req.session.id,
				loginname : req.session.name,
				loginemail : req.session.email,
				campaigns : campaigns,
				hashTags : hashTags,
				messages: req.flash('error') || req.flash('info')
			});
		});
  	}).sort({created_at:'desc'})
};

exports.removePost = function(req,res){
	var social_post_id = req.body.social_id;
	MemberSocial.remove({ _id: social_post_id }, function(err, social) {
		MemberSocialMedia.remove({ social_timeline_id: social_post_id }, function(err, membersocialmedia) {
			MemberSocialMediaFeedback.remove({ social_id: social_post_id }, function(err, membersocialmedia) {
				res.send('done');
				return false;
			});
		});
	});
};

// ajax list social post
exports.ajaxListSocialPost = function(req, res, next) {
	var socialPostObj = new Object();
	var async = require('async');
	var fullUrl = req.protocol + '://' + req.get('host');
	var monthNames = ["January", "February", "March", "April", "May", "June",
	  "July", "August", "September", "October", "November", "December"
	];
	
	var ajaxFileName;
	if(req.body.type=='tag'){
		if(req.body.tag!='All'){
			var tagObj = { $elemMatch: { $eq: req.body.tag } };
			socialPostObj.hash_tags = tagObj;
		}
		ajaxFileName = 'ajax-list-tag-social-post.ejs';
	}
	else {
		ajaxFileName = 'ajax-list-social-post.ejs';
	}
	MemberSocial.find(socialPostObj, function(err, social) {
  		var hashTags = _.pluck(social, 'hash_tags');
		hashTags = _.uniq(hashTags.join().split(','));
		hashTags = hashTags.filter(Boolean)
  		var month_year_info_arr = [];
  		var month_year_info_arr_cnt = month_year_arr_cnt = 0;
  		var month_year_arr = [];
  		async.forEachSeries(social, function(n1, callback_s1) {
  			MemberSocialPreview.find({social_timeline_id:n1._id},function(err, socialPreviewRec){
				if(socialPreviewRec.length>0){
					var previewDates = _.pluck(socialPreviewRec, 'preview_datetime');
					previewDatesArr = previewDates.join().split(',');
				}
				else {
					previewDatesArr = [];
				}
				MemberSocialShare.find({social_timeline_id:n1._id},function(err, socialShareRec){
					if(socialShareRec.length>0){
						var shareDates = _.pluck(socialShareRec, 'share_datetime');
						shareDatesArr = shareDates.join().split(',');
					}
					else {
						shareDatesArr = [];
					}
		  			var schemaName = '';
		  			if(n1.usertype=='Super'){
		  				schemaName = Superadmin;
		  			}	
		  			else if(n1.usertype=='Insurance' || n1.usertype=='Broker'){
		  				schemaName = Administrator;
		  			}
		  			else if(n1.usertype=='HR'){
		  				schemaName = Company;
		  			}
		  			else {
		  				schemaName = Member;
		  			}
		  			schemaName.findOne({ _id: n1.member_id }, function(err, userdetails) {
						var month_year_obj = new Object;
			  			var current_month = (n1.created_at.getMonth()+1);
			  			month_year_obj.month = current_month;
			  			month_year_obj.monthfullname = monthNames[(current_month-1)];
			  			var current_year = n1.created_at.getFullYear();
			  			month_year_obj.year = current_year;
			  			month_year_obj.social_info = [];
			  			var exist_status = 'no';
			  			var social_obj = new Object;
			  			social_obj.id = n1._id;
			  			social_obj.member_id = n1.member_id;
			  			social_obj.member_name = (userdetails.firstname+' '+userdetails.lastname);
			  			social_obj.member_photo = fullUrl+'/member/no_image_user.png';
			  			social_obj.caption_title = n1.caption_title;
			  			social_obj.total_preview = previewDatesArr.length;
			  			social_obj.total_share = shareDatesArr.length;
			  			social_obj.company_id = n1.company_id;
			  			social_obj.created_at = moment(n1.created_at).format('HH:mm MMMM DD, YYYY');
			  			var index = secondstoreindex = 0;
			  			for(var mon_year=0;mon_year<month_year_arr.length;mon_year++){
			  				if((month_year_arr[mon_year].month==current_month) && (month_year_arr[mon_year].year==current_year)){
			  					secondstoreindex = mon_year;
			  					index = month_year_info_arr[mon_year].social_info.length;
			  					month_year_info_arr[mon_year].social_info[index] = social_obj;
			  					exist_status = 'yes';
			  					break;
			  				}
			  			}
			  			if(exist_status=='no'){
			  				secondstoreindex = month_year_info_arr_cnt;
			  				month_year_info_arr[month_year_info_arr_cnt] = month_year_obj;
			  				month_year_info_arr[month_year_info_arr_cnt].social_info[0] = social_obj;
			  				month_year_arr[month_year_arr_cnt] = month_year_obj;
			  				month_year_info_arr_cnt++;
			  				month_year_arr_cnt++;
			  			}
			  			
			  			MemberSocialMedia.find({ social_timeline_id: n1._id }, function(err, membersocialmedia) {
					    	var member_social_media_arr = [];
		    				var member_social_media_cnt = 0;	
					    	async.forEachSeries(membersocialmedia, function(n2, callback_s2) {
								var n2_obj = new Object;
					    		n2_obj._id = n2._id;
					    		n2_obj.social_timeline_id = n2.social_timeline_id;
					    		n2_obj.media_type = n2.media_type;
					    		var foldertype = (n2.media_type=='Image') ? 'image' : 'video';
					    		
				    			n2_obj.file = (n2.file!='') ? fullUrl+'/socialmedia/'+foldertype+'/'+n2.file : '';
				    			member_social_media_arr[member_social_media_cnt] = n2_obj;
					    		member_social_media_cnt++;
					    		callback_s2();
					    	}, function (err) {
					    		month_year_info_arr[secondstoreindex].social_info[index].social_media = member_social_media_arr;
					  			
					  			var member_likes_feedback_arr = [];
					        	var member_likes_feedback_arr_cnt = 0;
					        	var member_comments_feedback_arr = [];
					        	var member_comments_feedback_arr_cnt = 0;
					        	month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
								month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
								MemberSocialMediaFeedback.find({ social_id: n1._id }, function(err, membersocialmediafeedback) {
									async.forEachSeries(membersocialmediafeedback, function(n3, callback_s3) {
										var feed_obj = new Object;
										feed_obj._id = n3._id;
										if(n3.usertype=='HR'){
											Company.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.usertype = n3.usertype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
										else if(n3.usertype=='Insurance' || n3.usertype=='Broker'){
											Administrator.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
										else if(n3.usertype=='Super'){
											Superadmin.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
										else {
											Member.findOne({ _id: n3.member_id }, function(err, member_feedback) {
												feed_obj.member_id = member_feedback._id;
												feed_obj.name = member_feedback.firstname+' '+member_feedback.lastname;
												feed_obj.photo = (member_feedback.photo!='') ? fullUrl+'/member/'+member_feedback.photo : fullUrl+'/img/avatar/avatar.jpg';
									    		feed_obj.social_id = n3.social_id;
									    		feed_obj.feedbacktype = n3.feedbacktype;
									    		feed_obj.usertype = n3.usertype;
									    		feed_obj.created_at = moment(n3.created_at).format('HH:mm MMMM DD, YYYY');
									    		if(n3.feedbacktype=='Comment'){
									    			feed_obj.comment = n3.comment;
									    			member_comments_feedback_arr[member_comments_feedback_arr_cnt] = feed_obj;
									    			member_comments_feedback_arr_cnt++;
									    		}
									    		else if(n3.feedbacktype=='Like'){
									    			member_likes_feedback_arr[member_likes_feedback_arr_cnt] = feed_obj;
									    			member_likes_feedback_arr_cnt++;
									    		}
												
												month_year_info_arr[secondstoreindex].social_info[index].social_media_likes = member_likes_feedback_arr;
												month_year_info_arr[secondstoreindex].social_info[index].social_media_comments = member_comments_feedback_arr;
												callback_s3();
											});
										}
									}, function () {
										var socialmedia_obj = member_social_media_arr;
								        callback_s1();
								    });
								}).sort({created_at:'desc'});
							});
						});
		  			});
				});
			});
  		}, function (err) {
			res.render('superadmin/social/'+ajaxFileName, {
  				customarr : month_year_info_arr,
				logintype : req.session.type,
				loginid : req.session.id,
				loginname : req.session.name,
				loginemail : req.session.email,
				hashTags : hashTags,
				layout:false,
				messages: req.flash('error') || req.flash('info')
			});
		});
  	}).sort({created_at:'desc'});
};