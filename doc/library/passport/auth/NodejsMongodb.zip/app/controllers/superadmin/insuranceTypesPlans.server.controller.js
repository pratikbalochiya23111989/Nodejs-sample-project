var InsuranceTypesPlans = require('mongoose').model('InsuranceTypesPlans');
var InsuranceTypes = require('mongoose').model('InsuranceTypes');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var moment = require('moment')

// list insurancetypes
exports.list = function(req, res, next) {
	InsuranceTypesPlans.find({status: {'$ne':'Deleted' },type : 'Group'}, function(err, insurancetypesplans) {
		if (err) {
			return next(err);
		}
		else {
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var fullUrl = req.protocol + '://' + req.get('host');
			for (var i = 0; i < insurancetypesplans.length; i++) {
				var uploadpath = appDir+'/upload/insuranceplan/'+insurancetypesplans[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(insurancetypesplans[i].photo!='')
                      {
                          insurancetypesplans[i].photo = fullUrl+'/insuranceplan/'+insurancetypesplans[i].photo;
                      }
                      else
                      {
                          insurancetypesplans[i].photo = fullUrl+'/insuranceplan/no_image_user.png';
                      }
				}
				catch (e) {
				  	insurancetypesplans[i].photo = fullUrl+'/insuranceplan/no_image_user.png';
				}
			};
			InsuranceTypes.find({type : 'Group'}, function(err, insurancetypes) {
				res.render('superadmin/insuranceTypesPlans/list', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					insurancetypes : insurancetypes,
					insurancetypesplans : insurancetypesplans,
					messages : req.flash('error') || req.flash('info'),
					messages : req.flash('info'),
					moment : moment
				});
			});				
		}
	}).sort({created_at:'desc'});
};

//add new insurancetypes 
exports.add = function(req, res, next) {
	InsuranceTypes.find({status:'Active',type:'Group'}, function(err, insurancetypes) {
		res.render('superadmin/insuranceTypesPlans/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			insurancetypes:insurancetypes,
			messages: req.flash('error') || req.flash('info')
		});
	});
};


// edit insurancetypes
exports.edit = function(req, res, next) {
	var id = req.params.id;
	
	 InsuranceTypesPlans.findOne({
	 		_id: id
		}, 
		function(err, insurancetypesplans) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
                    if(insurancetypesplans.photo!=''){
                        insurancetypesplans.photo = fullUrl+'/insuranceplan/'+insurancetypesplans.photo;
                    }
                    else {
                        insurancetypesplans.photo = '';
                    }
				InsuranceTypes.find({status:'Active',type:"Group"}, function(err, insurancetypes) {
					res.render('superadmin/insuranceTypesPlans/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						insurancetypes:insurancetypes,
						insurancetypesplans:insurancetypesplans,
						messages: req.flash('error') || req.flash('info')
					});
				});
			}
		});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.photo.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.photo;	
	sampleFile.mv('./upload/insuranceplan/'+fileName, function(err) 
		{	
			if (err)	  
				return res.status(500).send(err);	
		});
	req.body.photo=fileName;
	var insurancetypeplan=new InsuranceTypesPlans(req.body);
	insurancetypeplan.save(function(err){
		if(err)
		{
			return next(err);
		}
		else
		{
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new insurance plan '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Insurance Plan Added Successfully.');
			return res.redirect('/superadmin/insuranceTypesPlans/list');
		}
	});
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	 if(req.body.imgUpload=='Yes')
	 {
	 	var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/insuranceplan/'+fileName, function(err) 
			{	
				if (err)	  
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		InsuranceTypesPlans.findByIdAndUpdate(req.body.insurancetypes_plans_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated insurance plan '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				console.log(loginHistoryObj.login_id);
				console.log(loginHistoryObj);
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Insurance Plan Updated Successfully.');
				return res.redirect('/superadmin/insuranceTypesPlans/list');
			}
		});
	 }
	 else
	 {
	 	InsuranceTypesPlans.findByIdAndUpdate(req.body.insurancetypes_plans_id, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Insurance Plan Updated Successfully.');
				return res.redirect('/superadmin/insuranceTypesPlans/list');
			}
		});
	 }
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			InsuranceTypesPlans.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							InsuranceTypesPlans.findOne({_id:n1},function(err, insurancetypesplan){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  insurancetypesplan '+ insurancetypesplan.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/insuranceTypesPlans/list');
						});
						
					}
				}
			)
			break;
	}
	
};
exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	InsuranceTypesPlans.findOne({
			_id: id
		}, 
		function(err, insuranceplan) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/insuranceplan/'+insuranceplan.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				InsuranceTypesPlans.findByIdAndUpdate(id, memupdate, function(err, insurancetypeplans) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/insuranceTypesPlans/edit/'+id);
					}
				});
			}
		}
	);
};