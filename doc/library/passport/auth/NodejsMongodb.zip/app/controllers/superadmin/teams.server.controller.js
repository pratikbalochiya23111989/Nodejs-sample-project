var Team = require('mongoose').model('Team');
var Member = require('mongoose').model('Member');
var Department = require('mongoose').model('Department');
var moment = require('moment')

// list teams
exports.list = function(req, res, next) {
	Team.find({status: {'$ne':'Deleted' },type:'Wellnessclient'}, function(err, teams) {
		if (err) {
			return next(err);
		}
		else {
				var path = require('path');
			 	var appDir = path.dirname(require.main.filename);
				var fullUrl = req.protocol + '://' + req.get('host');
				var fs = require('fs');
				for (var i = 0; i < teams.length; i++) {
				var uploadpath = appDir+'/upload/team/'+teams[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(teams[i].photo!='')
				  	{
				  		teams[i].photo = fullUrl+'/team/'+teams[i].photo;
				  	}
				  	else
				  	{
				  		teams[i].photo = fullUrl+'/team/no_image_user.png';
				  	}
				  	
				}
				catch (e) {
				  	teams[i].photo = fullUrl+'/team/no_image_user.png';
				}
			};
			Department.find({type:'Wellnessclient'}, function(err, departments) {
				res.render('superadmin/teams/list', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					teams: teams,
					departments:departments,
					messages: req.flash('error') || req.flash('info'),
					messages:req.flash('info'),
					moment: moment
				});
			});
		}
	}).sort({created_at:'desc'});
};

//add new team 
exports.add = function(req, res, next) {
		Department.find({type:'Wellnessclient'}, function(err, departments){
		res.render('superadmin/teams/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			departments : departments,
			messages: req.flash('error') || req.flash('info')
		});
	});		
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
	var fileExt = req.files.photo.name.split('.').pop();
	fileName = fileName+'.'+fileExt;
	var team = new Team(req.body);
	team.company_id = req.session.uniqueid;
	team.photo = fileName;
	team.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			sampleFile = req.files.photo;
			sampleFile.mv('./upload/team/'+fileName, function(err) {
				    var date = new Date();
					industry_name=req.body.title;
					loginHistoryObj.title = req.session.name+' added new team '+ industry_name;
					loginHistoryObj.login_id = req.session.historyid;
					loginHistoryObj.posted =date;
					loginHistoryObj.save(function(err) {
					});
				req.flash('info', 'New team Added Successfully.');
				return res.redirect('/superadmin/teams/list');
			});
		}
	});
};

// edit team

exports.edit = function(req, res, next) {
	var id = req.params.id;
	
	 Team.findOne({
	 		_id: id
		}, 
		function(err, team) {
			if (err) {
				return next(err);
			}
			else {
				var fullUrl = req.protocol + '://' + req.get('host');
					if(team.photo)
						{
						if(team.photo!=''){
							team.photo = fullUrl+'/team/'+team.photo;
							}
						else {
							team.photo = '';
							}
						}
						else
						{
							team.photo = '';
						}
					Department.find({},function(err,departments){
						res.render('superadmin/teams/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						team:team,
						departments:departments,
						messages: req.flash('error') || req.flash('info')
					});
					})
			}
		});
};

// update team
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.body.imgUpload=='Yes')
	{
		var length = 10;
		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
		var fileExt = req.files.photo.name.split('.').pop();	
		fileName = fileName+'.'+fileExt;	
		sampleFile = req.files.photo;	
		sampleFile.mv('./upload/team/'+fileName, function(err) 
			{	
				if (err)	 
					return res.status(500).send(err);	
			});
		req.body.photo=fileName;
		Team.findByIdAndUpdate(req.body.teamid, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				industry_name=req.body.title;
				loginHistoryObj.title = req.session.name+' updated team '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				console.log(loginHistoryObj.login_id);
				console.log(loginHistoryObj);
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Team Updated Successfully.');
				return res.redirect('/superadmin/teams/list');
			}
		});
	}
	else
	{
		Team.findByIdAndUpdate(req.body.teamid, req.body, function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				req.flash('info', 'Team Updated Successfully.');
				return res.redirect('/superadmin/teams/list');
			}
		});
	}
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids = req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';

	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Team.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Team.findOne({_id:n1},function(err, team){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  team '+ team.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/teams/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Team.findOne({
			_id: id
		}, 
		function(err, team) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/team/'+team.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Team.findByIdAndUpdate(id, memupdate, function(err, team) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/superadmin/teams/edit/'+id);
					}
				});
			}
		}
	);
};