var Superadmin = require('mongoose').model('Superadmin');
var LogActivity = require('mongoose').model('LogActivity');
var moment = require('moment')

// list administrator
exports.list = function(req, res, next) {
	Superadmin.find({status:{$ne:'Deleted'}}, function(err, administrators) {
		Superadmin.findOne({_id:req.session.uniqueid}, function(err, superadmin) {
		if (err) {
			return next(err);
		}
		else {
			
			res.render('superadmin/administrators/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				administrators: administrators,
				superadmin:superadmin,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			
			});
		}
		});
	}).sort({created_at:'desc'});
};

//add new administrator 
exports.add = function(req, res, next) {
	res.render('superadmin/administrators/add', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.create = function(req, res, next) {	
	var superadmin = new Superadmin(req.body);
	var loginHistoryObj = new LogActivity();
	superadmin.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			loginHistoryObj.title = req.session.name+' added new super admin '+ req.body.firstname+' '+req.body.lastname;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Administrator Added Successfully.');
			return res.redirect('/superadmin/administrators/list');
		}
	});
};

exports.edit = function(req, res, next) {
	var id = req.params.id;
	
	Superadmin.findOne({
			_id: id
		}, 
		function(err, administrator) {
			if (err) {
				return next(err);
			}
			else {
				res.render('superadmin/administrators/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					administrator: administrator,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	Superadmin.findByIdAndUpdate(req.body.admin_id, req.body, function(err, user) {
		if (err) {
			return next(err);
		}
		else {
			if(req.session.uniqueid=req.body.admin_id)
			{
				var date = new Date();
				loginHistoryObj.title = req.session.name+' updated their profile';
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.session.name=req.body.firstname+' '+req.body.lastname;
			}
			else
			{
				var date = new Date();
				loginHistoryObj.title = req.session.name+' updated profile of super admin -'+ req.body.firstname+' '+req.body.lastname;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
			}
			
			req.flash('info', 'Administrator Updated Successfully.');
			return res.redirect('/superadmin/administrators/list');
		}
	});
};

exports.list_action = function(req, res, next) {
	var action = req.body.btnAction;
	var loginHistoryObj = new LogActivity();
	var async = require('async');

	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Superadmin.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
								
							Superadmin.findOne({_id:n1},function(err, superadmin){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  super admin '+ superadmin.firstname+' '+superadmin.lastname;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/superadmin/administrators/list');
						});
						
					}
				}
			)
			break;
	}
	
};
exports.checkemailexist = function(req, res, next) {
	Superadmin.find({email:req.body.email}, function(err, user) {
		if (err) {
			return next(err);
		}
		else {
			if(user.length==0)
			{
				var data='NO';
			}
			else
			{
				var data='YES';
			}
			res.send(data);
		}
	});
};