var Team = require('mongoose').model('Team');
var Member = require('mongoose').model('Member');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var moment = require('moment')

// list teams
exports.list = function(req, res, next) {
	Team.find({company_id : req.session.uniqueid, status: {'$ne':'Deleted'}}, function(err, teams) {
		if (err) {
			return next(err);
		}
		else {
			res.render('company/teams/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				teams: teams,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new team 
exports.add = function(req, res, next) {
	Member.find({company_id : req.session.uniqueid}, function(err, members) {
		res.render('company/teams/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			members : members,
			messages: req.flash('error') || req.flash('info')
		});
	});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var team = new Team(req.body);
	team.company_id = req.session.uniqueid;
	team.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new team '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Team Added Successfully.');
			return res.redirect('/teams/list');
		}
	});
};

// edit team
exports.edit = function(req, res, next) {
	var async = require('async');
	var id = req.params.id;
	Team.findOne({
			_id: id
		}, 
		function(err, team) {
			if (err) {
				return next(err);
			}
			else {
				Member.find({company_id : req.session.uniqueid}, function(err, members) {
					var newMem = [];
					async.forEachSeries(members, function(n1, callback_s1) {
						var matchStatus = team.multiple_members.indexOf(n1._id);
						var singleMem = new Object;
						singleMem._id = n1._id;
						singleMem.firstname = n1.firstname;
						singleMem.lastname = n1.lastname;
						singleMem.email = n1.email;
						singleMem.matchStatus = (matchStatus==-1) ? 'No' : 'Yes';
						newMem.push(singleMem);
						callback_s1();
					}, function (err) {
						res.render('company/teams/edit', {
							logintype : req.session.type,
							loginid : req.session.uniqueid,
							loginname : req.session.name,
							loginemail : req.session.email,
							team: team,
							members : newMem,
							messages: req.flash('error') || req.flash('info')
						});
					});
				});
			}
		}
	);
};

// update team
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	Team.findByIdAndUpdate(req.body.team_id, req.body, function(err, team) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' updated team '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Team Updated Successfully.');
			return res.redirect('/teams/list');
		}
	});
};

exports.list_action = function(req, res, next) {
	req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Team.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							// console.log(n1);
							
							Team.findOne({_id:n1},function(err, team){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  team '+ team.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								// console.log(loginHistoryObj);
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/teams/list');
						});
						
					}
				}
			)
			break;
	}
	
};