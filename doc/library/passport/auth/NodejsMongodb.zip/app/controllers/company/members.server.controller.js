var Member = require('mongoose').model('Member');
var Company = require('mongoose').model('Company');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');

//get all members list
exports.list = function(req, res, next) {
	Member.find({company_id : req.session.uniqueid, status: {'$ne':'Deleted'}}, function(err, members) {
		if (err) {
			return next(err);
		}
		else {
			var fullUrl = req.protocol + '://' + req.get('host');
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var uploadpath = '';

			var fs = require('fs');
			var stats;
			var sampleFileURL = fullUrl+'/sampleMemberImport.csv';
			for (var i = 0; i < members.length; i++) {
				var uploadpath = appDir+'/upload/member/'+members[i].photo;
				try {
				  	fs.statSync(uploadpath);
				  	members[i].photo = fullUrl+'/member/'+members[i].photo;
				}
				catch (e) {
				  	members[i].photo = fullUrl+'/member/no_image_user.png';
				}
			};

			res.render('company/members/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				members : members,
				samplefileurl : sampleFileURL,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info')
			});
		}
	}).sort({created_at:'desc'});
};

// import to csv
exports.importcsv = function(req, res, next) {
	var length = 10;
	var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
	var fileExt = req.files.importMemberCSV.name.split('.').pop();	
	fileName = fileName+'.'+fileExt;	
	sampleFile = req.files.importMemberCSV;	
	sampleFile.mv('./upload/csvfiles/'+fileName, function(err) 
	{	
		if(err){
		 	req.flash('info', 'File Upload Failed.');
			return res.redirect('/members/list');
		}
		else {
			var fs = require('fs');
			var parse = require('csv-parse');
			var async = require('async');

			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var inputFile = appDir+'/upload/csvfiles/'+fileName;
			var cntr = 0,totalImportMem = 0;
			var parser = parse({delimiter: ','}, function (err, data) {
				async.eachSeries(data, function (singleRec, callback) {
			    	// do something with the line
			    	if(cntr>0){
			    		Member.find({ member_code: singleRec[1] }, function(err, memRecord) {
			    			if(memRecord.length>0){
			    				callback();
			    			}
			    			else {
			    				var memInfoObj = {
			    					member_code : singleRec[1],
			    					company_id : singleRec[2],
			    					firstname : singleRec[3],
			    					middlename : singleRec[4],
			    					lastname : singleRec[5],
			    					email : singleRec[6],
			    					phone : singleRec[7],
			    					age : singleRec[8],
			    					sex : singleRec[9],
			    					date_of_birth : singleRec[10],
			    					photo : '',
			    					height : singleRec[11],
			    					smoker : singleRec[12],
			    					smokes : singleRec[13],
			    					drinker : singleRec[14],
			    					drinks : singleRec[15],
			    					weekly_exercise_goal : singleRec[16],
			    					aware_weight : singleRec[17],
			    					weight : singleRec[18],
			    					status : singleRec[19]
			    				}
			    				var memSaveObj = new Member(memInfoObj);
								memSaveObj.save(function(err) {
									totalImportMem++;
									callback();
								});
			    			}
			    		});
			    	}
			    	else {
			    		cntr++;
		      			callback();
			    	}
			  	}, function (err) {
			  		fs.unlinkSync(inputFile);
			  		if(totalImportMem>0){
			  			req.flash('info', 'Total '+totalImportMem+' Members Imported Successfully.');
			  		}
			  		else {
			  			req.flash('info', 'No Member Imported.');
			  		}
					return res.redirect('/members/list');
				});
			});
			fs.createReadStream(inputFile).pipe(parser);
		}
	});
};

// export to csv
exports.exportcsv = function(req, res, next) {
	var async = require('async');
	var json2csv = require('json2csv');
	var fs = require('fs');
	var fields = ['No','Code','CompanyID','Firstname','Middlename','Lastname','Email','Phone','Age','Sex','DateOfBirth','Height','Smoker','NoOfCigarettes','Alcoholic','NoOfDrinks','WeeklyExerciseGoal','AwareWeight','Weight','Status'];
	Member.find({company_id : req.session.uniqueid,status: {'$ne':'Deleted' }}, function(err, members) {
		var allMembersArr = [];
		var cntr = 0;

		async.forEachSeries(members.reverse(), function(n1, callback_s1) {
			var memObj = new Object;
			memObj.No = (cntr+1);
			memObj.Code = n1.member_code;
			memObj.CompanyID = n1.company_id;
			memObj.Firstname = n1.firstname;
			memObj.Middlename = n1.middlename;
			memObj.Lastname = n1.lastname;
			memObj.Email = n1.email;
			memObj.Phone = n1.phone;
			memObj.Age = n1.age;
			memObj.Sex = n1.sex;
			memObj.DateOfBirth = n1.date_of_birth;
			memObj.Height = n1.height;
			memObj.Smoker = n1.smoker;
			memObj.NoOfCigarettes = (n1.smoker=='Yeah') ? n1.smokes : '';
			memObj.Alcoholic = n1.drinker;
			memObj.NoOfDrinks = (n1.drinker=='Yeah') ? n1.drinks : '';
			memObj.WeeklyExerciseGoal = n1.weekly_exercise_goal;
			memObj.AwareWeight = n1.aware_weight;
			memObj.Weight = (n1.aware_weight=='Yes') ? n1.weight : '';
			memObj.Status = n1.status;
			allMembersArr.push(memObj);
			cntr++;
			callback_s1();
		}, function (err) {
			var uniq_no = Math.floor(Math.random()*89999+10000);
			var csv = json2csv({ data: allMembersArr,fields: fields });
			res.attachment(uniq_no+'.csv');
			res.status(200).send(csv);
			return false;	
		});
	}).sort({created_at: 'asc'})
};

//add new member
exports.add = function(req, res, next) {
	res.render('company/members/add', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	/*var path = require('path');
	var appDir = path.dirname(require.main.filename);
	var multer	= require('multer');

	var filenametmp = '';
	var storage	= multer.diskStorage({
	  	destination: function (req, file, callback) {
	    	callback(null, appDir+'/upload/member');
	  	},
	  	filename: function (req, file, callback) {
	  		var uniq_no = Math.floor(Math.random()*89999+10000);
	  		filenametmp = file.originalname;
			filenametmp = uniq_no+filenametmp;
	  		callback(null, filenametmp);
	  	}
	});
	var upload = multer({ storage : storage}).single('photo');
	upload(req,res,function(err) {
		if(err) {
			return next(err);	
		}
		else {*/
			req.body.company_id = req.session.uniqueid;
			/*req.body.photo = filenametmp;*/
			req.body.validic_uid = '';
			req.body.validic_access_token = '';
			req.body.age = '';
			req.body.sex = 'Male';
			req.body.height = '';
			req.body.weight = '';
			req.body.photo = '';
			var member = new Member(req.body);
			member.save(function(err) {
				if (err) {
					return next(err);
				}
				else {
					var date = new Date();
					var fname=req.body.firstname;
					var lname=req.body.lastname;
					var title=fname+' '+lname;
					industry_name=title;
					loginHistoryObj.title = req.session.name+' added new member '+ industry_name;
					loginHistoryObj.login_id = req.session.historyid;
					loginHistoryObj.posted =date;
					console.log(loginHistoryObj.login_id);
					console.log(loginHistoryObj);
					loginHistoryObj.save(function(err) {
					});
					req.flash('info', 'New Member Added Successfully.');
					return res.redirect('/members/list');
				}
			});	
		/*}
	});*/
};

// remove photo
exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Member.findOne({
			_id: id
		}, 
		function(err, member) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/member/'+member.photo;
				fs.unlinkSync(filePath);

				var memupdate = new Object;
				memupdate.photo = '';
				Member.findByIdAndUpdate(id, memupdate, function(err, member) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/member/edit/'+id);
					}
				});
			}
		}
	);
};

// edit member
exports.edit = function(req, res, next) {
	var id = req.params.id;
	Member.findOne({
			_id: id
		}, 
		function(err, member) {
			if (err) {
				return next(err);
			}
			else {
				Company.find({status : 'Active'}, function(err, companies) {
					var fullUrl = req.protocol + '://' + req.get('host');
					if(member.photo!=''){
						member.photo = fullUrl+'/member/'+member.photo;
					}
					else {
						member.photo = '';
					}
					
					res.render('company/members/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						companies : companies,
						member: member,
						messages: req.flash('error') || req.flash('info')
					});
				}).sort({created_at:'desc'});
			}
		}
	);
};

// update member
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	/*if(req.body.imgUpload=='Yes'){
		var filenametmp = '';
		var path = require('path');
		var appDir = path.dirname(require.main.filename);
		var multer	= require('multer');
		var updateObj = new Object;
		updateObj = req.body;

		var storage	= multer.diskStorage({
		  	destination: function (req, file, callback) {
		    	callback(null, appDir+'/upload/member');
		  	},
		  	filename: function (req, file, callback) {
		  		var uniq_no = Math.floor(Math.random()*89999+10000);
		  		filenametmp = file.originalname;
				filenametmp = uniq_no+filenametmp;
		  		callback(null, filenametmp);
		  	}
		});
		var upload = multer({ storage : storage}).single('photo');
		upload(req,res,function(err) {
			if(err) {
				return next(err);	
			}
			else {
				updateObj.photo = filenametmp;
				console.log(req.body);return false;
				Member.findByIdAndUpdate(req.body.member_id, req.body, function(err, member) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', 'Member Updated Successfully.');
						return res.redirect('/members/list');
					}
				});
			}
		});
	}
	else {*/
		Member.findByIdAndUpdate(req.body.member_id, req.body, function(err, member) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				var fname=req.body.firstname;
				var lname=req.body.lastname;
				var title=fname+' '+lname;
				industry_name=title;
				loginHistoryObj.title = req.session.name+' updated member '+ industry_name;
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				console.log(loginHistoryObj.login_id);
				console.log(loginHistoryObj);
				loginHistoryObj.save(function(err) {
				});
				req.flash('info', 'Member Updated Successfully.');
				return res.redirect('/members/list');
			}
		});
	/*}*/
};

// score
exports.score = function(req, res, next) {
	res.render('company/members/score', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.list_action = function(req, res, next) {
	req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Member.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Member.findOne({_id:n1},function(err, member){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  member '+ member.firstname +' '+ member.lastname;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/members/list');
						});
						
					}
				}
			)
			break;
	}
	
};