var Department = require('mongoose').model('Department'),
Team = require('mongoose').model('Team'),
Challenge = require('mongoose').model('Challenge'),
ChallengeAccept = require('mongoose').model('ChallengeAccept'),
Member = require('mongoose').model('Member'),
LogActivity = require('mongoose').model('LogActivity'),
async = require('async'),
moment = require('moment');

// list challenges
exports.list = function(req, res, next) {
	Challenge.find({company_id : req.session.uniqueid, status: {'$ne':'Deleted'}}, function(err, challenges) {
		if (err) {
			return next(err);
		}
		else {
			var fullUrl = req.protocol + '://' + req.get('host');
			var path = require('path');
			var appDir = path.dirname(require.main.filename);
			var uploadpath = '';

			var fs = require('fs');
			var stats;

			for (var i = 0; i < challenges.length; i++) {
				var uploadpath = appDir+'/upload/challenges/'+challenges[i].photo;

				try {
				  	fs.statSync(uploadpath);
				  	if(challenges[i].photo!='')
				  	{
				  		challenges[i].photo = fullUrl+'/challenges/'+challenges[i].photo;
				  	}
				  	else
				  	{
				  		challenges[i].photo = fullUrl+'/challenges/no_image_user.png';
				  	}
				  	
				}
				catch (e) {
				  	challenges[i].photo = fullUrl+'/challenges/no_image_user.png';
				}
				challenges[i].startdate = moment(challenges[i].startdate).format('MMM Do YYYY');
				challenges[i].enddate = moment(challenges[i].enddate).format('MMM Do YYYY');
			}

			res.render('company/challenges/list', {
				logintype : req.session.type,
				loginid : req.session.id,
				loginname : req.session.name,
				loginemail : req.session.email,
				challenges : challenges,
				messages: req.flash('error') || req.flash('info')
			});
		}
	}).sort({created_at:'desc'});
};

// add new challenge
exports.add = function(req, res, next) {
	Department.find({company_id : req.session.uniqueid,status:'Active'}, function(err, departments) {
		Team.find({company_id : req.session.uniqueid,status:'Active'}, function(err, teams) {
			Member.find({company_id : req.session.uniqueid,status:'Active'}, function(err, members) {
			res.render('company/challenges/add', {
				logintype : req.session.type,
				loginid : req.session.id,
				loginname : req.session.name,
				loginemail : req.session.email,
				departments : departments,
				teams : teams,
				members:members,
				messages: req.flash('error') || req.flash('info')
				});
			});
		});
	});
};

// add addteams
exports.addteams = function(req, res, next) {
	var deptarr = [];
	deptarr = req.body.values.split("|");
	var async = require('async');
	Team.find({company_id : req.session.uniqueid,status:'Active',department_id:{$in:deptarr}}, function(err, teams) {
		res.send(teams);
	});
};
exports.allteams = function(req, res, next) {
	Team.find({company_id : req.session.uniqueid,status:'Active'}, function(err, teams) {
		res.send(teams);
	});
};
exports.allteammembers = function(req, res, next) {
	var deptarr=[];
	var team_arr=[];
	var data='';
	var new_arr=[];
	depart_arr=req.body.depart_arr.split('|');
	Team.find({company_id : req.session.uniqueid,status:'Active',department_id:{$in:depart_arr}}, function(err, teams) {
		if(teams.length>0)
		{
			for(var k=0;k<teams.length;k++)
			{
				team_arr+=teams[k]._id+'|';
			}
			var team_array=team_arr.split('|');
			Member.find({company_id : req.session.uniqueid,status:'Active',multiple_teams:{$in:team_array}}, function(err, members) {
				if(members.length>0)
				{
					data+="<option value='All' selected=''>All</option>";
					for(i=0; i<members.length; i++){
					  data+='<option value="'+members[i]._id + '" >'+members[i].firstname+' '+members[i].lastname+'</option>';
					}
					res.send(data);
				}
				else
				{
					res.send(data);
				}
			});
		}
		else
		{
			res.send(data);
		}
	});
};
exports.allmembers = function(req, res, next) {
	var data='';
	Member.find({company_id : req.session.uniqueid,status:'Active'}, function(err, members) {
		data+="<option value='All' selected=''>All</option>";
		for(i=0; i<members.length; i++){
		  data+='<option value="'+members[i]._id + '" >'+members[i].firstname+' '+members[i].lastname+'</option>';
		}
		res.send(data);
	});
};

// add addmembers
exports.addmembers = function(req, res, next) {
	var deptarr = [];
	var teamarr = [];
	var memberarr = [];
	var data_dept=[];
	var team_dept=[];
	var data='';
	deptarr = req.body.dept_values;
	teamarr = req.body.team_values;
	console.log(teamarr);
	Member.find({company_id : req.session.uniqueid,status:'Active', multiple_teams: {$in:teamarr}},function(err,members){
		if(members)
		{
			console.log(members);
			if(members.length>0)
			{
				data+="<option value='All' selected=''>All</option>";
				for(i=0; i<members.length; i++){
				  data+='<option value="'+members[i]._id + '" >'+members[i].firstname+''+members[i].lastname+'</option>';
				 //data_dept.push(members[i]);
				}
				 
			}
			res.send(data);
		}
		else
		{
			data='No Records';
			res.send(data);
		}	
	});
};		



// exports.addmembers = function(req, res, next) {
// 	var deptarr = [];
// 	if(req.body.datadept!='no'){
// 		deptarr = req.body.datadept.split("|");
// 	}

// 	var teamarr = [];
// 	if(req.body.datateam!='no'){
// 		teamarr = req.body.datateam.split("|");
// 	}
// 	var memberidarr = [];
// 	var memberinfo = [];
// 	var memberinfocnt = 0;
// 	var async = require('async');
// 	Department.find({_id:{$in:deptarr},company_id : req.session.uniqueid}, function(err, departments) {
// 		async.forEachSeries(departments, function(n1, callback_s1) {
// 			for(var i=0;i<n1.multiple_members.length;i++){
// 				n1.multiple_members[i] = n1.multiple_members[i].trim();
// 				var recExist = memberidarr.indexOf(n1.multiple_members[i]);
// 				if(recExist==-1){
// 					memberidarr.push(n1.multiple_members[i]);
// 					break;
// 				}
// 			}
// 			console.log(memberidarr); return false;
// 			callback_s1();
// 		}, function (err) {
// 			Team.find({_id:{$in:teamarr},company_id : req.session.uniqueid}, function(err, teams) {
// 				async.forEachSeries(teams, function(n2, callback_s2) {
// 					for(var i=0;i<n2.multiple_members.length;i++){
// 						n2.multiple_members[i] = n2.multiple_members[i].trim();
// 						var recExist = memberidarr.indexOf(n2.multiple_members[i]);
// 						if(recExist==-1){
// 							memberidarr.push(n2.multiple_members[i]);
// 							break;
// 						}
// 					}
// 					callback_s2();
// 				}, function (err) {
// 					var multiMemStr = '';
// 					Member.find({_id:{$in:memberidarr}}, function(err, members) {
// 						for(var mem=0;mem<members.length;mem++){
// 							multiMemStr+= "<option value='"+members[mem]._id+"'>"+members[mem].firstname+' '+members[mem].lastname+"</option>";
// 						}
// 						res.send(multiMemStr);
// 					});
// 				});
// 			});
// 		});
// 	});
// };

exports.create = function(req, res, next) {
	if(req.files.photo)
	{
		var loginHistoryObj = new LogActivity();
			if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id=='All')
			{
					var department_array=[];
					var team_array=[];
					var member_array=[];
						Department.find({company_id:req.session.uniqueid,status:'Active'},function(err,departments){
							for(i=0; i<departments.length; i++)
							{
								department_array.push(departments[i]._id);
								req.body.department_id=department_array;
							}
							Team.find({company_id:req.session.uniqueid,status:'Active'},function(err,teams){
							for(j=0; j<teams.length; j++)
							{
								team_array.push(teams[j]._id);
								req.body.team_id=team_array;
							}
							Member.find({company_id:req.session.uniqueid,status:'Active'},function(err,members){
							for(k=0; k<members.length; k++)
							{
								member_array.push(members[k]._id);
								req.body.member_id=member_array;
							}
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
							var fileExt = req.files.photo.name.split('.').pop();
							fileName = fileName+'.'+fileExt;
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.photo = fileName;
							/*challenge.starttimestamp = challenge.startdate+'T00:00:00.000Z';
							challenge.endtimestamp = challenge.enddate+'T23:59:59.000Z';*/
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
									sampleFile = req.files.photo;
									sampleFile.mv('./upload/challenges/'+fileName, function(err) {
									    var date = new Date();
										industry_name=req.body.title;
										loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
										loginHistoryObj.login_id = req.session.historyid;
										loginHistoryObj.posted =date;
										loginHistoryObj.save(function(err) {
											req.flash('info', 'New Challenge Added Successfully.');
											return res.redirect('/challenges/list');
										});
									});
								}
							});
						});
					});
				});			
				
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' &&  req.body.member_id=='All')
			{
				var team_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
 				var id1=typeof(id);
 				if(id1=='string')
 				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:id},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							//console.log(req.body.member_id);
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
							var fileExt = req.files.photo.name.split('.').pop();
							fileName = fileName+'.'+fileExt;
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.photo = fileName;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
									sampleFile = req.files.photo;
									sampleFile.mv('./upload/challenges/'+fileName, function(err) {
									    var date = new Date();
										industry_name=req.body.title;
										loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
										loginHistoryObj.login_id = req.session.historyid;
										loginHistoryObj.posted =date;
										loginHistoryObj.save(function(err) {
											req.flash('info', 'New Challenge Added Successfully.');
											return res.redirect('/challenges/list');
										});
									});
								}
							});
						});
					});
 				}
 				else
 				{
 					var team_array2=[];
					var member_array2=[];
					var id=req.body.department_id;
 					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:{$in:id}},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							//console.log(req.body.member_id);
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
							var fileExt = req.files.photo.name.split('.').pop();
							fileName = fileName+'.'+fileExt;
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.photo = fileName;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
									sampleFile = req.files.photo;
									sampleFile.mv('./upload/challenges/'+fileName, function(err) {
									    var date = new Date();
										industry_name=req.body.title;
										loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
										loginHistoryObj.login_id = req.session.historyid;
										loginHistoryObj.posted =date;
										loginHistoryObj.save(function(err) {
											req.flash('info', 'New Challenge Added Successfully.');
											return res.redirect('/challenges/list');
										});
									});
								}
							});
						});
					});

 				}					
			}
			else if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
				
					Team.find({status:'Active',company_id:req.session.uniqueid},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
						 //console.log(req.body.team_id);
							//console.log(req.body.member_id);
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
							var fileExt = req.files.photo.name.split('.').pop();
							fileName = fileName+'.'+fileExt;
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.photo = fileName;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
									sampleFile = req.files.photo;
									sampleFile.mv('./upload/challenges/'+fileName, function(err) {
									    var date = new Date();
										industry_name=req.body.title;
										loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
										loginHistoryObj.login_id = req.session.historyid;
										loginHistoryObj.posted =date;
										loginHistoryObj.save(function(err) {
											req.flash('info', 'New Challenge Added Successfully.');
											return res.redirect('/challenges/list');
										});
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
 					Member.find({status:'Active',company_id:req.session.uniqueid},function(err,members){
						for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
						 //console.log(req.body.team_id);
							//console.log(req.body.member_id);
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
							var fileExt = req.files.photo.name.split('.').pop();
							fileName = fileName+'.'+fileExt;
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.photo = fileName;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
									sampleFile = req.files.photo;
									sampleFile.mv('./upload/challenges/'+fileName, function(err) {
									    var date = new Date();
										industry_name=req.body.title;
										loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
										loginHistoryObj.login_id = req.session.historyid;
										loginHistoryObj.posted =date;
										loginHistoryObj.save(function(err) {
											req.flash('info', 'New Challenge Added Successfully.');
											return res.redirect('/challenges/list');
										});
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
					for(i=0; i<departments.length; i++)
						{
							dept_array2.push(departments[i]._id);
							req.body.department_id=dept_array2;
						}
					 //console.log(req.body.team_id);
						//console.log(req.body.member_id);
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
						var fileExt = req.files.photo.name.split('.').pop();
						fileName = fileName+'.'+fileExt;
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.photo = fileName;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
								sampleFile = req.files.photo;
								sampleFile.mv('./upload/challenges/'+fileName, function(err) {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								});
							}
						});
					});
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
						var fileExt = req.files.photo.name.split('.').pop();
						fileName = fileName+'.'+fileExt;
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.photo = fileName;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
								sampleFile = req.files.photo;
								sampleFile.mv('./upload/challenges/'+fileName, function(err) {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								});
							}
						});
					});
				}
				else
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
						var fileExt = req.files.photo.name.split('.').pop();
						fileName = fileName+'.'+fileExt;
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.photo = fileName;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
								sampleFile = req.files.photo;
								sampleFile.mv('./upload/challenges/'+fileName, function(err) {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								});
							}
						});
					});
				}
			}
			else if(req.body.department_id!=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_departments:id},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
					 //console.log(req.body.team_id);
						//console.log(req.body.member_id);
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
						var fileExt = req.files.photo.name.split('.').pop();
						fileName = fileName+'.'+fileExt;
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.photo = fileName;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
								sampleFile = req.files.photo;
								sampleFile.mv('./upload/challenges/'+fileName, function(err) {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								});
							}
						});
					});
				}
				else
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_departments:{$in:id}},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
						var fileExt = req.files.photo.name.split('.').pop();
						fileName = fileName+'.'+fileExt;
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.photo = fileName;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
								sampleFile = req.files.photo;
								sampleFile.mv('./upload/challenges/'+fileName, function(err) {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								});
							}
						});
					});
				}	
				
			}
			else 
			{
				var length = 10;
				var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
				var fileExt = req.files.photo.name.split('.').pop();
				fileName = fileName+'.'+fileExt;
				var challenge = new Challenge(req.body);
				challenge.company_id = req.session.uniqueid;
				challenge.photo = fileName;
				challenge.save(function(err) {
					if (err) {
						return next(err);
					}
					else {
						sampleFile = req.files.photo;
						sampleFile.mv('./upload/challenges/'+fileName, function(err) {
						    var date = new Date();
							industry_name=req.body.title;
							loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
							loginHistoryObj.login_id = req.session.historyid;
							loginHistoryObj.posted =date;
							loginHistoryObj.save(function(err) {
								req.flash('info', 'New Challenge Added Successfully.');
								return res.redirect('/challenges/list');
							});
						});
					}
				});
					
			}		
	}
// without photo
	else
	{
		var loginHistoryObj = new LogActivity();
			if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id=='All')
			{
				var department_array=[];
				var team_array=[];
				var member_array=[];
					Department.find({company_id:req.session.uniqueid,status:'Active'},function(err,departments){
						for(i=0; i<departments.length; i++)
						{
							department_array.push(departments[i]._id);
							req.body.department_id=department_array;
						}
						Team.find({company_id:req.session.uniqueid,status:'Active'},function(err,teams){
						for(j=0; j<teams.length; j++)
						{
							team_array.push(teams[j]._id);
							req.body.team_id=team_array;
						}
						Member.find({company_id:req.session.uniqueid,status:'Active'},function(err,members){
						for(k=0; k<members.length; k++)
						{
							member_array.push(members[k]._id);
							req.body.member_id=member_array;
						}
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
							    var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'New Challenge Added Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				});
			});			
				
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' &&  req.body.member_id=='All')
			{
				var team_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
 				var id1=typeof(id);
 				if(id1=='string')
 				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:id},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
 				}
 				else
 				{
 					var team_array2=[];
					var member_array2=[];
					var id=req.body.department_id;
 					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:{$in:id}},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
									    var date = new Date();
										industry_name=req.body.title;
										loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
										loginHistoryObj.login_id = req.session.historyid;
										loginHistoryObj.posted =date;
										loginHistoryObj.save(function(err) {
											req.flash('info', 'New Challenge Added Successfully.');
											return res.redirect('/challenges/list');
									});
								}
							});
						});
					});

 				}					
			}
			else if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Team.find({status:'Active',company_id:req.session.uniqueid},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							 var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
					Member.find({status:'Active',company_id:req.session.uniqueid},function(err,members){
						for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							 var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
					for(i=0; i<departments.length; i++)
						{
							dept_array2.push(departments[i]._id);
							req.body.department_id=dept_array2;
						}
						 var challenge = new Challenge(req.body);
							challenge.company_id = req.session.uniqueid;
							challenge.save(function(err) {
								if (err) {
									return next(err);
								}
								else {
								    var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'New Challenge Added Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
					});
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
							    var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'New Challenge Added Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
							    var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'New Challenge Added Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
			}
			else if(req.body.department_id!=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_departments:id},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						 var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
							    var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'New Challenge Added Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_departments:{$in:id}},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						var challenge = new Challenge(req.body);
						challenge.company_id = req.session.uniqueid;
						challenge.save(function(err) {
							if (err) {
								return next(err);
							}
							else {
							    var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'New Challenge Added Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}	
				
			}
			else 
			{
				var challenge = new Challenge(req.body);
					challenge.company_id = req.session.uniqueid;
					challenge.save(function(err) {
						if (err) {
							return next(err);
						}
						else {
						    var date = new Date();
							industry_name=req.body.title;
							loginHistoryObj.title = req.session.name+' added new challenge '+ industry_name;
							loginHistoryObj.login_id = req.session.historyid;
							loginHistoryObj.posted =date;
							loginHistoryObj.save(function(err) {
								req.flash('info', 'New Challenge Added Successfully.');
								return res.redirect('/challenges/list');
							});
						}
					});
					
			}	
		}	
	};	



// edit challenge
exports.edit = function(req, res, next) {
	var request = require('request');
	var fullUrl = req.protocol + '://' + req.get('host');
	var async = require('async');
	Challenge.findOne({_id : req.params.id}, function(err, challenge) {
		if(challenge.photo)
		{
			if(challenge.photo!='')
			{
				challenge.photo = fullUrl+'/challenges/'+challenge.photo;
			}
			else
			{
				challenge.photo = '';
			}
		}
		else
		{
			challenge.photo = '';
		}
		var memArr = challenge.member_id;
		var accepted_users = [],not_accepted_users = [];
		ChallengeAccept.find({ challenge_id: challenge._id}, function(err, challenge_accept) {
			async.forEachSeries(challenge_accept, function(cacc, callback_cacc) {
				if(_.contains(memArr, cacc.member_id)){
					accepted_users.push(cacc.member_id);
				}
				callback_cacc();
			}, function (err) {
				not_accepted_users = _.difference(memArr, accepted_users);
				var members_accepted_arr = [];
				Member.find({_id:{$in:accepted_users}}, function(err, members_accepted) {
					async.forEachSeries(members_accepted, function(memacc, callback_memacc) {
						var mem_obj = new Object;
						mem_obj.photo = (memacc.photo!='') ? fullUrl+'/member/'+memacc.photo : fullUrl+'/member/no_image_user.png';
						mem_obj.firstname = memacc.firstname;
						mem_obj.lastname = memacc.lastname;
						var url = "https://api.validic.com/v1/organizations/58eb9ceeff9d9300800000ad/users/"+memacc.validic_uid+"/fitness.json?access_token=1cfc38b63c8e0ed5cb8f37d1815ed6e1774f828be3558e75bfe259f2efc671d5&start_date="+challenge.startdate+"T00:00:00+00:00&end_date="+challenge.enddate+"T23:59:59+00:00&expanded=1";
						request(url, function (error, response, body) {
							var myjson = JSON.parse(body);
							var targetValue = 0;
							async.forEachSeries(myjson.fitness, function(maFit, callback_maFit) {
								if(maFit.type==challenge.category){
									targetValue+= maFit.steps;
								}
								callback_maFit();
							}, function (err) {
								mem_obj.target = challenge.target;
								mem_obj.totaltargetvalue = targetValue;
								mem_obj.percentage = parseInt((targetValue*100)/challenge.target);
								members_accepted_arr.push(mem_obj);
								callback_memacc();
							});
						});
					}, function (err) {
						var members_not_accepted_arr = [];
						Member.find({_id:{$in:not_accepted_users}}, function(err, members_not_accepted) {
							async.forEachSeries(members_not_accepted, function(memnotacc, callback_memnotacc) {
								var mem_obj = new Object;
								mem_obj.photo = (memnotacc.photo!='') ? fullUrl+'/member/'+memnotacc.photo : fullUrl+'/member/no_image_user.png';
								mem_obj.firstname = memnotacc.firstname;
								mem_obj.lastname = memnotacc.lastname;
								members_not_accepted_arr.push(mem_obj);
								callback_memnotacc();
							}, function (err) {
								Department.find({company_id : req.session.uniqueid,status:'Active'}, function(err, departments) {
									Team.find({company_id : req.session.uniqueid,status:'Active'}, function(err, teams) {
										Member.find({company_id : req.session.uniqueid,status:'Active'}, function(err, members) {
											var deptArr = [],
											teamArr = [],
											memberArr = [];
											async.forEachSeries(departments, function(n1, callback_s1) {
												var matchStatus = challenge.department_id.indexOf(n1._id);
												var singleDept = new Object;
												singleDept._id = n1._id;
												singleDept.title = n1.title;
												singleDept.matchStatus = (matchStatus==-1) ? 'No' : 'Yes';
												deptArr.push(singleDept);
												callback_s1();
											}, function (err) {
												async.forEachSeries(teams, function(n2, callback_s2) {
													var matchStatus = challenge.team_id.indexOf(n2._id);
													var singleTeam = new Object;
													singleTeam._id = n2._id;
													singleTeam.title = n2.title;
													singleTeam.matchStatus = (matchStatus==-1) ? 'No' : 'Yes';
													teamArr.push(singleTeam);
													callback_s2();
												}, function (err) {
													async.forEachSeries(members, function(n3, callback_s3) {
														var matchStatus = challenge.member_id.indexOf(n3._id);
														var singleMember = new Object;
														singleMember._id = n3._id;
														singleMember.name = n3.firstname+' '+n3.lastname;
														singleMember.matchStatus = (matchStatus==-1) ? 'No' : 'Yes';
														memberArr.push(singleMember);
														callback_s3();
													}, function (err) {
														res.render('company/challenges/edit', {
															logintype : req.session.type,
															loginid : req.session.id,
															loginname : req.session.name,
															loginemail : req.session.email,
															teams : teamArr,
															departments : deptArr,
															members : memberArr,
															challenge : challenge,
															members_accepted:members_accepted_arr,
															members_not_accepted:members_not_accepted_arr,
															messages: req.flash('error') || req.flash('info')
														});
													});
												});
											});
										});
									});
								});
							});
						});
					});
				});
			});
		});
	});
};

// remove photo
exports.removephoto = function(req, res, next) {
	var id = req.params.id;
	Challenge.findOne({
			_id: id
		}, 
		function(err, challenge) {
			if (err) {
				return next(err);
			}
			else {
				var fs = require('fs');
				var path = require('path');
				var appDir = path.dirname(require.main.filename);
				var filePath = appDir+'/upload/challenges/'+challenge.photo;
				fs.unlinkSync(filePath);

				var challengeUpdateObj = {
					photo:''
				};
				
				Challenge.findByIdAndUpdate(id, challengeUpdateObj, function(err, challengeRes) {
					if (err) {
						return next(err);
					}
					else {
						return res.redirect('/challenges/edit/'+id);
					}
				});
			}
		}
	);
};

// update department
exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.body.imgUpload=='Yes')
	{
		if(req.files.photo)
		{
			var loginHistoryObj = new LogActivity();
			if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id=='All')
			{
					var department_array=[];
					var team_array=[];
					var member_array=[];
						Department.find({company_id:req.session.uniqueid,status:'Active'},function(err,departments){
							for(i=0; i<departments.length; i++)
							{
								department_array.push(departments[i]._id);
								req.body.department_id=department_array;
							}
							Team.find({company_id:req.session.uniqueid,status:'Active'},function(err,teams){
							for(j=0; j<teams.length; j++)
							{
								team_array.push(teams[j]._id);
								req.body.team_id=team_array;
							}
							Member.find({company_id:req.session.uniqueid,status:'Active'},function(err,members){
							for(k=0; k<members.length; k++)
							{
								member_array.push(members[k]._id);
								req.body.member_id=member_array;
							}
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
							var fileExt = req.files.photo.name.split('.').pop();	
							fileName = fileName+'.'+fileExt;	
							sampleFile = req.files.photo;	
							sampleFile.mv('./upload/challenges/'+fileName, function(err) 
								{	
									if (err)	 
										return res.status(500).send(err);	
								});
							req.body.photo=fileName;
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
				});			
				
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' &&  req.body.member_id=='All')
			{
				var team_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
 				var id1=typeof(id);
 				if(id1=='string')
 				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:id},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
							var fileExt = req.files.photo.name.split('.').pop();	
							fileName = fileName+'.'+fileExt;	
							sampleFile = req.files.photo;	
							sampleFile.mv('./upload/challenges/'+fileName, function(err) 
								{	
									if (err)	 
										return res.status(500).send(err);	
								});
							req.body.photo=fileName;
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
 				}
 				else
 				{
 					var team_array2=[];
					var member_array2=[];
					var id=req.body.department_id;
 					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:{$in:id}},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
							var fileExt = req.files.photo.name.split('.').pop();	
							fileName = fileName+'.'+fileExt;	
							sampleFile = req.files.photo;	
							sampleFile.mv('./upload/challenges/'+fileName, function(err) 
								{	
									if (err)	 
										return res.status(500).send(err);	
								});
							req.body.photo=fileName;
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});

 				}					
			}
			else if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
				
					Team.find({status:'Active',company_id:req.session.uniqueid},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							 var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
							var fileExt = req.files.photo.name.split('.').pop();	
							fileName = fileName+'.'+fileExt;	
							sampleFile = req.files.photo;	
							sampleFile.mv('./upload/challenges/'+fileName, function(err) 
								{	
									if (err)	 
										return res.status(500).send(err);	
								});
							req.body.photo=fileName;
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
 					Member.find({status:'Active',company_id:req.session.uniqueid},function(err,members){
						for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
						 	var length = 10;
							var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
							var fileExt = req.files.photo.name.split('.').pop();	
							fileName = fileName+'.'+fileExt;	
							sampleFile = req.files.photo;	
							sampleFile.mv('./upload/challenges/'+fileName, function(err) 
								{	
									if (err)	 
										return res.status(500).send(err);	
								});
							req.body.photo=fileName;
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
					for(i=0; i<departments.length; i++)
						{
							dept_array2.push(departments[i]._id);
							req.body.department_id=dept_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
						var fileExt = req.files.photo.name.split('.').pop();	
						fileName = fileName+'.'+fileExt;	
						sampleFile = req.files.photo;	
						sampleFile.mv('./upload/challenges/'+fileName, function(err) 
							{	
								if (err)	 
									return res.status(500).send(err);	
							});
						req.body.photo=fileName;
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
						var fileExt = req.files.photo.name.split('.').pop();	
						fileName = fileName+'.'+fileExt;	
						sampleFile = req.files.photo;	
						sampleFile.mv('./upload/challenges/'+fileName, function(err) 
							{	
								if (err)	 
									return res.status(500).send(err);	
							});
						req.body.photo=fileName;
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
						var fileExt = req.files.photo.name.split('.').pop();	
						fileName = fileName+'.'+fileExt;	
						sampleFile = req.files.photo;	
						sampleFile.mv('./upload/challenges/'+fileName, function(err) 
							{	
								if (err)	 
									return res.status(500).send(err);	
							});
						req.body.photo=fileName;
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
			}
			else if(req.body.department_id!=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.team_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_teams:id},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
						var fileExt = req.files.photo.name.split('.').pop();	
						fileName = fileName+'.'+fileExt;	
						sampleFile = req.files.photo;	
						sampleFile.mv('./upload/challenges/'+fileName, function(err) 
							{	
								if (err)	 
									return res.status(500).send(err);	
							});
						req.body.photo=fileName;
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_teams:{$in:id}},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						var length = 10;
						var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
						var fileExt = req.files.photo.name.split('.').pop();	
						fileName = fileName+'.'+fileExt;	
						sampleFile = req.files.photo;	
						sampleFile.mv('./upload/challenges/'+fileName, function(err) 
							{	
								if (err)	 
									return res.status(500).send(err);	
							});
						req.body.photo=fileName;
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}	
				
			}
			else 
			{
				var length = 10;
				var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);	
				var fileExt = req.files.photo.name.split('.').pop();	
				fileName = fileName+'.'+fileExt;	
				sampleFile = req.files.photo;	
				sampleFile.mv('./upload/challenges/'+fileName, function(err) 
					{	
						if (err)	 
							return res.status(500).send(err);	
					});
				req.body.photo=fileName;
				Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
					if (err) {
						return next(err);
					}
					else {
						var date = new Date();
						industry_name=req.body.title;
						loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
						loginHistoryObj.login_id = req.session.historyid;
						loginHistoryObj.posted =date;
						loginHistoryObj.save(function(err) {
							req.flash('info', 'challenge Updated Successfully.');
							return res.redirect('/challenges/list');
						});
					}
				});
					
			}		
		}
		else
		{
			var loginHistoryObj = new LogActivity();
			if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id=='All')
			{
					var department_array=[];
					var team_array=[];
					var member_array=[];
						Department.find({company_id:req.session.uniqueid,status:'Active'},function(err,departments){
							for(i=0; i<departments.length; i++)
							{
								department_array.push(departments[i]._id);
								req.body.department_id=department_array;
							}
							Team.find({company_id:req.session.uniqueid,status:'Active'},function(err,teams){
							for(j=0; j<teams.length; j++)
							{
								team_array.push(teams[j]._id);
								req.body.team_id=team_array;
							}
							Member.find({company_id:req.session.uniqueid,status:'Active'},function(err,members){
							for(k=0; k<members.length; k++)
							{
								member_array.push(members[k]._id);
								req.body.member_id=member_array;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
				});			
				
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' &&  req.body.member_id=='All')
			{
				var team_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
 				var id1=typeof(id);
 				if(id1=='string')
 				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:id},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
 				}
 				else
 				{
 					var team_array2=[];
					var member_array2=[];
					var id=req.body.department_id;
 					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:{$in:id}},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});

 				}					
			}
			else if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Team.find({status:'Active',company_id:req.session.uniqueid},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
					Member.find({status:'Active',company_id:req.session.uniqueid},function(err,members){
						for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
					for(i=0; i<departments.length; i++)
						{
							dept_array2.push(departments[i]._id);
							req.body.department_id=dept_array2;
						}
						 Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
			}
			else if(req.body.department_id!=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.team_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_teams:id},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_teams:{$in:id}},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}	
				
			}
			else 
			{
				Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
					if (err) {
						return next(err);
					}
					else {
						var date = new Date();
						industry_name=req.body.title;
						loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
						loginHistoryObj.login_id = req.session.historyid;
						loginHistoryObj.posted =date;
						loginHistoryObj.save(function(err) {
							req.flash('info', 'challenge Updated Successfully.');
							return res.redirect('/challenges/list');
						});
					}
				});
					
			}	
		}
	}	
// without photo
	else
	{
		var loginHistoryObj = new LogActivity();
			if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id=='All')
			{
				var department_array=[];
				var team_array=[];
				var member_array=[];
					Department.find({company_id:req.session.uniqueid,status:'Active'},function(err,departments){
						for(i=0; i<departments.length; i++)
						{
							department_array.push(departments[i]._id);
							req.body.department_id=department_array;
						}
						Team.find({company_id:req.session.uniqueid,status:'Active'},function(err,teams){
						for(j=0; j<teams.length; j++)
						{
							team_array.push(teams[j]._id);
							req.body.team_id=team_array;
						}
						Member.find({company_id:req.session.uniqueid,status:'Active'},function(err,members){
						for(k=0; k<members.length; k++)
						{
							member_array.push(members[k]._id);
							req.body.member_id=member_array;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				});
			});			
				
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' &&  req.body.member_id=='All')
			{
				var team_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
 				var id1=typeof(id);
 				if(id1=='string')
 				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:id},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
 				}
 				else
 				{
 					var team_array2=[];
					var member_array2=[];
					var id=req.body.department_id;
 					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						 //console.log(req.body.team_id);
						Member.find({company_id:req.session.uniqueid,status:'Active',multiple_departments:{$in:id}},function(err,members){
							for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});

 				}					
			}
			else if(req.body.department_id=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Team.find({status:'Active',company_id:req.session.uniqueid},function(err,teams){
						for(i=0; i<teams.length; i++)
							{
								team_array2.push(teams[i]._id);
								req.body.team_id=team_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
					Member.find({status:'Active',company_id:req.session.uniqueid},function(err,members){
						for(i=0; i<members.length; i++)
							{
								member_array2.push(members[i]._id);
								req.body.member_id=member_array2;
							}
						Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
						for(i=0; i<departments.length; i++)
							{
								dept_array2.push(departments[i]._id);
								req.body.department_id=dept_array2;
							}
							Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
								if (err) {
									return next(err);
								}
								else {
									var date = new Date();
									industry_name=req.body.title;
									loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
									loginHistoryObj.login_id = req.session.historyid;
									loginHistoryObj.posted =date;
									loginHistoryObj.save(function(err) {
										req.flash('info', 'challenge Updated Successfully.');
										return res.redirect('/challenges/list');
									});
								}
							});
						});
					});
			}
			else if(req.body.department_id=='All' && req.body.team_id!=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.member_id;
				var id1=typeof(id);
					Department.find({status:'Active',company_id:req.session.uniqueid},function(err,departments){
					for(i=0; i<departments.length; i++)
						{
							dept_array2.push(departments[i]._id);
							req.body.department_id=dept_array2;
						}
						 Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
			}
			else if(req.body.department_id!=='All' && req.body.team_id=='All' && req.body.member_id!=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.department_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:id},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Team.find({status:'Active',company_id:req.session.uniqueid,department_id:{$in:id}},function(err,teams){
					for(i=0; i<teams.length; i++)
						{
							team_array2.push(teams[i]._id);
							req.body.team_id=team_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
			}
			else if(req.body.department_id!=='All' && req.body.team_id!=='All' && req.body.member_id=='All')
			{
				var team_array2=[];
				var dept_array2=[];
				var member_array2=[];
				var id=req.body.team_id;
				var id1=typeof(id);
				if(id1=='string')
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_teams:id},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}
				else
				{
					Member.find({status:'Active',company_id:req.session.uniqueid,multiple_teams:{$in:id}},function(err,members){
					for(i=0; i<members.length; i++)
						{
							member_array2.push(members[i]._id);
							req.body.member_id=member_array2;
						}
						Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
							if (err) {
								return next(err);
							}
							else {
								var date = new Date();
								industry_name=req.body.title;
								loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									req.flash('info', 'challenge Updated Successfully.');
									return res.redirect('/challenges/list');
								});
							}
						});
					});
				}	
				
			}
			else 
			{
				Challenge.findByIdAndUpdate(req.body.challenge_id, req.body, function(err, state) {
					if (err) {
						return next(err);
					}
					else {
						var date = new Date();
						industry_name=req.body.title;
						loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
						loginHistoryObj.login_id = req.session.historyid;
						loginHistoryObj.posted =date;
						loginHistoryObj.save(function(err) {
							req.flash('info', 'challenge Updated Successfully.');
							return res.redirect('/challenges/list');
						});
					}
				});
					
			}	
		}	
	};	


// update challenges
// exports.update = function(req, res, next) {
// 	var loginHistoryObj = new LogActivity();
// 	var challenge = req.body;
// 	var challenge_id = challenge.challenge_id;
// 	challenge.company_id = req.session.uniqueid;
// 	delete challenge.challenge_id;
// 	if(challenge.imgUpload=='Yes'){
// 		var length = 10;
// 		var fileName = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1);
// 		var fileExt = req.files.photo.name.split('.').pop();
// 		fileName = fileName+'.'+fileExt;
// 		challenge.photo = fileName;		
// 		sampleFile = req.files.photo;
// 		sampleFile.mv('./upload/challenges/'+fileName, function(err) {});
// 	}
// 	else {
// 		delete challenge.photo;
// 	}
// 	delete challenge.imgUpload;
// 	Challenge.findByIdAndUpdate(challenge_id, challenge, function(err, challenge) {
// 		if (err) {
// 			return next(err);
// 		}
// 		else {
// 		      	var date = new Date();
// 				industry_name=req.body.title;
// 				loginHistoryObj.title = req.session.name+' updated challenge '+ industry_name;
// 				loginHistoryObj.login_id = req.session.historyid;
// 				loginHistoryObj.posted =date;
// 				console.log(loginHistoryObj.login_id);
// 				console.log(loginHistoryObj);
// 				loginHistoryObj.save(function(err) {
// 			});
// 			req.flash('info', 'Challenge Updated Successfully.');
// 			return res.redirect('/challenges/list');
// 		}
// 	});
// };

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Challenge.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Challenge.findOne({_id:n1},function(err, challenge){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  challenge '+ challenge.title;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/challenges/list');
						});
						
					}
				}
			)
			break;
	}
	
};