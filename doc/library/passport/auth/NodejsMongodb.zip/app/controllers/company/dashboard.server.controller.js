var MembersEmotionalAnalytics = require('mongoose').model('MembersEmotionalAnalytics'),
MemberCalories = require('mongoose').model('MemberCalories'),
MemberSteps = require('mongoose').model('MemberSteps'),
MemberHeartBitRate = require('mongoose').model('MemberHeartBitRate'),
MemberSleep = require('mongoose').model('MemberSleep'),
Member = require('mongoose').model('Member'),
Challenge = require('mongoose').model('Challenge'),
Department = require('mongoose').model('Department'),
Team = require('mongoose').model('Team'),
moment = require('moment'),
_ = require('underscore'),
_this = this,
async = require('async');

exports.postCurrentDate = function(req, res) {
	var currentDate = new Date();
	var match_month = (currentDate.getMonth()+1);
	match_month = ('0' + match_month).slice(-2);
	var match_day = (currentDate.getDate());
	match_day = ('0' + match_day).slice(-2);
	return currentDate.getFullYear()+'-' +match_month+ '-'+match_day;
};

exports.list = function(req, res, next) {
	var currentDate = _this.postCurrentDate(req,res);
	var d = new Date(currentDate);
 	d.setDate(d.getDate()-5);

 	var match_month = (d.getMonth()+1);
	match_month = ('0' + match_month).slice(-2);
	var match_day = (d.getDate());
	match_day = ('0' + match_day).slice(-2);
	var startdate = d.getFullYear()+'-' +match_month+ '-'+match_day;
	var enddate = currentDate;
	Member.count({company_id : req.session.uniqueid,status:'Active'}, function(err, totmember) {
		if (err) {
			return next(err);
		}
		else {
			Challenge.count({company_id : req.session.uniqueid,status:'Active'}, function(err, totchallenge) {
				if (err) {
					return next(err);
				}
				else {
					Department.find({company_id : req.session.uniqueid,status:'Active'}, function(err, departments) {
						if (err) {
							return next(err);
						}
						else {
							Team.find({company_id : req.session.uniqueid,status:'Active'}, function(err, teams) {
								if (err) {
									return next(err);
								}
								else {
									res.render('company/dashboard/list', {
										logintype : req.session.type,
										loginid : req.session.id,
										loginname : req.session.name,
										loginemail : req.session.email,
										totalmembers : totmember,
										totalchallenges : totchallenge,
										departments : departments,
										teams : teams,
										totaldepartments : departments.length,
										totalteams : teams.length,
										startdate : startdate,
										enddate : enddate,
										messages: req.flash('error') || req.flash('info')
									});
								}
							}).sort({created_at: 'desc'})
						}
					}).sort({created_at: 'desc'})
				}
			});
		}
	});
};

exports.postRangeStartEndDates = function(req, res, startDate, stopDate) {
	var dateArray = [];
	var currentDate = moment(startDate);
	stopDate = moment(stopDate);
	while (currentDate <= stopDate) {
	    dateArray.push( moment(currentDate).format('YYYY-MM-DD') )
	    currentDate = moment(currentDate).add(1, 'days');
	}
	return dateArray;
};

exports.loadDashboardChart = function(req,res){
	var department = team = feature = gender = age = smoking = drinking = startdate = enddate = '';
	var deptarr = teamarr = featurearr = [];
	department = req.query.department;
	deptarr = department.split('|');
	team = req.query.team;
	teamarr = team.split('|');
	feature = req.query.feature;
	featurearr = feature.split('|');
	gender = req.query.gender;
	age = req.query.age;
	smoking = req.query.smoking;
	drinking = req.query.drinking;
	startdate = req.query.startdate;
	enddate = req.query.enddate;
	smoking = (smoking=='Smoker') ? 'Yeah' : 'Nope';
	drinking = (drinking=='Drinker') ? 'Yeah' : 'Nope';
	var whereParamObj = new Object();
	if(gender!='All'){
		whereParamObj.sex = gender;
	}
	var startdateunixtimestamp = moment(startdate, 'YYYY-MM-DD').unix();
	startdateunixtimestamp+= 86400;
	if(age!='All'){
		if(age=='<18'){
			whereParamObj.age = {"$lt": 18};
		}
		else if(age=='>60'){
			whereParamObj.age = {"$gt": 60};
		}
		else {
			var dateRange = {"$gte": 18, "$lte": 30};
			whereParamObj.age = dateRange;
		}
	}
	if(req.query.smoking!='All'){
		whereParamObj.smoker = smoking;
	}
	if(req.query.drinking!='All'){
		whereParamObj.drinker = drinking;
	}
	
	if(deptarr.length>1){
		Department.find({_id: {$in: deptarr},company_id : req.session.uniqueid,status:'Active'}, function(err, departments) {
			var resDateRange = _this.postRangeStartEndDates(req,res,startdate,enddate);
			var chartInfo = [];
			async.forEachSeries(departments, function(singleDepartment, callback_singleDepartment) {
				var deptChartInfo = [];
				var deptObj = { $elemMatch: { $eq: String(singleDepartment._id) } };
				var teamObj = { $elemMatch: { $in: teamarr } };
				whereParamObj.multiple_departments = deptObj;
				whereParamObj.multiple_teams = teamObj;
				var valenceScore = [],caloriesBurned = [],stepsTaken = [],heartRate = [],sleep = [];
				Member.find(whereParamObj,{"_id":true}, function(err, members) {
					var memIds = _.pluck(members, '_id');
					memIds = memIds.join().split(',');
					async.forEachSeries(resDateRange, function(singleDate, callback_singleDate) {
						function valenceScoreFunc(callback) {
							if(_.contains(featurearr, 'Valence Score')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"currentDate": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$valence_score" }
					                    }
					                }
					            ];

					            MembersEmotionalAnalytics.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgValenceScore = 0;
				                    if(!err && result.length>0){
				                    	avgValenceScore = result[0].average;
				                    }
				                    deptChartInfo.push(parseFloat((avgValenceScore).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function caloriesBurnedFunc(callback) {
							if(_.contains(featurearr, 'Calories Burned')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$calories_burned" }
					                    }
					                }
					            ];

					            MemberCalories.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgCaloriesBurned = 0;
				                    if(!err && result.length>0){
				                    	avgCaloriesBurned = result[0].average;
				                    }
				                    deptChartInfo.push(parseFloat((avgCaloriesBurned).toFixed(2)));
				                    callback();
				                })	
							}else {
								callback();
							}
						}

						function stepsTakenFunc(callback) {
							if(_.contains(featurearr, 'Steps Taken')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$steps" }
					                    }
					                }
					            ];

					            MemberSteps.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgSteps = 0;
				                    if(!err && result.length>0){
				                    	avgSteps = result[0].average;
				                    }
				                    deptChartInfo.push(parseFloat((avgSteps).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function heartRateFunc(callback) {
							if(_.contains(featurearr, 'Heart Rate')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$resting_heart_rate" }
					                    }
					                }
					            ];

					            MemberHeartBitRate.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgHeartRate = 0;
				                    if(!err && result.length>0){
				                    	result[0].average = (result[0].average==null) ? 0 : result[0].average;
				                    	avgHeartRate = result[0].average;
				                    }
				                    deptChartInfo.push(parseFloat((avgHeartRate).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function sleepFunc(callback) {
							if(_.contains(featurearr, 'Sleep')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$total_sleep" }
					                    }
					                }
					            ];

					            MemberSleep.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgSleep = 0;
				                    if(!err && result.length>0){
				                    	avgSleep = result[0].average;
				                    }
				                    deptChartInfo.push(parseFloat((avgSleep).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						async.series([valenceScoreFunc, caloriesBurnedFunc,stepsTakenFunc,heartRateFunc,sleepFunc], function (err, results) {
							callback_singleDate();    
						});
					}, function (err) {
						chartInfo.push(deptChartInfo);
						callback_singleDepartment();
					});
				});
			}, function (err) {
				res.render('company/dashboard/ajax_load_company_overview', {
					departments : departments,
					teams : [],
					chartInfo : chartInfo,
					features : [],
					features : featurearr,
					valenceScore : [],
					caloriesBurned : [],
					stepsTaken : [],
					heartRate : [],
					sleep : [],
					startdateunixtimestamp:startdateunixtimestamp,
					layout : false
				});
			});
		}).sort({created_at: 'desc'})
	}
	else if(teamarr.length>1){
		Team.find({_id: {$in: teamarr},company_id : req.session.uniqueid,status:'Active'}, function(err, teams) {
			var resDateRange = _this.postRangeStartEndDates(req,res,startdate,enddate);
			var chartInfo = [];
			async.forEachSeries(teams, function(singleTeam, callback_singleTeam) {
				var teamChartInfo = [];
				var teamObj = { $elemMatch: { $eq: String(singleTeam._id) } };
				whereParamObj.multiple_teams = teamObj;
				var valenceScore = [],caloriesBurned = [],stepsTaken = [],heartRate = [],sleep = [];
				Member.find(whereParamObj,{"_id":true}, function(err, members) {
					var memIds = _.pluck(members, '_id');
					memIds = memIds.join().split(',');
					async.forEachSeries(resDateRange, function(singleDate, callback_singleDate) {
						function valenceScoreFunc(callback) {
							if(_.contains(featurearr, 'Valence Score')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"currentDate": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$valence_score" }
					                    }
					                }
					            ];

					            MembersEmotionalAnalytics.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgValenceScore = 0;
				                    if(!err && result.length>0){
				                    	avgValenceScore = result[0].average;
				                    }
				                    teamChartInfo.push(parseFloat((avgValenceScore).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function caloriesBurnedFunc(callback) {
							if(_.contains(featurearr, 'Calories Burned')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$calories_burned" }
					                    }
					                }
					            ];

					            MemberCalories.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgCaloriesBurned = 0;
				                    if(!err && result.length>0){
				                    	avgCaloriesBurned = result[0].average;
				                    }
				                    teamChartInfo.push(parseFloat((avgCaloriesBurned).toFixed(2)));
				                    callback();
				                })	
							}else {
								callback();
							}
						}

						function stepsTakenFunc(callback) {
							if(_.contains(featurearr, 'Steps Taken')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$steps" }
					                    }
					                }
					            ];

					            MemberSteps.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgSteps = 0;
				                    if(!err && result.length>0){
				                    	avgSteps = result[0].average;
				                    }
				                    teamChartInfo.push(parseFloat((avgSteps).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function heartRateFunc(callback) {
							if(_.contains(featurearr, 'Heart Rate')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$resting_heart_rate" }
					                    }
					                }
					            ];

					            MemberHeartBitRate.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgHeartRate = 0;
				                    if(!err && result.length>0){
				                    	result[0].average = (result[0].average==null) ? 0 : result[0].average;
				                    	avgHeartRate = result[0].average;
				                    }
				                    teamChartInfo.push(parseFloat((avgHeartRate).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function sleepFunc(callback) {
							if(_.contains(featurearr, 'Sleep')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$total_sleep" }
					                    }
					                }
					            ];

					            MemberSleep.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgSleep = 0;
				                    if(!err && result.length>0){
				                    	avgSleep = result[0].average;
				                    }
				                    teamChartInfo.push(parseFloat((avgSleep).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						async.series([valenceScoreFunc, caloriesBurnedFunc,stepsTakenFunc,heartRateFunc,sleepFunc], function (err, results) {
							callback_singleDate();    
						});
					}, function (err) {
						chartInfo.push(teamChartInfo);
						callback_singleTeam();
					});
				});
			}, function (err) {
				res.render('company/dashboard/ajax_load_company_overview', {
					departments : [],
					teams : teams,
					chartInfo : chartInfo,
					features : [],
					features : featurearr,
					valenceScore : [],
					caloriesBurned : [],
					stepsTaken : [],
					heartRate : [],
					sleep : [],
					startdateunixtimestamp:startdateunixtimestamp,
					layout : false
				});
			});
		}).sort({created_at: 'desc'})
	}
	else {
		var resDateRange = _this.postRangeStartEndDates(req,res,startdate,enddate);
		var teamObj = { $elemMatch: { $eq: teamarr[0] } };
		whereParamObj.multiple_teams = teamObj;
		var chartInfo = [];
		var valenceScore = [],caloriesBurned = [],stepsTaken = [],heartRate = [],sleep = [];
		Member.find(whereParamObj,{"_id":true}, function(err, members) {
			var memIds = _.pluck(members, '_id');
			memIds = memIds.join().split(',');
			async.forEachSeries(resDateRange, function(singleDate, callback_singleDate) {
				function valenceScoreFunc(callback) {
					if(_.contains(featurearr, 'Valence Score')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"currentDate": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$valence_score" }
			                    }
			                }
			            ];

			            MembersEmotionalAnalytics.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgValenceScore = 0;
		                    if(!err && result.length>0){
		                    	avgValenceScore = result[0].average;
		                    }
		                    valenceScore.push(parseFloat((avgValenceScore).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				function caloriesBurnedFunc(callback) {
					if(_.contains(featurearr, 'Calories Burned')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$calories_burned" }
			                    }
			                }
			            ];

			            MemberCalories.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgCaloriesBurned = 0;
		                    if(!err && result.length>0){
		                    	avgCaloriesBurned = result[0].average;
		                    }
		                    caloriesBurned.push(parseFloat((avgCaloriesBurned).toFixed(2)));
		                    callback();
		                })	
					}else {
						callback();
					}
				}

				function stepsTakenFunc(callback) {
					if(_.contains(featurearr, 'Steps Taken')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$steps" }
			                    }
			                }
			            ];

			            MemberSteps.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgSteps = 0;
		                    if(!err && result.length>0){
		                    	avgSteps = result[0].average;
		                    }
		                    stepsTaken.push(parseFloat((avgSteps).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				function heartRateFunc(callback) {
					if(_.contains(featurearr, 'Heart Rate')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$resting_heart_rate" }
			                    }
			                }
			            ];

			            MemberHeartBitRate.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgHeartRate = 0;
		                    if(!err && result.length>0){
		                    	result[0].average = (result[0].average==null) ? 0 : result[0].average;
		                    	avgHeartRate = result[0].average;
		                    }
		                    heartRate.push(parseFloat((avgHeartRate).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				function sleepFunc(callback) {
					if(_.contains(featurearr, 'Sleep')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$total_sleep" }
			                    }
			                }
			            ];

			            MemberSleep.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgSleep = 0;
		                    if(!err && result.length>0){
		                    	avgSleep = result[0].average;
		                    }
		                    sleep.push(parseFloat((avgSleep).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				async.series([valenceScoreFunc, caloriesBurnedFunc,stepsTakenFunc,heartRateFunc,sleepFunc], function (err, results) {
					callback_singleDate(); 
				});
			}, function (err) {
				res.render('company/dashboard/ajax_load_company_overview', {
					chartInfo : chartInfo,
					departments : [],
					teams : [],
					features : featurearr,
					valenceScore : valenceScore,
					caloriesBurned : caloriesBurned,
					stepsTaken : stepsTaken,
					heartRate : heartRate,
					sleep : sleep,
					startdateunixtimestamp:startdateunixtimestamp,
					layout : false
				});
			});
		});
	}
};

exports.loadTeam = function(req,res){
	var dept = req.query.department;
	var deptArr = dept.split('|');
	Team.find({"department_id" : {$in: deptArr},status:'Active'}, function(err, teams) {
		var teamStr = "<option value='All'>All</option>";
		for(var t=0;t<teams.length;t++){
			teamStr+= "<option value='"+teams[t]._id+"'>"+teams[t].title+"</option>";
		}
		res.send(teamStr);
		return false;
	}).sort({created_at: 'desc'})
};