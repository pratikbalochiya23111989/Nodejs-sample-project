var CMS = require('mongoose').model('CMS');
var Superadmin = require('mongoose').model('Superadmin');
var Administrator = require('mongoose').model('Administrator');
var Company = require('mongoose').model('Company');
var Industry = require('mongoose').model('Industry');
var LogActivity = require('mongoose').model('LogActivity');
var InsuranceTypes = require('mongoose').model('InsuranceTypes');
var Country = require('mongoose').model('Country');
var State = require('mongoose').model('State');
var moment = require('moment');

// Terms and condition
exports.termsAndCondition = function(req, res, next) {
	CMS.find({code:'TERMS_AND_CONDITION'}, function(err, cms) {
		if (err) {
			return next(err);
		}
		else {
			res.render('terms-and-condition', {
				layout:false,
				cms: cms[0],
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info')
			});
		}
	}).sort({created_at:'desc'});
};

exports.changepassword = function(req, res, next) {
	res.render('changepassword/changepassword', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info'),
		messages:req.flash('info'),
		moment: moment
	});
};

exports.changedpassword = function(req, res, next) {
	var md5 = require('md5');
	var updateObj = {
			password : md5(req.body.password)
		}
	Superadmin.findOne({_id : req.session.uniqueid}, function(err, superadmin) {
			if(superadmin){
				Superadmin.findByIdAndUpdate(superadmin._id, updateObj, function(err, superadminRes) {
					req.flash('info', 'Your password changed successfully!')
					return res.redirect('/changepassword');
				});
			}else {
				Administrator.findOne({_id : req.session.uniqueid}, function(err, administrator) {
					if(administrator){
						Administrator.findByIdAndUpdate(administrator._id, updateObj, function(err, administratorRes) {
							req.flash('info', 'Your password changed successfully!')
							res.redirect('/changepassword');
						});	
					}
					else {
						Company.findOne({_id : req.session.uniqueid}, function(err, company) {
							if(company){
								Company.findByIdAndUpdate(company._id, updateObj, function(err, companyRes) {
									req.flash('info', 'Your password changed successfully!')
									res.redirect('/changepassword');
								});
							}
						});
					}
				});
			}
		});
};

exports.updateprofile = function(req, res, next) {
	if(req.session.type=='Superadmin')
	{
		Superadmin.findOne({_id : req.session.uniqueid}, function(err, superadmin) {
			res.render('superadmin/accountsetting/accountsetting', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			administrator : superadmin,
			messages: req.flash('error') || req.flash('info'),
			messages:req.flash('info'),
			moment: moment
			});
		});
	}
	if(req.session.type=='Admin')
	{
		Administrator.findOne({_id : req.session.uniqueid}, function(err, admin) {
			res.render('admin/accountsetting/accountsetting', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			administrator : admin,
			messages: req.flash('error') || req.flash('info'),
			messages:req.flash('info'),
			moment: moment
			});
		});
	}
	if(req.session.type=='Company')
	{
		Company.findOne({_id : req.session.uniqueid}, function(err, company) {
			Industry.find({status:'Active'},function(err,industry){
				InsuranceTypes.find({status:'Active'},function(err,insurancetypes){
					Country.find({status:'Active'},function(err,country){
						State.find({status:'Active'},function(err,state){
								res.render('company/accountsetting/accountsetting', {
								logintype : req.session.type,
								loginid : req.session.uniqueid,
								loginname : req.session.name,
								loginemail : req.session.email,
								administrator : company,
								industry,industry,
								insurancetypes:insurancetypes,
								country,country,
								state,state,
								messages: req.flash('error') || req.flash('info'),
								messages:req.flash('info'),
								moment: moment
							});
						});
					});
				});
			});
		});
	}
};

exports.updatedprofile = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	if(req.session.type=='Superadmin')
	{
		Superadmin.findByIdAndUpdate(req.body.admin_id, req.body, function(err, superadmin) {
			if (err) {
				return next(err);
			}
			else {
					var date = new Date();
					loginHistoryObj.title = req.session.name+' updated their profile';
					loginHistoryObj.login_id = req.session.historyid;
					loginHistoryObj.posted =date;
					loginHistoryObj.save(function(err) {
					});
					req.session.name=req.body.firstname+' '+req.body.lastname;
					req.session.email=req.body.email;

				//console.log(req.session.firstname);return false;
				//req.flash('info', 'Administrator Updated Successfully.');
				return res.redirect('/superadmin/dashboard/list');
			}
		});
	}
	if(req.session.type=='Admin')
	{
		Administrator.findByIdAndUpdate(req.body.admin_id, req.body, function(err, administrator) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				loginHistoryObj.title = req.session.name+' updated their profile';
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.session.name=req.body.firstname+' '+req.body.lastname;
					req.session.email=req.body.email;
				//req.flash('info', 'Administrator Updated Successfully.');
				return res.redirect('/admin/dashboard/list');
			}
		});
	}
	if(req.session.type=='Company')
	{
		Company.findByIdAndUpdate(req.body.admin_id, req.body, function(err, company) {
			if (err) {
				return next(err);
			}
			else {
				var date = new Date();
				loginHistoryObj.title = req.session.name+' updated their profile';
				loginHistoryObj.login_id = req.session.historyid;
				loginHistoryObj.posted =date;
				loginHistoryObj.save(function(err) {
				});
				req.session.name=req.body.firstname+' '+req.body.lastname;
				req.session.email=req.body.email;
				//req.flash('info', 'Administrator Updated Successfully.');
				return res.redirect('/dashboard/list');
			}
		});
	}
};