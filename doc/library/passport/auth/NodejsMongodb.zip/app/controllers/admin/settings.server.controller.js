var Setting = require('mongoose').model('Setting');

// edit setting
exports.edit = function(req, res, next) {
	Setting.find({}, function(err, settings) {
		if (err) {
			return next(err);
		}
		else {
			res.render('admin/settings/edit', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				settings : settings,
				messages : req.flash('error') || req.flash('info'),
				messages : req.flash('info')
			});
		}
	});
};

// update setting
exports.update = function(req, res, next) {
	var setval = new Object();
	var all_settings = req.body;
	for (var key in all_settings) {
	  	setval.value = all_settings[key];
	  	Setting.findByIdAndUpdate(key, setval, function(err, setting) {
			if (err) {
				return next(err);
			}
		});
	}
	req.flash('info', 'Settings Updated Successfully.');
	return res.redirect('/admin/setting/edit');
};