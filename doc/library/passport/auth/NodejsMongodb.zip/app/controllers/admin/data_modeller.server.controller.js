var moment = require('moment')

// list data_modeller
exports.list = function(req, res, next) {
	res.render('admin/data_modeller/list', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages : req.flash('error') || req.flash('info'),
		messages : req.flash('info'),
		moment : moment
	});
};