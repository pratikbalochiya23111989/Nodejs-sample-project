var LoginLog = require('mongoose').model('LoginLog');
var LogActivity = require('mongoose').model('LogActivity');
var Company = require('mongoose').model('Company');
var moment = require('moment')

// list login logs
exports.list = function(req, res, next) {
	var date=new Date();
	var oneWeekAgo = new Date();
	oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);
	Company.find({insurance_id : req.session.uniqueid,}, function(err, allcompanies) {
		var allEmailArr = [];
		for (var i = 0; i < allcompanies.length; i++) {
			allEmailArr.push(allcompanies[i].hr_email);
		}
		LoginLog.find({email : {$in: allEmailArr},user_type: 'HR',created_at:{$gte:oneWeekAgo,$lte:date}}, function(err, loginlogs	) {
			LogActivity.find({login_id:loginlogs._id }, function(err, logs) {
				if (err) {
					return next(err);
				}
				else {
					res.render('admin/loginlogs/list', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						loginlogs: loginlogs,
						messages: req.flash('error') || req.flash('info'),
						messages:req.flash('info'),
						moment: moment
					});
				}
			});				
		}).sort({created_at:'desc'});
	});
};

exports.list_action = function(req, res, next) {
	var action = req.body.btnAction
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Deleted":
			LoginLog.deleteMany(
				{ '_id':{ $in : req.body.iId } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Deleted Successfully.');
						return res.redirect('/admin/loginlogs/list');
					}
				}
			)
			break;
	}
	
};

exports.logactivity = function(req, res, next) {
	var id=req.body.id;
	LogActivity.find({login_id:id}, function(err, logs) {
		LoginLog.findOne({_id :logs.login_id}, function(err, loginlogs) {
		if (err) {
			return next(err);
		}
		else {
			var j=1;
			var data="<tr>\
			<th width='10%' colspan='5' class='tbl_center' style='font: bold !important;color: black;''>Sr No.</th>\
			<th width='60%' colspan='3' class='tbl_pad_left' style='font: bold !important;color: black;''>Activities Description</th>\
			<th width='30%' colspan='6' class='tbl_pad_left' style='font: bold !important;color: black;''>Activities Date & Time</th></tr>\
			";
			if(logs.length>0)
			{

			for(var i=0; i < logs.length; i++) { 
				if(logs[i].posted) {  
				var	str=moment(logs[i].posted).format( 'Do MMM  YYYY, h:mm a') 
				};
			
			data+="<tr>\
				<td width='10%' colspan='5' class='tbl_center'>"+j+++"</td>\
				<td width='60%' colspan='3' class='tbl_pad_left'>"+logs[i].title+"</td>\
				<td width='30%' colspan='6' class='tbl_pad_left'>"+str+"</td>\
						</tr>";
			};
		}
		else
		{
			data+="<tr>\
				<td width='10%' colspan='14' class='tbl_center'>No Record Available</td>";
		}
		res.send(JSON.stringify(data));
		}
	});
	});
	
};