var Company = require('mongoose').model('Company');
var State = require('mongoose').model('State');
var Country = require('mongoose').model('Country');
var Industry = require('mongoose').model('Industry');
var EmailTemplate = require('mongoose').model('EmailTemplate');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var moment = require('moment')

// list administrator
exports.list = function(req, res, next) {
	Company.find({status:{$ne : 'Deleted'},insurance_id:req.session.uniqueid}, function(err, companies) {
		if (err) {
			return next(err);
		}
		else {
			res.render('admin/companies/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				companies: companies,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new question 
exports.add = function(req, res, next) {
	Industry.find({status:'Active'}, function(err, industries) {
		Country.find({status:'Active'}, function(err, countries) {
			State.find({status:'Active',country_id:countries[0]._id}, function(err, states) {
				res.render('admin/companies/add', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					industries : industries,
					countries : countries,
					states : states,
					messages: req.flash('error') || req.flash('info')
				});
			});
		});
	}).sort({created_at:'desc'});
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var md5 = require('md5');
	var originalPassword = req.body.password;
	req.body.password = md5(req.body.password);
	req.body.insurance_id = req.session.uniqueid;
	var company = new Company(req.body);
	company.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new company '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Company Added Successfully.');
			return res.redirect('/admin/company/list');
			/*EmailTemplate.findOne({code: 'SIGNUP'}, function(err, emailcontent) {
				var text = emailcontent.content;
				text = text.replace("#NAME#", (req.body.firstname+' '+req.body.lastname)).replace("#EMAIL#", req.body.hr_email).replace("#PASSWORD#", originalPassword);
				
				var api_key = 'key-43cf4c016eb85a389fc22df0dd7bf6f4';
				var domain = 'dotzapper.com';
				var mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});
				 
				var data = {
				  	from: 'Brio <demo1.testing1@gmail.com>',
				  	to: req.body.hr_email,
				  	subject: 'Thank you for sign up at Brio',
				  	html: text
				};
				 
				mailgun.messages().send(data, function (error, body) {
				  	req.flash('info', 'New Company Added Successfully.');
					return res.redirect('/admin/company/list');
				});
			});*/
		}
	});
};

exports.edit = function(req, res, next) {
	var id = req.params.id;
	Industry.find({status:'Active'}, function(err, industries) {
		Company.findOne({
				_id: id
			}, 
			function(err, com) {
				if (err) {
					return next(err);
				}
				else {
					Country.find({status:'Active'}, function(err, countries) {
						State.find({status:'Active',country_id:com.country_id}, function(err, states) {
							res.render('admin/companies/edit', {
								logintype : req.session.type,
								loginid : req.session.uniqueid,
								loginname : req.session.name,
								loginemail : req.session.email,
								com: com,
								industries : industries,
								countries : countries,
								states : states,
								messages: req.flash('error') || req.flash('info')
							});
						});
					});
				}
			}
		);
	}).sort({created_at:'desc'});	
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	Company.findByIdAndUpdate(req.body.company_id, req.body, function(err, company) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			industry_name=req.body.title;
			loginHistoryObj.title = req.session.name+' added new company '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Company Updated Successfully.');
			return res.redirect('/admin/company/list');
		}
	});
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Company.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Company.findOne({_id:n1},function(err, company){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  company '+ company.firstname +' '+ company.lastname;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/admin/company/list');
						});
						
					}
				}
			)
			break;
	}
	
};
exports.add_member = function(req, res, next) {
	res.render('admin/companies/add_member', {
		messages: req.flash('error') || req.flash('info')
	});
};

exports.edit_member = function(req, res, next) {
	res.render('admin/companies/edit_member', {
		messages: req.flash('error') || req.flash('info')
	});
};