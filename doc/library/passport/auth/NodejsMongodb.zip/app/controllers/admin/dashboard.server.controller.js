var Company = require('mongoose').model('Company'),
InsuranceTypes = require('mongoose').model('InsuranceTypes'),
Administrator = require('mongoose').model('Administrator'),
Industry = require('mongoose').model('Industry'),
MembersEmotionalAnalytics = require('mongoose').model('MembersEmotionalAnalytics'),
MemberCalories = require('mongoose').model('MemberCalories'),
MemberSteps = require('mongoose').model('MemberSteps'),
MemberHeartBitRate = require('mongoose').model('MemberHeartBitRate'),
MemberSleep = require('mongoose').model('MemberSleep'),
Member = require('mongoose').model('Member'),
Challenge = require('mongoose').model('Challenge'),
Department = require('mongoose').model('Department'),
Team = require('mongoose').model('Team'),
moment = require('moment'),
_ = require('underscore'),
_this = this,
async = require('async');

//load chart
exports.ajax_loadchart = function(req, res, next) {
	res.render('admin/dashboard/ajax_loadchart', {
		logintype : 'ajax',
		messages: req.flash('error') || req.flash('info')
	});
};

exports.postCurrentDate = function(req, res) {
	var currentDate = new Date();
	var match_month = (currentDate.getMonth()+1);
	match_month = ('0' + match_month).slice(-2);
	var match_day = (currentDate.getDate());
	match_day = ('0' + match_day).slice(-2);
	return currentDate.getFullYear()+'-' +match_month+ '-'+match_day;
};

exports.list = function(req, res, next) {
	var currentDate = _this.postCurrentDate(req,res);
	var d = new Date(currentDate);
 	d.setDate(d.getDate()-5);

 	var match_month = (d.getMonth()+1);
	match_month = ('0' + match_month).slice(-2);
	var match_day = (d.getDate());
	match_day = ('0' + match_day).slice(-2);
	var startdate = d.getFullYear()+'-' +match_month+ '-'+match_day;
	var enddate = currentDate;

	var startdateunixtimestamp = moment(startdate, 'YYYY-MM-DD').unix();
	startdateunixtimestamp+= 86400;

	Industry.find({insurance_id : req.session.uniqueid, status:'Active'},function(err,industries){
		if (err) {
			return next(err);
		}
		else {
			Company.find({insurance_id : req.session.uniqueid, status:'Active'}, function(err, companies) {
				if (err) {
					return next(err);
				}
				else {
					var comIds = _.pluck(companies, '_id');
					comIds = comIds.join().split(',');
					Member.find({'company_id':{$in : comIds}},function(err,membersList){
						var memIds = _.pluck(membersList, '_id');
						memIds = memIds.join().split(',');

						var pipeline = [
					        {"$match": { "member_id": { $in: memIds }} },
					        {
					            "$group": {
					                "_id": null,
					                "totalSteps": { "$sum": "$steps" }
					            }
					        }
					    ];

					    MemberSteps.aggregate(pipeline).exec(function (err, result){
					    	var sumSteps = 0;
					        if(!err && result.length>0){
					        	sumSteps = result[0].totalSteps;
					        }
					     	
					        var pipeline = [
						        {"$match": { "member_id": { $in: memIds }} },
						        {
						            "$group": {
						                "_id": null,
						                "totalCalories": { "$sum": "$calories_burned" }
						            }
						        }
						    ];

						    MemberCalories.aggregate(pipeline).exec(function (err, result){
						    	var sumCalories = 0;
						        if(!err && result.length>0){
						        	sumCalories = result[0].totalCalories;
						        }

						        InsuranceTypes.find({insurance_id : req.session.uniqueid, status:'Active'}, function(err, insurancetypes) {
									if (err) {
										return next(err);
									}
									else {
										Administrator.count({}, function(err, totadmin) {
											if (err) {
												return next(err);
											}
											else {
												Member.count({}, function(err, totmem) {
													if (err) {
														return next(err);
													}
													else {
														res.render('admin/dashboard/list', {
															logintype : req.session.type,
															loginid : req.session.uniqueid,
															loginname : req.session.name,
															loginemail : req.session.email,
															totalcompanies : companies.length,
															totaladmins : totadmin,
															totalmembers : totmem,
															totalsteps : sumSteps,
															totalcalories : sumCalories,
															customertype : req.session.customertype,
															industries : industries,
															companies : companies,
															startdate : startdate,
															enddate : enddate,
															insurancetypes : insurancetypes,
															startdateunixtimestamp : startdateunixtimestamp,
															messages: req.flash('error') || req.flash('info')
														});
													}
												});
											}
										});
									}
								});
							});
					    })	
					});
				}
			}).sort({created_at: 'desc'})
		}
	}).sort({created_at: 'desc'})
};

exports.postRangeStartEndDates = function(req, res, startDate, stopDate) {
	var dateArray = [];
	var currentDate = moment(startDate);
	stopDate = moment(stopDate);
	while (currentDate <= stopDate) {
	    dateArray.push( moment(currentDate).format('YYYY-MM-DD') )
	    currentDate = moment(currentDate).add(1, 'days');
	}
	return dateArray;
};

exports.loadDashboardChart = function(req,res){
	var industry = company = feature = gender = age = smoking = drinking = startdate = enddate = '';
	var indarr = comarr = featurearr = [];
	industry = req.query.industries;
	indarr = industry.split('|');
	company = req.query.companies;
	comarr = company.split('|');
	feature = req.query.features;
	featurearr = feature.split('|');
	gender = req.query.gender;
	age = req.query.age;
	smoking = req.query.smoking;
	drinking = req.query.drinking;
	startdate = req.query.startdate;
	enddate = req.query.enddate;
	smoking = (smoking=='Smoker') ? 'Yeah' : 'Nope';
	drinking = (drinking=='Drinker') ? 'Yeah' : 'Nope';
	var whereParamObj = new Object();
	if(gender!='All'){
		whereParamObj.sex = gender;
	}
	var startdateunixtimestamp = moment(startdate, 'YYYY-MM-DD').unix();
	startdateunixtimestamp+= 86400;
	if(age!='All'){
		if(age=='<18'){
			whereParamObj.age = {"$lt": 18};
		}
		else if(age=='>60'){
			whereParamObj.age = {"$gt": 60};
		}
		else {
			var dateRange = {"$gte": 18, "$lte": 30};
			whereParamObj.age = dateRange;
		}
	}

	if(req.query.smoking!='All'){
		whereParamObj.smoker = smoking;
	}
	if(req.query.drinking!='All'){
		whereParamObj.drinker = drinking;
	}

	if(indarr.length>1){
		Industry.find({"_id" : {$in: indarr},status:'Active'}, function(err, industries) {
			var resDateRange = _this.postRangeStartEndDates(req,res,startdate,enddate);
			var chartInfo = [];
			async.forEachSeries(industries, function(singleIndustry, callback_singleIndustry) {
				Company.find({industry_id : singleIndustry._id,status:'Active','_id':{$in : comarr}}, function(err, companies) {
					var comIds = _.pluck(companies, '_id');
					comIds = comIds.join().split(',');
					var indChartInfo = [];
					var valenceScore = [],caloriesBurned = [],stepsTaken = [],heartRate = [],sleep = [];
					Member.find({"company_id" : {$in: comIds},status:'Active'},{"_id":true}, function(err, members) {
						var memIds = _.pluck(members, '_id');
						memIds = memIds.join().split(',');
						async.forEachSeries(resDateRange, function(singleDate, callback_singleDate) {
							function valenceScoreFunc(callback) {
								if(_.contains(featurearr, 'Valence Score')){
									var pipeline = [
						                {"$match": { "member_id": { $in: memIds },"currentDate": singleDate} },
						                {
						                    "$group": {
						                        "_id": null,
						                        "average": { "$avg": "$valence_score" }
						                    }
						                }
						            ];

						            MembersEmotionalAnalytics.aggregate(pipeline)
					                .exec(function (err, result){
					                	console.log(result);
					                	var avgValenceScore = 0;
					                    if(!err && result.length>0){
					                    	avgValenceScore = result[0].average;
					                    }
					                    indChartInfo.push(parseFloat((avgValenceScore).toFixed(2)));
					                    callback();
					                })
								}else {
									callback();
								}
							}

							function caloriesBurnedFunc(callback) {
								if(_.contains(featurearr, 'Calories Burned')){
									var pipeline = [
						                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
						                {
						                    "$group": {
						                        "_id": null,
						                        "average": { "$avg": "$calories_burned" }
						                    }
						                }
						            ];

						            MemberCalories.aggregate(pipeline)
					                .exec(function (err, result){
					                	var avgCaloriesBurned = 0;
					                    if(!err && result.length>0){
					                    	avgCaloriesBurned = result[0].average;
					                    }
					                    indChartInfo.push(parseFloat((avgCaloriesBurned).toFixed(2)));
					                    callback();
					                })	
								}else {
									callback();
								}
							}

							function stepsTakenFunc(callback) {
								if(_.contains(featurearr, 'Steps Taken')){
									var pipeline = [
						                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
						                {
						                    "$group": {
						                        "_id": null,
						                        "average": { "$avg": "$steps" }
						                    }
						                }
						            ];

						            MemberSteps.aggregate(pipeline)
					                .exec(function (err, result){
					                	var avgSteps = 0;
					                    if(!err && result.length>0){
					                    	avgSteps = result[0].average;
					                    }
					                    indChartInfo.push(parseFloat((avgSteps).toFixed(2)));
					                    callback();
					                })
								}else {
									callback();
								}
							}

							function heartRateFunc(callback) {
								if(_.contains(featurearr, 'Heart Rate')){
									var pipeline = [
						                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
						                {
						                    "$group": {
						                        "_id": null,
						                        "average": { "$avg": "$resting_heart_rate" }
						                    }
						                }
						            ];

						            MemberHeartBitRate.aggregate(pipeline)
					                .exec(function (err, result){
					                	var avgHeartRate = 0;
					                    if(!err && result.length>0){
					                    	result[0].average = (result[0].average==null) ? 0 : result[0].average;
					                    	avgHeartRate = result[0].average;
					                    }
					                    indChartInfo.push(parseFloat((avgHeartRate).toFixed(2)));
					                    callback();
					                })
								}else {
									callback();
								}
							}

							function sleepFunc(callback) {
								if(_.contains(featurearr, 'Sleep')){
									var pipeline = [
						                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
						                {
						                    "$group": {
						                        "_id": null,
						                        "average": { "$avg": "$total_sleep" }
						                    }
						                }
						            ];

						            MemberSleep.aggregate(pipeline)
					                .exec(function (err, result){
					                	var avgSleep = 0;
					                    if(!err && result.length>0){
					                    	avgSleep = result[0].average;
					                    }
					                    indChartInfo.push(parseFloat((avgSleep).toFixed(2)));
					                    callback();
					                })
								}else {
									callback();
								}
							}

							async.series([valenceScoreFunc, caloriesBurnedFunc,stepsTakenFunc,heartRateFunc,sleepFunc], function (err, results) {
								callback_singleDate();    
							});
						}, function (err) {
							chartInfo.push(indChartInfo);
							callback_singleIndustry();
						});
					});
				});
			}, function (err) {
				res.render('admin/dashboard/ajax_load_insurance_overview', {
					chartInfo : chartInfo,
					industries : industries,
					companies : [],
					features : featurearr,
					valenceScore : [],
					caloriesBurned : [],
					stepsTaken : [],
					heartRate : [],
					sleep : [],
					startdateunixtimestamp:startdateunixtimestamp,
					layout : false
				});
			});
		}).sort({created_at: 'desc'})
	}
	else if(comarr.length>1){
		Company.find({"_id" : {$in: comarr},status:'Active'}, function(err, companies) {
			var resDateRange = _this.postRangeStartEndDates(req,res,startdate,enddate);
			var chartInfo = [];
			async.forEachSeries(companies, function(singleCompany, callback_singleCompany) {
				var companyChartInfo = [];
				whereParamObj.company_id = singleCompany._id;
				var valenceScore = [],caloriesBurned = [],stepsTaken = [],heartRate = [],sleep = [];
				Member.find(whereParamObj,{"_id":true}, function(err, members) {
					var memIds = _.pluck(members, '_id');
					memIds = memIds.join().split(',');
					async.forEachSeries(resDateRange, function(singleDate, callback_singleDate) {
						function valenceScoreFunc(callback) {
							if(_.contains(featurearr, 'Valence Score')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"currentDate": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$valence_score" }
					                    }
					                }
					            ];

					            MembersEmotionalAnalytics.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgValenceScore = 0;
				                    if(!err && result.length>0){
				                    	avgValenceScore = result[0].average;
				                    }
				                    companyChartInfo.push(parseFloat((avgValenceScore).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function caloriesBurnedFunc(callback) {
							if(_.contains(featurearr, 'Calories Burned')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$calories_burned" }
					                    }
					                }
					            ];

					            MemberCalories.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgCaloriesBurned = 0;
				                    if(!err && result.length>0){
				                    	avgCaloriesBurned = result[0].average;
				                    }
				                    companyChartInfo.push(parseFloat((avgCaloriesBurned).toFixed(2)));
				                    callback();
				                })	
							}else {
								callback();
							}
						}

						function stepsTakenFunc(callback) {
							if(_.contains(featurearr, 'Steps Taken')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$steps" }
					                    }
					                }
					            ];

					            MemberSteps.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgSteps = 0;
				                    if(!err && result.length>0){
				                    	avgSteps = result[0].average;
				                    }
				                    companyChartInfo.push(parseFloat((avgSteps).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function heartRateFunc(callback) {
							if(_.contains(featurearr, 'Heart Rate')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$resting_heart_rate" }
					                    }
					                }
					            ];

					            MemberHeartBitRate.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgHeartRate = 0;
				                    if(!err && result.length>0){
				                    	result[0].average = (result[0].average==null) ? 0 : result[0].average;
				                    	avgHeartRate = result[0].average;
				                    }
				                    companyChartInfo.push(parseFloat((avgHeartRate).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						function sleepFunc(callback) {
							if(_.contains(featurearr, 'Sleep')){
								var pipeline = [
					                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
					                {
					                    "$group": {
					                        "_id": null,
					                        "average": { "$avg": "$total_sleep" }
					                    }
					                }
					            ];

					            MemberSleep.aggregate(pipeline)
				                .exec(function (err, result){
				                	var avgSleep = 0;
				                    if(!err && result.length>0){
				                    	avgSleep = result[0].average;
				                    }
				                    companyChartInfo.push(parseFloat((avgSleep).toFixed(2)));
				                    callback();
				                })
							}else {
								callback();
							}
						}

						async.series([valenceScoreFunc, caloriesBurnedFunc,stepsTakenFunc,heartRateFunc,sleepFunc], function (err, results) {
							callback_singleDate();    
						});
					}, function (err) {
						chartInfo.push(companyChartInfo);
						callback_singleCompany();
					});
				});
			}, function (err) {
				res.render('admin/dashboard/ajax_load_insurance_overview', {
					chartInfo : chartInfo,
					industries : [],
					companies : companies,
					features : featurearr,
					valenceScore : [],
					caloriesBurned : [],
					stepsTaken : [],
					heartRate : [],
					sleep : [],
					startdateunixtimestamp:startdateunixtimestamp,
					layout : false
				});
			});
		}).sort({created_at: 'desc'})
	}
	else {
		var resDateRange = _this.postRangeStartEndDates(req,res,startdate,enddate);
		whereParamObj.company_id = comarr[0];
		whereParamObj.status = 'Active';
		var chartInfo = [];
		var valenceScore = [],caloriesBurned = [],stepsTaken = [],heartRate = [],sleep = [];
		Member.find(whereParamObj,{"_id":true}, function(err, members) {
			var memIds = _.pluck(members, '_id');
			memIds = memIds.join().split(',');
			async.forEachSeries(resDateRange, function(singleDate, callback_singleDate) {
				function valenceScoreFunc(callback) {
					if(_.contains(featurearr, 'Valence Score')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"currentDate": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$valence_score" }
			                    }
			                }
			            ];

			            MembersEmotionalAnalytics.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgValenceScore = 0;
		                    if(!err && result.length>0){
		                    	avgValenceScore = result[0].average;
		                    }
		                    valenceScore.push(parseFloat((avgValenceScore).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				function caloriesBurnedFunc(callback) {
					if(_.contains(featurearr, 'Calories Burned')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$calories_burned" }
			                    }
			                }
			            ];

			            MemberCalories.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgCaloriesBurned = 0;
		                    if(!err && result.length>0){
		                    	avgCaloriesBurned = result[0].average;
		                    }
		                    caloriesBurned.push(parseFloat((avgCaloriesBurned).toFixed(2)));
		                    callback();
		                })	
					}else {
						callback();
					}
				}

				function stepsTakenFunc(callback) {
					if(_.contains(featurearr, 'Steps Taken')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$steps" }
			                    }
			                }
			            ];

			            MemberSteps.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgSteps = 0;
		                    if(!err && result.length>0){
		                    	avgSteps = result[0].average;
		                    }
		                    stepsTaken.push(parseFloat((avgSteps).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				function heartRateFunc(callback) {
					if(_.contains(featurearr, 'Heart Rate')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$resting_heart_rate" }
			                    }
			                }
			            ];

			            MemberHeartBitRate.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgHeartRate = 0;
		                    if(!err && result.length>0){
		                    	result[0].average = (result[0].average==null) ? 0 : result[0].average;
		                    	avgHeartRate = result[0].average;
		                    }
		                    heartRate.push(parseFloat((avgHeartRate).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				function sleepFunc(callback) {
					if(_.contains(featurearr, 'Sleep')){
						var pipeline = [
			                {"$match": { "member_id": { $in: memIds },"created_date": singleDate} },
			                {
			                    "$group": {
			                        "_id": null,
			                        "average": { "$avg": "$total_sleep" }
			                    }
			                }
			            ];

			            MemberSleep.aggregate(pipeline)
		                .exec(function (err, result){
		                	var avgSleep = 0;
		                    if(!err && result.length>0){
		                    	avgSleep = result[0].average;
		                    }
		                    sleep.push(parseFloat((avgSleep).toFixed(2)));
		                    callback();
		                })
					}else {
						callback();
					}
				}

				async.series([valenceScoreFunc, caloriesBurnedFunc,stepsTakenFunc,heartRateFunc,sleepFunc], function (err, results) {
					callback_singleDate(); 
				});
			}, function (err) {
				res.render('admin/dashboard/ajax_load_insurance_overview', {
					chartInfo : chartInfo,
					industries : [],
					companies : [],
					features : featurearr,
					valenceScore : valenceScore,
					caloriesBurned : caloriesBurned,
					stepsTaken : stepsTaken,
					heartRate : heartRate,
					sleep : sleep,
					startdateunixtimestamp:startdateunixtimestamp,
					layout : false
				});
			});
		});
	}
};

exports.loadCompany = function(req,res){
	var ind = req.query.industry;
	var indArr = ind.split('|');
	Company.find({"industry_id" : {$in: indArr},status:'Active'}, function(err, companies) {
		var companyStr = "<option value='All'>All</option>";
		for(var t=0;t<companies.length;t++){
			companyStr+= "<option value='"+companies[t]._id+"'>"+companies[t].title+"</option>";
		}
		res.send(companyStr);
		return false;
	}).sort({created_at: 'desc'})
};