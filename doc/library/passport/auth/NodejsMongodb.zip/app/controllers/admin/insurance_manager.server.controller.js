var moment = require('moment')

// list insurance_manager
exports.list = function(req, res, next) {
	res.render('admin/insurance_manager/list', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages : req.flash('error') || req.flash('info'),
		messages : req.flash('info'),
		moment : moment
	});
};
exports.listrundata = function(req, res, next) {
	res.render('admin/insurance_manager/list_rundata', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages : req.flash('error') || req.flash('info'),
		messages : req.flash('info'),
		moment : moment
	});
};