var State = require('mongoose').model('State');
var Country = require('mongoose').model('Country');
var moment = require('moment')

// list states
exports.list = function(req, res, next) {
	State.find({}, function(err, states) {
		if (err) {
			return next(err);
		}
		else {
			res.render('admin/states/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				states : states,
				messages : req.flash('error') || req.flash('info'),
				messages : req.flash('info'),
				moment : moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new state 
exports.add = function(req, res, next) {
	Country.find({}, function(err, countries) {
		res.render('admin/states/add', {
			logintype : req.session.type,
			loginid : req.session.uniqueid,
			loginname : req.session.name,
			loginemail : req.session.email,
			countries : countries,
			messages: req.flash('error') || req.flash('info')
		});
	}).sort({created_at:'desc'});
};

exports.create = function(req, res, next) {
	var state = new State(req.body);
	state.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			req.flash('info', 'New State Added Successfully.');
			return res.redirect('/admin/states/list');
		}
	});
};

// edit state
exports.edit = function(req, res, next) {
	var id = req.params.id;
	State.findOne({
			_id: id
		}, 
		function(err, state) {
			if (err) {
				return next(err);
			}
			else {
				Country.find({}, function(err, countries) {
					res.render('admin/states/edit', {
						logintype : req.session.type,
						loginid : req.session.uniqueid,
						loginname : req.session.name,
						loginemail : req.session.email,
						state : state,
						countries : countries,
						messages: req.flash('error') || req.flash('info')
					});
				}).sort({created_at:'desc'});
			}
		}
	);
};

// update state
exports.update = function(req, res, next) {
	State.findByIdAndUpdate(req.body.state_id, req.body, function(err, state) {
		if (err) {
			return next(err);
		}
		else {
			req.flash('info', 'State Updated Successfully.');
			return res.redirect('/admin/states/list');
		}
	});
};

exports.list_action = function(req, res, next) {
	var action = req.body.btnAction
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
			State.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Updated Successfully.');
						return res.redirect('/admin/states/list');
					}
				}
			)
			break;
		case "Deleted":
			State.deleteMany(
				{ '_id':{ $in : req.body.iId } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Deleted Successfully.');
						return res.redirect('/admin/states/list');
					}
				}
			)
			break;
	}
};