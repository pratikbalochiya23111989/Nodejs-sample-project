var Policy_holder = require('mongoose').model('Policy_holder');
var InsuranceTypesPlans = require('mongoose').model('InsuranceTypesPlans');
var InsuranceTypes = require('mongoose').model('InsuranceTypes');
var LogActivity = require('mongoose').model('LogActivity');
var async = require('async');
var fs = require('fs'); 
var parse = require('csv-parse');
var  csv = require("csv");
//get all members list
exports.list = function(req, res, next) {
	Policy_holder.find({status: {'$ne':'Deleted' }}, function(err, policyholder) {
		if (err) {
			return next(err);
		}
		else {	
			res.render('admin/policy_holder/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				policyholder:policyholder,
				messages : req.flash('error') || req.flash('info'),
				messages : req.flash('info'),
			});	
		}
	}).sort({created_at:'desc'});
};


//add new member
exports.add = function(req, res, next) {
	InsuranceTypesPlans.find({status:'Active' }, function(err, insurancetypesplans) {
		InsuranceTypes.find({status:'Active' }, function(err, insurancetypes) {
			res.render('admin/policy_holder/add', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				insurancetypes:insurancetypes,
				insurancetypesplans:insurancetypesplans,
				messages: req.flash('error') || req.flash('info')
			});
		});
	});
};

// remove photo

// edit member
exports.edit = function(req, res, next) {
	var id = req.params.id;
	 Policy_holder.findOne({
	 		_id: id
		}, 
		function(err, policyholder) {
			if (err) {
				return next(err);
			}
			else
			{
				InsuranceTypesPlans.find({status:'Active' }, function(err, insurancetypesplans) {
					InsuranceTypes.find({status:'Active' }, function(err, insurancetypes) {
						res.render('admin/policy_holder/edit', {
							logintype : req.session.type,
							loginid : req.session.uniqueid,
							loginname : req.session.name,
							loginemail : req.session.email,
							insurancetypesplans:insurancetypesplans,
							insurancetypes:insurancetypes,
							policyholder:policyholder,
							messages: req.flash('error') || req.flash('info')
						});
					});
				});
			}
		}
	
	);			
			
};

exports.create = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	var data = new Policy_holder(req.body);
	data.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			var fname=req.body.firstname;
			var lname=req.body.lastname;
			var title=fname+' '+lname;
			industry_name=title;
			loginHistoryObj.title = req.session.name+' added new policy holder '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'New Policy holder Added Successfully.');
			return res.redirect('/admin/policy_holder/list');
		}
	});
};

exports.list_action = function(req, res, next) {
    req.body.loginid=req.session.historyid;
	var async = require('async');
	var action = req.body.btnAction;
	var ids=req.body.iId;
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
		case "Deleted":
			Policy_holder.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						async.forEachSeries(req.body.iId, function(n1, callback_s1) {
							var date = new Date();
							if(action=='Active')
							{
								perform_action="activated";
							}
							else if(action=='Inactive')
							{
								perform_action="deactivated";
							}
							else if(action=='Deleted')
							{
								perform_action="deleted";
							}
							
							Policy_holder.findOne({_id:n1},function(err, policyholder){
								var loginHistoryObj = new LogActivity();
								loginHistoryObj.title = req.session.name+' '+perform_action+'  policyholder '+ policyholder.firstname+' '+policyholder.lastname;
								loginHistoryObj.login_id = req.session.historyid;
								loginHistoryObj.posted =date;
								loginHistoryObj.save(function(err) {
									callback_s1();
								});

							});
							
						}, function (err) {
							if(req.body.btnAction=='Deleted'){
								req.flash('info', str+' Deleted Successfully.');
							}
							else {
								req.flash('info', str+' Updated Successfully.');
							}
							return res.redirect('/admin/policy_holder/list');
						});
						
					}
				}
			)
			break;
	}
	
};

exports.update = function(req, res, next) {
	var loginHistoryObj = new LogActivity();
	Policy_holder.findByIdAndUpdate(req.body.policyholder_id, req.body, function(err, state) {
		if (err) {
			return next(err);
		}
		else {
			var date = new Date();
			var fname=req.body.firstname;
			var lname=req.body.lastname;
			var title=fname+' '+lname;
			industry_name=title;
			loginHistoryObj.title = req.session.name+' updated policy holder '+ industry_name;
			loginHistoryObj.login_id = req.session.historyid;
			loginHistoryObj.posted =date;
			console.log(loginHistoryObj.login_id);
			console.log(loginHistoryObj);
			loginHistoryObj.save(function(err) {
			});
			req.flash('info', 'Policy Holder Updated Successfully.');
			return res.redirect('/admin/policy_holder/list');
		}
	});
};

exports.importcsv = function(req, res, next) {
	
        // the name under "files" must correspond to the name of the
        // file input field in the submitted form (here: "csvdata")
        csv.from.path(req.files.csvdata.path, {
            delimiter: ",",
            escape: '"'
        })
        // when a record is found in the CSV file (a row)
        .on("record", function(row, index) {
            var firstName, lastName;

            // skip the header row
            if (index === 0) {
                return;
            }

            // read in the data from the row
            console.log(row[0].trim());return false;
            

            // perform some operation with the data
            // ...
        })
        // when the end of the CSV document is reached
        .on("end", function() {
            // redirect back to the root
            res.redirect("/");
        })
        // if any errors occur
        .on("error", function(error) {
            console.log(error.message);
        });
    
};