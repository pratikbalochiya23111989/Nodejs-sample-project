var Administrator = require('mongoose').model('Administrator');
var moment = require('moment')

// list administrator
exports.list = function(req, res, next) {
	Administrator.find({}, function(err, administrators) {
		if (err) {
			return next(err);
		}
		else {
			res.render('admin/administrators/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				administrators: administrators,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new administrator 
exports.add = function(req, res, next) {
	res.render('admin/administrators/add', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.create = function(req, res, next) {	
	var administrator = new Administrator(req.body);
	administrator.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			req.flash('info', 'New Administrator Added Successfully.');
			return res.redirect('/admin/administrators/list');
		}
	});
};

exports.edit = function(req, res, next) {
	var id = req.params.id;
	Administrator.findOne({
			_id: id
		}, 
		function(err, administrator) {
			if (err) {
				return next(err);
			}
			else {
				res.render('admin/administrators/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					administrator: administrator,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};

exports.update = function(req, res, next) {
	Administrator.findByIdAndUpdate(req.body.admin_id, req.body, function(err, user) {
		if (err) {
			return next(err);
		}
		else {
			req.flash('info', 'Administrator Updated Successfully.');
			return res.redirect('/admin/administrators/list');
		}
	});
};

exports.list_action = function(req, res, next) {
	var action = req.body.btnAction
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
			Administrator.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Updated Successfully.');
						return res.redirect('/admin/administrators/list');
					}
				}
			)
			break;
		case "Deleted":
			Administrator.deleteMany(
				{ '_id':{ $in : req.body.iId } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Deleted Successfully.');
						return res.redirect('/admin/administrators/list');
					}
				}
			)
			break;
	}
	
};