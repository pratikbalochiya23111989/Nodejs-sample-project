var Country = require('mongoose').model('Country');
var moment = require('moment')

// list countries
exports.list = function(req, res, next) {
	Country.find({}, function(err, countries) {
		if (err) {
			return next(err);
		}
		else {
			res.render('admin/countries/list', {
				logintype : req.session.type,
				loginid : req.session.uniqueid,
				loginname : req.session.name,
				loginemail : req.session.email,
				countries: countries,
				messages: req.flash('error') || req.flash('info'),
				messages:req.flash('info'),
				moment: moment
			});
		}
	}).sort({created_at:'desc'});
};

//add new country 
exports.add = function(req, res, next) {
	res.render('admin/countries/add', {
		logintype : req.session.type,
		loginid : req.session.uniqueid,
		loginname : req.session.name,
		loginemail : req.session.email,
		messages: req.flash('error') || req.flash('info')
	});
};

exports.create = function(req, res, next) {
	var country = new Country(req.body);
	country.save(function(err) {
		if (err) {
			return next(err);
		}
		else {
			req.flash('info', 'New Country Added Successfully.');
			return res.redirect('/admin/countries/list');
		}
	});
};

// edit country
exports.edit = function(req, res, next) {
	var id = req.params.id;
	Country.findOne({
			_id: id
		}, 
		function(err, country) {
			if (err) {
				return next(err);
			}
			else {
				res.render('admin/countries/edit', {
					logintype : req.session.type,
					loginid : req.session.uniqueid,
					loginname : req.session.name,
					loginemail : req.session.email,
					country: country,
					messages: req.flash('error') || req.flash('info')
				});
			}
		}
	);
};

// update country
exports.update = function(req, res, next) {
	Country.findByIdAndUpdate(req.body.country_id, req.body, function(err, country) {
		if (err) {
			return next(err);
		}
		else {
			req.flash('info', 'Country Updated Successfully.');
			return res.redirect('/admin/countries/list');
		}
	});
};

exports.list_action = function(req, res, next) {
	var action = req.body.btnAction
	var str = (req.body.iId.length>1) ? 'Records' : 'Record';
	switch(action)
	{
		case "Active":
		case "Inactive":
			Country.updateMany(
				{ '_id':{ $in : req.body.iId } },
				{ $set: { "status": req.body.btnAction } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Updated Successfully.');
						return res.redirect('/admin/countries/list');
					}
				}
			)
			break;
		case "Deleted":
			Country.deleteMany(
				{ '_id':{ $in : req.body.iId } },
				function (err,val) {
					if (err) {
						return next(err);
					}
					else {
						req.flash('info', str+' Deleted Successfully.');
						return res.redirect('/admin/countries/list');
					}
				}
			)
			break;
	}	
};