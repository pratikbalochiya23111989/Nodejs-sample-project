var Superadmin = require('mongoose').model('Superadmin');
var Administrator = require('mongoose').model('Administrator');
var Company = require('mongoose').model('Company');
var LoginLog = require('mongoose').model('LoginLog');
var _this = this;

exports.render = function(req, res) {
	res.render('login', {
		layout:false,
		remember_me : req.session.remember_me,
		remember_email : req.session.remember_email,
		remember_password : req.session.remember_password,
		messages : req.flash('error') || req.flash('info'),
		messages : req.flash('info'),
	});
};

exports.check_session_created = function(req, res){
	if(req.session.uniqueid){
		var date = new Date();
		LoginLog.findByIdAndUpdate(req.session.historyid, { logout_datetime: date.toISOString()}, function(err, logres) { });
		req.session.destroy();
		res.send('yes');
	}
	else {
		res.send('no');
	}
};

exports.check_session_status = function(req, res){
	if(req.session.uniqueid){
		res.send('yes');
	}
	else {
		res.send('no');
	}
};

exports.session_timeout = function(req, res) {
	req.flash('info', 'Session Expired.');
	return res.redirect('/');
};

exports.access_denied = function(req, res) {
	req.flash('info', "You have no any rights to access this control panel.");
	return res.redirect('/');
};

exports.authentication = function(req, res) {
	var loginHistoryObj = new LoginLog();
	var ip = require('ip');
	if(req.body.remember_me=='on'){
		req.session.remember_me = "yes";
		req.session.remember_email = req.body.email;
		req.session.remember_password = req.body.password;
	}
	else {
		req.session.remember_me = "no";
		req.session.remember_email = '';
		req.session.remember_password = '';
	}
	var email = req.body.email;
	var md5 = require('md5');
	var password = md5(req.body.password);
	
	var date = new Date();
	loginHistoryObj.ip_address = ip.address();
	loginHistoryObj.login_datetime = date.toISOString();
	Superadmin.findOne({email : email, password : password, status : 'Active'}, function(err, superadmin) {
		if(superadmin){
			req.session.type = 'Superadmin';
			req.session.uniqueid = superadmin._id;
			req.session.name = superadmin.firstname+" "+superadmin.lastname;
			req.session.access_permission = superadmin.access_permission;
			req.session.email = superadmin.email;
			loginHistoryObj.user_type = "Superadmin";
			loginHistoryObj.name = superadmin.firstname+" "+superadmin.lastname;
			loginHistoryObj.email = superadmin.email;
			loginHistoryObj.save(function(err,insertRec) {
				req.session.historyid = insertRec._id;
				return res.redirect('/superadmin/dashboard/list');
			});
		}
		else {
			Administrator.findOne({email : email, password : password, status : 'Active'}, function(err, administrators) {
				if(administrators){
					req.session.type = 'Admin';
					req.session.uniqueid = administrators._id;
					req.session.name = administrators.firstname+" "+administrators.lastname;
					req.session.email = administrators.email;
					req.session.customertype = administrators.customertype;

					loginHistoryObj.user_type = "Insuranceadmin";
					loginHistoryObj.name = administrators.firstname+" "+administrators.lastname;
					loginHistoryObj.email = administrators.email;
					loginHistoryObj.save(function(err,insertRec) {
						req.session.historyid = insertRec._id;
						return res.redirect('/admin/dashboard/list');
					});
				}
				else {
					Company.findOne({hr_email : email, password : password, status : 'Active'}, function(err, companies) {
						if(companies){
							req.session.type = 'Company';
							req.session.uniqueid = companies._id;
							req.session.name = companies.firstname+' '+companies.lastname;
							req.session.email = companies.hr_email;
							
							loginHistoryObj.user_type = "HR";
							loginHistoryObj.name = companies.firstname+' '+companies.lastname;
							loginHistoryObj.email = companies.hr_email;
							loginHistoryObj.save(function(err,insertRec) {
								req.session.historyid = insertRec._id;
								return res.redirect('/dashboard/list');
							});
						}
						else {
							req.flash('info', 'Invalid Email Or Password.');
							return res.redirect('/');
						}
					});
				}
			});
		}
	});
};

exports.sendEmail = function(req,res,toemail,subject,content) {
	var nodemailer = require('nodemailer');
	var transporter = nodemailer.createTransport({
	  	host: 'smtp.gmail.com',
        port: 465,
        secure: true,
	  	service: 'gmail',
	  	auth: {
	    	user: 'otp@aktivolabs.com',
	    	pass: '9924693192'
	  	}
	});

	var mailOptions = {
	  	from: '"Aktivo" <otp@aktivolabs.com>',
	  	to: toemail,
	  	subject: subject,
	  	html: content
	};

	transporter.sendMail(mailOptions, function(error, info){
		return;
	});
};

exports.forgotPassword = function(req, res) {
	if(req.body.email){
		var length = 6;
		code = Math.round((Math.pow(36, length + 1) - Math.random() * Math.pow(36, length))).toString(36).slice(1),
		fullUrl = req.protocol + '://' + req.get('host'),
		link = fullUrl+'/reset_password/'+code,
		emailTemplate = "<html xmlns='http://www.w3.org/1999/xhtml'><head><meta name='viewport' content='width=device-width' /><meta http-equiv='Content-Type' content='text/html; charset=UTF-8' /><title>Email</title><style type='text/css'>table tr td a{color:#ffffff!important;text-decoration:none}.reset_password{color:#ffffff!important;text-decoration:none!important}</style></head><body bgcolor='#FFFFFF'><table width='96%' border='0' cellspacing='0' cellpadding='0' bgcolor='#f2f5f7' style='border-right:1px solid #d3d9dd;border-bottom:20px solid #000;padding:1% 2% 2% 2%;margin:0 0 0 2%;border-radius:10px'><tr><td><table width='100%' border='0' cellspacing='0' cellpadding='0'><tr><td><table width='100%' border='0' cellspacing='0' cellpadding='0' bgcolor='#000' style='border-radius:5px;padding:20px 0'><tr><td align='center' valign='middle'><img src='https://i.imgur.com/n2nLbtv.png' alt='' width='200'></td></tr></table></td></tr><tr><td><table width='100%' border='0' cellspacing='0' cellpadding='0' style='padding:10px 0 0 0'><tr><td style='font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#000;padding:10px 0 10px 10px'><span>Dear #NAME#,</span></td></tr><tr><td style='font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#000;padding:0 0 0 10px'><p>You requested for reset password</p></td></tr><tr><td style='font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#000;padding:0 0 0 10px'><p>Click on below button to reset your password</p></td></tr><tr><td style='font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#000;padding:0 0 10px 10px'><p></p></td></tr><tr style=''><td style='font-size:20px;font-family:Clan,Helvetica,Arial,sans-serif;font-weight:normal;color:#ffffff!important;text-decoration:none;background-color:#000;border-top:12px solid #000;border-bottom:12px solid #000;border-right:10px solid #000;border-left:10px solid #000;display:block;text-transform:uppercase;width:90%;text-align:center!important;margin:0 auto' target='_blank'><a href='#LINK#' class='reset_password' style='font-size:20px;font-family:Clan,Helvetica,Arial,sans-serif;font-weight:normal;text-decoration:none;background-color:#000;border-top:0 solid #000;border-bottom:0 solid #000;border-right:0 solid #000;border-left:10px solid #000;display:block;text-transform:uppercase,width:14%;margin:0 auto;color:#ffffff!important' target='_blank'><span style='text-decoration:none!important;color:#ffffff!important'>Reset Password</span></a></td></tr><tr><td style='font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#000;padding:0 0 10px 10px'><p></p></td></tr></table></td></tr></table></td></tr></table></body></html>",
		api_key = 'key-43cf4c016eb85a389fc22df0dd7bf6f4',
		domain = 'dotzapper.com',
		mailgun = require('mailgun-js')({apiKey: api_key, domain: domain});
		Superadmin.findOne({email : req.body.email}, function(err, superadmin) {
			if(superadmin){
				emailTemplate = emailTemplate.replace("#NAME#", superadmin.firstname+' '+superadmin.lastname);
				emailTemplate = emailTemplate.replace("#LINK#", link);
				
				_this.sendEmail(req,res,superadmin.email,'Aktivo - You requested for reset password',emailTemplate);

				Superadmin.findByIdAndUpdate(superadmin._id, { code: code }, function(err, superAdminRes) {
					req.flash('info', 'We sent you a link for reset password at your registered email id!');
					res.redirect('/');
				});
			}
			else {
				Administrator.findOne({email : req.body.email}, function(err, administrator) {
					if(administrator){
						emailTemplate = emailTemplate.replace("#NAME#", administrator.firstname+' '+administrator.lastname);
						emailTemplate = emailTemplate.replace("#LINK#", link);
						
						_this.sendEmail(req,res,administrator.email,'Aktivo - You requested for reset password',emailTemplate);

						Administrator.findByIdAndUpdate(administrator._id, { code: code }, function(err, administratorRes) {
							req.flash('info', 'We sent you a link for reset password at your registered email id!');
							res.redirect('/');
						});
					}
					else {
						Company.findOne({hr_email : req.body.email}, function(err, company) {
							if(company){
								emailTemplate = emailTemplate.replace("#NAME#", company.firstname+' '+company.lastname);
								emailTemplate = emailTemplate.replace("#LINK#", link);
								
								_this.sendEmail(req,res,company.hr_email,'Aktivo - You requested for reset password',emailTemplate);

								Company.findByIdAndUpdate(company._id, { code: code }, function(err, companyRes) {
									req.flash('info', 'We sent you a link for reset password at your registered email id!');
									res.redirect('/');
								});
							}
							else {
								req.flash('info', 'Please enter correct email id.');
								return res.redirect('/');
							}
						});
					}
				});
			}
		});
	} // end of if
	else {
		res.render('forgotpassword', {
			layout:false
		});
	}
};

exports.logout = function(req, res) {
	var date = new Date();
	LoginLog.findByIdAndUpdate(req.session.historyid, { logout_datetime: date.toISOString()}, function(err, logres) { });
	req.flash('info', 'Thank you for using control panel!')
	req.session.destroy();
	res.redirect('/');
};

exports.reset_password = function(req, res){
	if(req.body.code){
		var md5 = require('md5');
		var updateObj = {
			code : '',
			password : md5(req.body.password)
		}
		Superadmin.findOne({code : req.body.code}, function(err, superadmin) {
			if(superadmin){
				Superadmin.findByIdAndUpdate(superadmin._id, updateObj, function(err, superadminRes) {
					req.flash('info', 'Your password changed successfully!')
					res.redirect('/');
				});
			}
			else {
				Administrator.findOne({code : req.body.code}, function(err, administrator) {
					if(administrator){
						Administrator.findByIdAndUpdate(administrator._id, updateObj, function(err, administratorRes) {
							req.flash('info', 'Your password changed successfully!')
							res.redirect('/');
						});	
					}
					else {
						Company.findOne({code : req.body.code}, function(err, company) {
							if(company){
								Company.findByIdAndUpdate(company._id, updateObj, function(err, companyRes) {
									req.flash('info', 'Your password changed successfully!')
									res.redirect('/');
								});
							}
							else {
								req.flash('info', "You can't use same email for reset password!")
								res.redirect('/');
							}
						});
					}
				});
			}
		});
	}
	else {
		var code = req.params.code;
		res.render('resetpassword', {
			code: code,
			layout:false
		});
	}
};
