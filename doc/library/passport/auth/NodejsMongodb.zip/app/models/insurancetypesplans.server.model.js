//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var InsuranceTypesPlansSchema = new Schema({
	insurancetypeplan_id : String,
	insurancetype_id: String,
	type: String,
	title : String,
	description:String,
	photo : String,
	status : {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at : { type: Date, default: Date.now }
});
// save state
InsuranceTypesPlansSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('InsuranceTypesPlans', InsuranceTypesPlansSchema);