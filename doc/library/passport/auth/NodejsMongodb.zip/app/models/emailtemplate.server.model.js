//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var EmailTemplateSchema = new Schema({
	code : String,
	title : String,
	content : String,
	created_at : { type: Date, default: Date.now }
});

// save email template
EmailTemplateSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('EmailTemplate', EmailTemplateSchema);