//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MemberCaloriesSchema = new Schema({
	platform_type: {type: String, enum: ['validic','apple_health_kit','google_fit','aktivo_band']},
	member_id: String,
	calories_id : String,
	calories_burned : Number,
	distance : String,
	elevation : Number,
	floors : Number,
	last_updated : String,
	source : String,
	source_name : String,
	steps : Number,
	timestamp : String,
	user_id : String,
	utc_offset : String,
	validated : Boolean,
	water : Number,
	created_date : String,
	created_time : String
});

// save calories
MemberCaloriesSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('MemberCalories', MemberCaloriesSchema);