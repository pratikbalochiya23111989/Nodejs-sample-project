//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var LoginLogSchema = new Schema({
	user_type: {type: String, enum: ['Superadmin', 'Insuranceadmin','HR']},
	name:String,
	email:String,
	ip_address: String,
	login_datetime : Date,
	logout_datetime : Date,
	created_at: { type: Date, default: Date.now }
});

mongoose.model('LoginLog', LoginLogSchema);