//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var CompanySchema = new Schema({
	insurance_id : String,
	industry_id : String,
	title : String,
	firstname: String,
	lastname: String,
	address:String,
	country_id:String,
	state_id:String,
	zipcode:String,
	hr_email: {
		type: String,
		trim: true,
		unique: true
	},
	hr_phone:String,
	password: String,
	code: String,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at: { type: Date, default: Date.now },
	updated_at: { type: Date, default: Date.now }
});

// save company
CompanySchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Company', CompanySchema);