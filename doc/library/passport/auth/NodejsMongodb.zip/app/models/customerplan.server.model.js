//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var CustomerPlanSchema = new Schema({
	customerplan_id : String,
	customerplantype_id : String,
	customerplantype : String,
	photo: String,
	title : String,
	customerplanprice : String,
	description : String,
	created_at : { type: Date, default: Date.now },
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']}
});

// save industry
CustomerPlanSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('CustomerPlan', CustomerPlanSchema);