//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MemberBrioSchema = new Schema({
	member_id : String,
	brio_score : String,
	created_date : String,
	created_time : String
});

// save brio
MemberBrioSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('MemberBrio', MemberBrioSchema);