//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MembersAktivoScoreSchema = new Schema({
	member_id : String,
	aktivo_score : Number,
	loaded_score : Number,
	LIPA_Modified : Number,
	MVPA_Modified : Number,
	Sleep_Modified : Number,
	SB_Modified : Number,
	created_date : String,
	created_at : { type: Date, default: Date.now }
});

mongoose.model('MembersAktivoScore', MembersAktivoScoreSchema);