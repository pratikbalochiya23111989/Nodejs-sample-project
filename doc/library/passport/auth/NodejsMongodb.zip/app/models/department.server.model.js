//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

/*var Department = mongoose.model('department', DepartmentSchema);*/

var DepartmentSchema = new Schema({
	type : String, 
	company_id: String,
	department_id: String,
	title:String,
	description:String,
	photo: String,
	multiple_members:Array,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at: { type: Date, default: Date.now }
});

// save company
DepartmentSchema.pre('save',
	function(next) {
		next();
	}
);

/*DepartmentSchema.methods.getMemberDetails = function getMemberDetails(email, callback) {
	Department.find({ email: email }, function(err, department) {
	  	console.log(department);
	});
};*/

mongoose.model('Department', DepartmentSchema);