//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var TestSchema = new Schema({
	base64str:String,
	created_at: { type: Date, default: Date.now }
});

mongoose.model('Test', TestSchema);