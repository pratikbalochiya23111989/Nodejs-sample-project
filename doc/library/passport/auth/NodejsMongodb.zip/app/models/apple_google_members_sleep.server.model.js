//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var AppleGoogleMemberSleepSchema = new Schema({
	platform_type: {type: String, enum: ['validic','apple_health_kit','google_fit','aktivo_band']},
	member_id: String,
	total_sleep : Number,
	created_date : String,
	created_time : String
});

mongoose.model('AppleGoogleMemberSleepSchema', AppleGoogleMemberSleepSchema);