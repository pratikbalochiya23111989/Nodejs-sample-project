//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var TeamSchema = new Schema({
	type: String,
	team_id : String,
	company_id: String,
	title:String,
	department_id: String,
	description: String,
	photo: String,
	multiple_members:Array,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at: { type: Date, default: Date.now }
});

// save company
TeamSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Team', TeamSchema);