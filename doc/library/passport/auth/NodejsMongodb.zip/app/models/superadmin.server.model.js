//define schema and mongoose
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var SuperadminSchema = new Schema({
	firstname: String,
	lastname:String,
	email: {
		type: String,
		trim: true,
		unique: true
	},
	password: String,
	access_permission:String,
	code:String,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at: { type: Date, default: Date.now }
});

// save insurance admin
SuperadminSchema.pre('save',
	function(next) {
		if (this.password) {
			var md5 = crypto.createHash('md5');
			this.password = md5.update(this.password).digest('hex');
		}
		next();
	}
);

mongoose.model('Superadmin', SuperadminSchema);