//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var MemberSocialSchema = new Schema({
	member_id:String,
	usertype : {type: String, enum: ['Super', 'Insurance', 'Broker', 'HR','Member'],default: ['Member']},
	caption_title:String,
	hash_tags:Array,
	user_tags:Array,
	updated_at: { type: Date },
	created_at: { type: Date, default: Date.now }
});

mongoose.model('MemberSocial', MemberSocialSchema);