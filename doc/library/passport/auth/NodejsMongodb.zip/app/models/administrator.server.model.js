//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var AdministratorSchema = new Schema({
	customertype : String,
	customerId : String,
	businessname: String,
	firstname: String,
	middlename : String,
	lastname:String,
	email: {
		type: String,
		trim: true,
		unique: true
	},
	customerplan_id : String,
	password: String,
	phone : String,
	photo:String,
	access_permission: String,
	code: String,
	last_login_id : String,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at: { type: Date, default: Date.now }
});

// save admin
AdministratorSchema.pre('save',
	function(next) {
		if (this.password) {
			var md5 = crypto.createHash('md5');
			this.password = md5.update(this.password).digest('hex');
		}
		next();
	}
);

mongoose.model('Administrator', AdministratorSchema);