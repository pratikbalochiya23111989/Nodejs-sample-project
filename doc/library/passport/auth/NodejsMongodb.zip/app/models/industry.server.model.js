//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var IndustrySchema = new Schema({
	type : String,
	photo : String,
	title : String,
	created_at : { type: Date, default: Date.now },
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']}
});

// save industry
IndustrySchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Industry', IndustrySchema);