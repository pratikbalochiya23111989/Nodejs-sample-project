//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var AnnouncementSchema = new Schema({
	title : String,
	// status : {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	description:String,
	photo:String,
	created_at : { type: Date, default: Date.now }
});

// save state
AnnouncementSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Announcement', AnnouncementSchema);