//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MemberActiveMinutesSchema = new Schema({
	platform_type: {type: String, enum: ['validic','apple_health_kit','google_fit','aktivo_band']},
	active_duration: Number,
	calories_burned: Number,
	distance: String,
	elevation: Number,
	floors:  Number,
	last_updated: String,
	source: String,
	source_name: String,
	steps: Number,
	timestamp: String,
	user_id: String,
	utc_offset: String,
	validated: Boolean,
	water: Number,
	member_id: String,
	created_date: String,
	created_time: String
});

mongoose.model('MemberActiveMinutes', MemberActiveMinutesSchema);