//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var AppleGoogleMemberStepsSchema = new Schema({
	platform_type: {type: String, enum: ['validic','apple_health_kit','google_fit','aktivo_band']},
	member_id: String,
	steps : Number,
	created_date : String,
	created_time : String
});

mongoose.model('AppleGoogleMemberStepsSchema', AppleGoogleMemberStepsSchema);