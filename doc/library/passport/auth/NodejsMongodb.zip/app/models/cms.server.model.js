//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var CMSSchema = new Schema({
	code:String,
	title:String,
	description:String
});

// save cms
CMSSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('CMS', CMSSchema);