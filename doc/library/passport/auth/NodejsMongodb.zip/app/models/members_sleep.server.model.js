//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MemberSleepSchema = new Schema({
	platform_type: {type: String, enum: ['validic','apple_health_kit','google_fit','aktivo_band']},
	sleep_id : String,
	member_id: String,
	awake : Number,
	deep : Number,
	last_updated : String,
	light : Number,
	rem : Number,
	source : String,
	source_name : String,
	times_woken : Number, 
	timestamp : String,
	total_sleep : Number,
	user_id : String,
	utc_offset : String,
	validated : Boolean,
	created_date : String,
	created_time : String
});

// save sleep
MemberSleepSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('MemberSleep', MemberSleepSchema);