//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MembersEmotionalAnalyticsSchema = new Schema({
	member_id: String,
	mood:String,
	valence_score:Number,
	moodForHighestPoint : String,
	moodForLowestPoint : String,
	temperValue : Number,
	currentDate : String,
	currentTime : String,
	created_at: { type: Date, default: Date.now }
});

MembersEmotionalAnalyticsSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('MembersEmotionalAnalytics', MembersEmotionalAnalyticsSchema);