//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var MemberSocialMediaSchema = new Schema({
	social_timeline_id : String,
	media_type : {type: String, enum: ['Image', 'Video','Link']},
	file : String,
	thumbnail : String,
	updated_at : { type: Date },
	created_at : { type: Date, default: Date.now }
});

mongoose.model('MemberSocialMedia', MemberSocialMediaSchema);