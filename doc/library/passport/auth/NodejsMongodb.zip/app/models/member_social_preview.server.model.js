//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var MemberSocialPreviewSchema = new Schema({
	member_id:String,
	social_timeline_id: String,
	preview_datetime:Array,
	total_count: Number
});

mongoose.model('MemberSocialPreview', MemberSocialPreviewSchema);