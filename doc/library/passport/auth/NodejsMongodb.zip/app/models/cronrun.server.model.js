//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var CronRunSchema = new Schema({
	title: String,
	type : String,
	created_at: { type: Date, default: Date.now }
});

mongoose.model('CronRun', CronRunSchema);