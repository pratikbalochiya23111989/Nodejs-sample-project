//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var StateSchema = new Schema({
	country_id : String,
	title : String,
	created_at : { type: Date, default: Date.now },
	status : {type: String, enum: ['Active', 'Inactive', 'Deleted']}
});

// save state
StateSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('State', StateSchema);