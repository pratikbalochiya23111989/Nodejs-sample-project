//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var LogActivitySchema = new Schema({
	login_id:String,
	title:String,
	posted: { type: Date, default: Date.now }
});

mongoose.model('LogActivity', LogActivitySchema);