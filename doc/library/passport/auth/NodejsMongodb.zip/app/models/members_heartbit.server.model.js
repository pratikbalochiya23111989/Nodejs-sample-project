//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MemberHeartBitRateSchema = new Schema({
	platform_type: {type: String, enum: ['validic','apple_health_kit','google_fit','aktivo_band']},
	member_id: String,
	heart_rate_id : String,
	activity_calories : Number,
	activity_id : String,
	calories_bmr : Number,
	calories_burned : Number,
	distance : String,
	elevation : Number,
	floors : Number,
	last_updated : String,
	minutes_fairly_active : Number,
	minutes_lightly_active : Number,
	minutes_sedentary : Number,
	minutes_very_active : Number,
	resting_heart_rate : Number,
	source : String,
	source_name : String,
	steps : Number,
	timestamp : String,
	user_id : String,
	utc_offset : String,
	validated : Boolean,
	water : Number,
	created_date : String,
	created_time : String
});

// save sleep
MemberHeartBitRateSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('MemberHeartBitRate', MemberHeartBitRateSchema);