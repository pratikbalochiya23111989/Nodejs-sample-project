//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var ChallengeAcceptSchema = new Schema({
	challenge_id: String,
	member_id: String,
	created_at: { type: Date, default: Date.now }
});

mongoose.model('ChallengeAccept', ChallengeAcceptSchema);