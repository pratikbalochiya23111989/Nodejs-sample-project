//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var PushNotificationSchema = new Schema({
	title: String,
	types : String,
	usertype: {type: String, enum: ['Policy_Holder', 'Member']},
	senddatetime: String,
	users: Array,
	created_at: { type: Date, default: Date.now },
});

mongoose.model('PushNotification', PushNotificationSchema);