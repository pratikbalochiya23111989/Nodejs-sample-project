//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var FlashScreenSchema = new Schema({
	image:String,
	title:String,
	description:String
});

mongoose.model('FlashScreen', FlashScreenSchema);