//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var Policy_holderSchema = new Schema({
	type: String,
	insurancetype_id: String,
	insuranceplan_id:String,
	policyholder_id: String,
	photo : String,
	customer_id : String,
	email : String,
	firstname: String,
	middlename:String,
	lastname:String,
	date_of_birth : String,
	gender : String,
	no_claims_applied : String,
	no_insurance_renewals : String,
	age: String,
	no_of_contacts: String,
	discount: String,
	premium: String,
	duration_of_contract: String,
	family_size: String,
	no_complaints: String,
	claim_amount: String,
	deductible_excess: String,
	no_claimssanctioned: String,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at : { type: Date, default: Date.now },
});

// save member
Policy_holderSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Policy_holder', Policy_holderSchema);