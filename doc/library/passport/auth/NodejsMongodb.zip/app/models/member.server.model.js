//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var MemberSchema = new Schema({
	member_code : String,
	company_id : String,
	multiple_departments: Array,
	multiple_teams : Array,
	department_id : Array,
	team_id : Array,
	firstname : String,
	middlename : String,
	lastname : String,
	email : String,
	phone : String,
	photo : String,
	device_id : String,
	device_name : String,
	device_type : {type: String, enum: ['IOS', 'Android']},
	device_token : String,
	otp : String,
	otp_posted : String,
	validic_uid : String,
	validic_access_token : String,
	validic_access_token_updated_datetime : String,
	age : Number,
	sex : {type: String, enum: ['Male', 'Female']},
	date_of_birth : String,
	height : Number,
	aware_weight : {type: String, enum: ['Yes', 'No']},
	weight : Number,
	bmi : Number,
	smoker : {type: String, enum: ['Yeah', 'Nope']},
	smokes : Number,
	drinker : {type: String, enum: ['Yeah', 'Nope']},
	drinks : Number,
	daily_activity_level : String,
	physical_activity : String,
	stepstaken : Number,
	sleephrs : Number,
	sleepquality : Number,
	caloriesburnt : Number,
	hr : Number,
	restinghr : Number,
	weekly_exercise_goal : Number,
	eType : {type: String, enum: ['Member', '']},
	badtime : { type: String, default: '22:00:00' },
	wakeup : { type: String, default: '08:00:00' },
	created_at : { type: Date, default: Date.now },
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']}
});

// save member
MemberSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Member', MemberSchema);