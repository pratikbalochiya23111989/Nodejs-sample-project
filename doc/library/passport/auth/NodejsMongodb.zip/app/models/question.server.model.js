//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var QuestionSchema = new Schema({
	title: String,
	order_by:Number,
	description:String,
	status: {type: String, enum: ['active', 'inactive']},
	created_at: { type: Date, default: Date.now },
	updated_at: { type: Date, default: Date.now }
});

mongoose.model('Question', QuestionSchema);