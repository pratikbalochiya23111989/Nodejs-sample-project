//define schema and mongoose 
var mongoose = require('mongoose')
	Schema = mongoose.Schema;

var ChallengeSchema = new Schema({
	company_id: String,
	photo: String,
	title: String,
	description: String,
	startdate : String,
	enddate : String,
	department_id : Array,
	team_id : Array,
	member_id : Array,
	category : String,
	target : String,
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']},
	created_at: { type: Date, default: Date.now },
	updated_at: { type: Date, default: Date.now }
});

mongoose.model('Challenge', ChallengeSchema);