//define schema and mongoose
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var SettingSchema = new Schema({
	title : String,
	value : String,
	created_at : { type: Date, default: Date.now }
});

// save setting
SettingSchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Setting', SettingSchema);