//define schema and mongoose 
var mongoose = require('mongoose'),
	crypto = require('crypto'),
	Schema = mongoose.Schema;

var CountrySchema = new Schema({
	title:String,
	created_at: { type: Date, default: Date.now },
	status: {type: String, enum: ['Active', 'Inactive', 'Deleted']}
});

// save country
CountrySchema.pre('save',
	function(next) {
		next();
	}
);

mongoose.model('Country', CountrySchema);