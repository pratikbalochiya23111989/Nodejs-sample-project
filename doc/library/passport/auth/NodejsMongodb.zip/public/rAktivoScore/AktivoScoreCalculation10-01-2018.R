setwd("/var/www/html/nodejs/aktivo/public/rAktivoScore")

source("modelAndFunctions.R")

url_in <- paste("http://192.168.1.76:1338/userStatistics?id=", paste(input[1]),"&date=",paste(input[2]), sep="")

# Calling the Get User Statistics URL
stats <- GET(url = url_in)

stats_text <- content(stats, 'text')
stats_json <- fromJSON(stats_text, flatten = TRUE)

# Original Dataframes
df <- as.data.frame(stats_json$data$statistics)
historicalScore <- as.data.frame(stats_json$data$historical_scores)
Score <- as.data.frame(stats_json$data$scores)

# Manipulation of dataframes begins here
df_score <- Score
df_score$date <- as.Date(df_score$date, '%Y-%m-%d')
df_score <- df_score[order(df_score$date), ]

df_historical_score <- historicalScore


# Replacing the missing day's data by its preceeding day and...
# ..repeating furthest day's scores and modified PA's

# Historical score is now prepared. 

xx <- df_historical_score

# Calculating Scores for unprocessed data
yy <- data.frame(date = NULL, aktivo_score = NULL, 
                 loaded_score = NULL, LIPA = NULL,
                 LIPA_Modified = NULL, MVPA = NULL, 
                 MVPA_Modified = NULL, Sleep = NULL, 
                 Sleep_Modified = NULL, 
                 SB = NULL, SB_Modified = NULL)
for(initDate in as.character(df_score$date)) {
  initDate <- as.Date(initDate, '%Y-%m-%d')
  
  if (dim(xx)[1] == 0) {
    xx <- xx
  } else {
    xx$date <- as.Date(xx$date, '%Y-%m-%d')
    xx <- xx[order(xx$date), ]
    Date <- min(xx$date) - 1:(no_of_days - 1) 
    xx <- merge(xx, data.frame(date = (initDate - 1:6)), by = "date", all = T)
    xx <- xx[order(xx$date), ]
    xx <- tail(xx, (no_of_days - 1))
    xx <- na.omit(xx)
    if (dim(xx)[1] == 0) {
      xx <- xx
    } else {
      nMissing <- 6 - dim(xx)[1]
      for(i in 1:nMissing){
        xx <- rbind(xx[1,],xx)
      }
      xx$date <- initDate - dim(xx)[1]:1
    }
  }
  INPUT <- df_score[df_score$date == initDate,]
  input.sb <- INPUT$SB
  input.lipa <- INPUT$LIPA
  input.mvpa <- INPUT$MVPA
  input.sleep <- INPUT$Sleep
  input.gender <- ifelse(df$gender == 'M', 'Male', 'Female')
  input.age <- df$age
  
  if(sum(input.sleep, input.sb, input.mvpa, input.lipa) > 1440) {
    Err <- paste0("Error : Sum of PA's is greater than 1440 for date:", as.character(initDate))
    print(paste0("Error : Sum of PA's is greater than 1440 for date:", as.character(initDate)))
    break
  } else {
    Remaining <- (1440 - sum(input.sleep, input.sb, input.mvpa, input.lipa))
    
    if(dim(xx)[1] == 0) {
      input.total <- (input.lipa + input.mvpa + input.sleep + input.sb)
      input.sleep.modified <- input.sleep + ((Remaining * input.sleep)/input.total)
      input.sb.modified <- input.sb + ((Remaining * input.sb)/input.total)
      input.mvpa.modified <- input.mvpa + ((Remaining * input.mvpa)/input.total)
      input.lipa.modified <- input.lipa + ((Remaining * input.lipa)/input.total)
      
      predicted_score <- score(gender = input.gender, Age = input.age, sb = input.sb.modified, 
                               lipa = input.lipa.modified, mvpa = input.mvpa.modified, sleep = input.sleep.modified)
      
      xx <- data.frame(date = as.Date(initDate), aktivo_score = 0, 
                       loaded_score = predicted_score, LIPA = input.lipa,
                       LIPA_Modified = input.lipa.modified, MVPA = input.mvpa, 
                       MVPA_Modified = input.mvpa.modified, Sleep = input.sleep, 
                       Sleep_Modified = input.sleep.modified, 
                       SB = input.sb, SB_Modified = input.sb.modified)
      
    } else {
      prevDate <- max(xx$date[which(xx$date < initDate)])
      changeInput.sb <- as.numeric(xx[xx$date == prevDate, 'SB_Modified'])
      changeInput.lipa <- as.numeric(xx[xx$date == prevDate, 'LIPA_Modified'])
      changeInput.mvpa <- as.numeric(xx[xx$date == prevDate, 'MVPA_Modified'])
      changeInput.sleep <- as.numeric(xx[xx$date == prevDate, 'Sleep_Modified'])
      
      input.sleep.modified <- input.sleep + ((Remaining * changeInput.sleep)/1440)
      input.sb.modified <- input.sb + ((Remaining * changeInput.sb)/1440)
      input.mvpa.modified <- input.mvpa + ((Remaining * changeInput.mvpa)/1440)
      input.lipa.modified <- input.lipa + ((Remaining * changeInput.lipa)/1440)
      
      predicted_score <- score(gender = input.gender, Age = input.age, sb = input.sb.modified, 
                               lipa = input.lipa.modified, mvpa = input.mvpa.modified, sleep = input.sleep.modified)
      newRow <- c(as.character(initDate), 0, predicted_score, input.lipa, input.lipa.modified, input.mvpa,
                  input.mvpa.modified, input.sleep, input.sleep.modified, input.sb, 
                  input.sb.modified)
      xx <- rbind.data.frame(xx, newRow)
      
    }
    
    yy <- rbind.data.frame(yy, data.frame(date = as.Date(initDate), aktivo_score = 0, 
                                          loaded_score = predicted_score, LIPA = input.lipa,
                                          LIPA_Modified = input.lipa.modified, MVPA = input.mvpa, 
                                          MVPA_Modified = input.mvpa.modified, Sleep = input.sleep, 
                                          Sleep_Modified = input.sleep.modified, 
                                          SB = input.sb, SB_Modified = input.sb.modified))
    
    loaded_scores <- tail(xx$loaded_score, no_of_days)
    loaded_scores <- c(rep(loaded_scores[1], no_of_days - length(loaded_scores)), loaded_scores)
    Sc <- (as.numeric(loaded_scores) * 1:no_of_days)
    aktivo_score <- sum(Sc)/((no_of_days*(no_of_days+1))/2)
    xx[xx$date == initDate, 'aktivo_score'] <- aktivo_score
    yy[yy$date == initDate, 'aktivo_score'] <- aktivo_score
    
  }
}

if(exists('yy') == T){
 generated_scores <- list("id" = df$id, "generated_score" = yy[,c("date", "aktivo_score", "loaded_score", "LIPA_Modified", 
                      "MVPA_Modified", "Sleep_Modified", "SB_Modified")])
} else if (exists('Err') == T) {
  generated_scores <- Err 
}else {}


# POST the parameters to the Set Statistics URL
url_out <- "http://192.168.1.76:1338/setStatistics"
z <- POST(url = url_out, body = generated_scores, encode = "json", verbose())

# Check whether successfully POSTED on the URL
message_for_status(z)
