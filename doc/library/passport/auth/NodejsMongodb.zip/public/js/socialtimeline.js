function pressLike(id,type){
	var loadURL = '';
	if(type=='HR'){
		loadURL = '/social/postFeedBack';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/postFeedBack';
	}
	else {
		loadURL = '/superadmin/social/postFeedBack';
	}

	$.post(loadURL,
    {
        social_id: id
    },
    function(data, status){
    	$('#getLike_'+id).html("<i class='fa fa-thumbs-o-up'></i> "+data);
    });$("[data-toggle='tooltip']").tooltip();
}

function pressComment(id,type){
	$("#toggleComment_"+id).toggle(1000);
	var loadURL = '',loadURLComment = '';
	if(type=='HR'){
		loadURL = '/social/postCommentFeedBack';
		loadURLComment = '/social/postListUserComment';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/postCommentFeedBack';
		loadURLComment = '/admin/social/postListUserComment';
	}
	else {
		loadURL = '/superadmin/social/postCommentFeedBack';
		loadURLComment = '/superadmin/social/postListUserComment';
	}

	var comment = $('#comment_'+id).val();
	$('#comment_'+id).val('');
	if(comment==''){
		$('#comment_'+id).addClass('errSocialText');
	}
	else {
		$('#comment_'+id).removeClass('errSocialText');
		$.post(loadURL,
	    {
	        social_id : id,
	        comment : comment
	    },
	    function(data, status){
	    	$('#getComment_'+id).html("<i class='fa fa-comments'></i> "+data);

	    	$.post(loadURLComment,
		    {
		        social_id : id
		    },
		    function(data, status){
		    	$('.getCommentUserList_'+id).html(data);
		    	return false;
		    });
	    });
	}
}

function pressListCommentUsersModal(id,type){
	var loadURL = '';
	if(type=='HR'){
		loadURL = '/social/pressListCommentUsersModal';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/pressListCommentUsersModal';
	}
	else {
		loadURL = '/superadmin/social/pressListCommentUsersModal';
	}

	$.post(loadURL,
    {
        social_id : id
    },
    function(data, status){
    	if(data.totalRecords>0){
    		$('#displayListCommentUsers').html(data.tableInfo);
	    	$('#socialCommentTotalUsers').text(data.totalRecords);
	    	$('#socialCommentUserList').modal('show');
    	}
    });
}

function pressListLikeUsers(id,type){
	var loadURL = '';
	if(type=='HR'){
		loadURL = '/social/postListLikeUsers';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/postListLikeUsers';
	}
	else {
		loadURL = '/superadmin/social/postListLikeUsers';
	}

	$.post(loadURL,
    {
        social_id: id
    },
    function(data, status){
    	if(data.totalRecords>0){
	    	$('#displayListLikeUsers').html(data.tableInfo);
	    	$('#socialLikeTotalUsers').text(data.totalRecords);
	    	$('#socialLikeUserList').modal('show');
	    }
    });
}

function pressListPreviewUsers(id,type){
	var loadURL = '';
	if(type=='HR'){
		loadURL = '/social/postListPreviewUsers';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/postListPreviewUsers';
	}
	else {
		loadURL = '/superadmin/social/postListPreviewUsers';
	}

	$.post(loadURL,
    {
        social_id: id
    },
    function(data, status){
    	if(data.totalRecords>0){
			$('#displayListPreviewUsers').html(data.tableInfo);
	    	$('#socialPreviewTotalUsers').text(data.totalRecords);
	    	$('#socialPreviewUserList').modal('show');
	    }
	    
    });
}

function pressListShareUsers(id,type){
	var loadURL = '';
	if(type=='HR'){
		loadURL = '/social/postListShareUsers';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/postListShareUsers';
	}
	else {
		loadURL = '/superadmin/social/postListShareUsers';
	}

	$.post(loadURL,
    {
        social_id: id
    },
    function(data, status){
    	if(data.totalRecords>0){
			$('#displayListShareUsers').html(data.tableInfo);
	    	$('#socialShareTotalUsers').text(data.totalRecords);
	    	$('#socialShareUserList').modal('show');
	    }
    });
}

function toggleComment(id){
	$("#toggleComment_"+id).toggle(1000);
}

function removeSocialPost(id,type){
	var loadURL = '',loadURLList = '';
	if(type=='HR'){
		loadURL = '/social/removePost';
		loadURLList = '/social/ajaxListSocialPost';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/removePost';
		loadURLList = '/admin/social/ajaxListSocialPost';
	}
	else {
		loadURL = '/superadmin/social/removePost';
		loadURLList = '/superadmin/social/ajaxListSocialPost';
	}

	$('.content-loading-message').html('Social post deleting...');
	$("#btn-call-loading-message")[0].click();
	$.post(loadURL,
    {
        social_id : id
    },
    function(data, status){
		$.post(loadURLList,
	    {
	        type: 'remove'
	    },
	    function(listInfo, listStatus){
	    	$('#list_social_post_area').html(listInfo);
	    	$(".close")[0].click();
	    	$('html, body').animate({scrollTop:550}, 5000);
	    });
    });
}

function pressTags(tag,type){
	var loadURL = '';
	if(type=='HR'){
		loadURL = '/social/ajaxListSocialPost';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/ajaxListSocialPost';
	}
	else {
		loadURL = '/superadmin/social/ajaxListSocialPost';
	}

	$('.content-loading-message').html('Social post loading...');
	$("#btn-call-loading-message")[0].click();
	$.post(loadURL,
    {
        type : 'tag',
        tag : tag
    },
    function(listInfo, listStatus){
    	$('#list_timeline_area').html(listInfo);
    	$(".close")[0].click();
    	$('html, body').animate({scrollTop:550}, 5000);
    });
}

function editSocialPost(id,type){
	var loadURL = '',loadURLList = '';
	if(type=='HR'){
		loadURL = '/social/loadSinglePost';
	}
	else if(type=='Insurance'){
		loadURL = '/admin/social/loadSinglePost';
	}
	else {
		loadURL = '/superadmin/social/loadSinglePost';
	}

	$('.content-loading-message').html('Social post loading...');
	$("#btn-call-loading-message")[0].click();
	$.post(loadURL,
    {
        social_id : id
    },
    function(data, status){
    	$(".close")[0].click();
    	$("#areaLoadEditPost").html(data);
    	$("#btn-call-loading-message2")[0].click();
    });
}