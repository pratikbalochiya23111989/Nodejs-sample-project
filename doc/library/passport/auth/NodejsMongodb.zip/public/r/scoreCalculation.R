# Load Required Packages
library(httr)
library(jsonlite)

url_in <- paste("http://192.168.1.91:1338/userStatistics?id=", paste(input[1]),"&date=",paste(input[2]), sep="")

# Calling the Get User Statistics URL
stats <- GET(url = url_in) 

stats_text <- content(stats, 'text')
stats_json <- fromJSON(stats_text, flatten = TRUE)

df <- as.data.frame(stats_json$data$statistics)
df_score <- as.data.frame(stats_json$data$scores)

Date <- as.Date(df$date, '%Y-%m-%d')

no_of_days <- 7

# =========================================================================
# MODEL BUILDING
# =========================================================================

# Preparing the model constraints

sleep <- seq(0, 24, 1)
male_less_than_50 <- c(9,8,7,6,5,4,2,0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)
male_greater_than_50 <- c(9,8,7,6,5,4,2,0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)

female_less_than_50 <- c(10,9,8,7,6,5,2.5,0,0,0,2,4,5,6,7,8,9,10,11,12,13,14,15,16,17)
female_greater_than_50 <- c(7,6,5,4,3,2,1,0,0,0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15)

penalty_point <- data.frame(Sleep = sleep, male_less_than_50, 
                            male_greater_than_50, female_less_than_50,
                            female_greater_than_50)


# Function to calculate the penalty value for deficiency/excess in sleep hours

sleepPenalty <- function(sleep, Age, gender = 'Female'){
  
  age <- ifelse(Age <= 50, ifelse(gender == 'Female', 'female_less_than_50', 'male_less_than_50'), 
                ifelse(gender == 'Female', 'female_greater_than_50', 'male_greater_than_50'))
  
  penalty.plus.one <- penalty_point[penalty_point$Sleep == as.numeric(floor(sleep) + 1), age]
  penalty.minus.one <- penalty_point[penalty_point$Sleep == as.numeric(floor(sleep)), age]
  
  if (sleep <= 9) {
    
    sleep_penalty <- penalty.minus.one - ((as.numeric(sleep) - as.numeric(floor(sleep))) * 
                                            abs(penalty.minus.one - penalty.plus.one))
    
  } else {
    
    sleep_penalty <- penalty.minus.one + ((as.numeric(sleep) - as.numeric(floor(sleep))) * 
                                            abs(penalty.minus.one - penalty.plus.one))
    
  }
  return(sleep_penalty)
}

# Preparing the model coefficients

female_less_than_50_coeff <- c(26.0394923871851, -0.523527976834494, 
                               1.14259502350332, 0.984910203763971, 
                               -0.00670483474495657)

female_greater_than_50_coeff <- c(26.0394923871851, -0.523527976834494, 
                                  1.14259502350332, 0.984910203763971, 
                                  -0.00670483474495657)

male_less_than_50_coeff <- c(24.7229393212017, -0.33266546421295, 1.14727282797639,
                             0.953821809705544, 0.0378780302056346)

male_greater_than_50_coeff <- c(31.9814197836501, -0.162624026885802, 
                                0.0596346041103889, 1.23379186949473, 
                                -0.110913942463974)

model_coeff <- data.frame(female_less_than_50_coeff, female_greater_than_50_coeff, 
                          male_less_than_50_coeff, male_greater_than_50_coeff)


# Function to calculate the Predicted BMI Score

score <- function(gender = 'Female', Age, sb, lipa, mvpa, sleep) {
  
  sb <- sb/60
  lipa <- lipa/60
  mvpa <- mvpa/60
  sleep <- sleep/60
  
  age <- ifelse(Age <= 50, ifelse(gender == 'Female', 'female_less_than_50_coeff', 'male_less_than_50_coeff'), 
                ifelse(gender == 'Female', 'female_greater_than_50_coeff', 'male_greater_than_50_coeff'))
  
  z1 <- sqrt(3/4)*log(lipa/(sb*mvpa*sleep)^(1/3)) 
  z2 <- sqrt(2/3)*log(sb/sqrt(mvpa*sleep))
  z3 <- sqrt(1/2)*log(sleep/mvpa)
  
  sleep_penalty <- sleepPenalty(sleep, Age, gender)
  
  xx <- model_coeff[,age] * unlist(c(1, z1, z2, z3, Age))
  bmi_Prediction <- sum(xx)
  Score_with_sleep <- bmi_Prediction + sleep_penalty
  
  if (mvpa > 2) {
    
    Score_with_MVPA_sleep <- Score_with_sleep + 0.7 * (as.numeric(mvpa) - 2)
    
  } else {
    
    Score_with_MVPA_sleep <- Score_with_sleep
    
  }
  
  activo_score <- 45 + (48 - Score_with_MVPA_sleep) * 11/5
  
  return(activo_score)
}

# =========================================================================
# Calculating 'loaded_score'
# =========================================================================

# THE INPUTS SHOULD BE IN MINUTES AND NOT IN HOURS

inputDate <- Date-1
INPUT <- df_score[df_score$date == inputDate,]
input.sb <- INPUT$SB
input.lipa <- INPUT$LIPA
input.mvpa <- INPUT$MVPA
input.sleep <- INPUT$Sleep
input.gender <- ifelse(df$gender == 'M', 'Male', 'Female')
input.age <- df$age

# Condition 1 : If sum of all the PA's is less than 1440..

if ((input.sleep + input.sb + input.mvpa + input.lipa) < 1440) {
  
  Remaining <- (1440 - sum(input.sleep, input.sb, input.mvpa, input.lipa))
  
  changeInput <- df_score
  
  
  # Condition 1(A) : Condition 1 holds and the score is being calculated..
  # ... for he first day.
  
  if (dim(changeInput)[1] == 1){
    
    input.total <- (input.lipa + input.mvpa + input.sleep + input.sb)
    input.sleep <- input.sleep + ((Remaining * input.sleep)/input.total)
    input.sb <- input.sb + ((Remaining * input.sb)/input.total)
    input.mvpa <- input.mvpa + ((Remaining * input.mvpa)/input.total)
    input.lipa <- input.lipa + ((Remaining * input.lipa)/input.total)
    
  } else {
    
    # Condition 1(B) : Condition 1 holds and the score is being calculated..
    # ... for second day or later days.
    
    changeInput.sb <- df_score[df_score$date == inputDate-1, 'SB_Modified']
    changeInput.lipa <- df_score[df_score$date == inputDate-1, 'LIPA_Modified']
    changeInput.mvpa <- df_score[df_score$date == inputDate-1, 'MVPA_Modified']
    changeInput.sleep <- df_score[df_score$date == inputDate-1, 'Sleep_Modified']
    
    input.sleep <- input.sleep + ((Remaining * changeInput.sleep)/1440)
    input.sb <- input.sb + ((Remaining * changeInput.sb)/1440)
    input.mvpa <- input.mvpa + ((Remaining * changeInput.mvpa)/1440)
    input.lipa <- input.lipa + ((Remaining * changeInput.lipa)/1440)
  }
  
  predicted_score <- score(gender = input.gender, Age = input.age, sb = input.sb, 
                           lipa = input.lipa, mvpa = input.mvpa, sleep = input.sleep)
} else {
  
  # Condition 2 : The sum of all activities are equal to 1440
  
  predicted_score <- score(gender = input.gender, Age = input.age, sb = input.sb, 
                           lipa = input.lipa, mvpa = input.mvpa, sleep = input.sleep)
}


# Storing the modfied values of PA's in '_Modified' columns for...
# ..next day's calculations.

df_score[df_score$date == inputDate, 'SB_Modified'] <- input.sb
df_score[df_score$date == inputDate, 'LIPA_Modified'] <- input.lipa
df_score[df_score$date == inputDate, 'MVPA_Modified'] <- input.mvpa
df_score[df_score$date == inputDate, 'Sleep_Modified'] <- input.sleep


# =========================================================================
# Calculating 'aktivo_score' and updating data{scores}
# =========================================================================

# NEW ROWS ARE ADDED AT THE BOTTOM OF THE EXISTING DATA FRAME

dfScore <- df_score[order(df_score$date),]
loaded_scores <- dfScore$loaded_score[is.na(dfScore$loaded_score) == F]
loaded_scores <- c(loaded_scores, predicted_score)
loaded_scores <- ifelse(length(loaded_scores) > 1, loaded_scores[-1], loaded_scores)
n <- 1:min(no_of_days, length(loaded_scores))
n1 <- length(loaded_scores)
Sc <- (as.numeric(loaded_scores) * n)
aktivo_score <- sum(Sc)/((n1*(n1+1))/2)

# POST the parameters to the Set Statistics URL
url_out <- "http://192.168.1.91:1338/setStatistics"
body <- list("id" = df$id, "aktivo_score" = aktivo_score, "loaded_score" = predicted_score, "date" = Date,
             "LIPA_Modified" = input.lipa, "MVPA_Modified" = input.mvpa, "Sleep_Modified" = input.sleep, 
             "SB_Modified" = input.sb)
z <- POST(url = url_out, body = body, encode = "json", verbose())

# Check whether successfully POSTED on the URL
message_for_status(z)
